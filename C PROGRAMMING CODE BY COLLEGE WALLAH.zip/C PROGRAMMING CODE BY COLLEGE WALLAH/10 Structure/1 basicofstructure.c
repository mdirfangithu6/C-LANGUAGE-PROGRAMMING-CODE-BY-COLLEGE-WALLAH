// 16:10+ par code
#include<stdio.h>

int main() {
    struct pokemon { // user defined data type
        int hp;
        int speed;
        int attack;
    };
    
    struct pokemon pikachu;
    pikachu.attack = 60;
    pikachu.hp = 50;
    pikachu.speed = 100;
    
    return 0;
}



// 24:55+ par code
#include<stdio.h>

int main() {
    struct pokemon { // user defined data type
        int hp;
        int speed;
        int attack;
    };
    
    struct pokemon pikachu;
    pikachu.attack = 60;
    pikachu.hp = 50;
    pikachu.speed = 100;

    struct pokemon charizard;
    pikachu.attack = 130;
    pikachu.hp = 80;
    pikachu.speed = 80;
    
    return 0;
}
 



// 26:55+ par code
#include<stdio.h>

int main() {
    struct pokemon { // user defined data type
        int hp;
        int speed;
        int attack;
        char tier; // S,A,B,C,D
    };
    
    struct pokemon pikachu;
    pikachu.attack = 60;
    pikachu.hp = 50;
    pikachu.speed = 100;
    pikachu.tier = "A";

    struct pokemon charizard;
    pikachu.attack = 130;
    pikachu.hp = 80;
    pikachu.speed = 80;
    charizard.tier = "S";
    
    return 0;
}



// 29:15+ par code
#include<stdio.h>

int main() {
    struct pokemon { // user defined data type
        int hp;
        int speed;
        int attack;
        char tier; // S,A,B,C,D
    };
    
    struct pokemon pikachu;
    pikachu.attack = 60;
    pikachu.hp = 50;
    pikachu.speed = 100;
    pikachu.tier = 'A';

    printf("%d", pikachu.attack);

    struct pokemon charizard;
    pikachu.attack = 130;
    pikachu.hp = 80;
    pikachu.speed = 80;
    charizard.tier = 'S';

    struct pokemon mewtwo;
    pikachu.attack = 170;
    pikachu.hp = 150;
    pikachu.speed = 200;
    charizard.tier = 'G';
    
    return 0;
}
// output
// 60




//33:06+ user se input
#include <stdio.h>

int main() {
    struct pokemon { // user-defined data type
        int hp;
        int speed;
        int attack;
        char tier; // S,A,B,C,D
    };

    struct pokemon pikachu;
    printf("Enter attack of pikachu: ");
    scanf("%d", &pikachu.attack);  
    //pikachu.attack = 60;
    pikachu.hp = 50;
    pikachu.speed = 100;
    pikachu.tier = 'A';

    struct pokemon charizard;
    charizard.attack = 130;     
    charizard.hp = 80;
    charizard.speed = 80;
    charizard.tier = 'S';

    struct pokemon mewtwo;
    mewtwo.attack = 170;      
    mewtwo.hp = 150;
    mewtwo.speed = 200;
    mewtwo.tier = 'G';

    printf("%d", pikachu.attack);
    

    return 0;
}
// output
// Enter attack of pikachu : 70
// 70





// 42:42+ par code
#include <stdio.h>

int main() {
    struct pokemon { // user-defined data type
        int hp;
        int speed;
        int attack;
        char tier; // S,A,B,C,D
    } pikachu, charizard, mewtwo;

    printf("Enter attack of pikachu: ");
    scanf("%d", &pikachu.attack);  
    //pikachu.attack = 60;
    pikachu.hp = 50;
    pikachu.speed = 100;
    pikachu.tier = 'A';


    charizard.attack = 130;     
    charizard.hp = 80;
    charizard.speed = 80;
    charizard.tier = 'S';


    mewtwo.attack = 170;      
    mewtwo.hp = 150;
    mewtwo.speed = 200;
    mewtwo.tier = 'G';

    printf("%d", pikachu.attack);

    return 0;
}