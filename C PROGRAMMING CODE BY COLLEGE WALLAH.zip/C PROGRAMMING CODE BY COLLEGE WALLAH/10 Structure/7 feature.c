// 2:04:53+ par code

#include<stdio.h>
#include<string.h>
int main(){
    typedef struct pokemon {
        int hp;
        int speed;
        int attack;
        char tier;
        char name[15];
    } pokemon;
    pokemon a, b, c;
    a.attack = 100;
    a.hp = 100;
    a.speed = 90;
    a.tier = 'A';
    strcpy(a.name, "Blastoise");

    b.attack = a.attack;
    b.hp = a.hp;
    b.speed = a.speed;
    b.tier = a.tier;
    strcpy(b.name, a.name);


    return 0;
}

// 2:09:10+ par code
#include<stdio.h>
#include<string.h>
int main(){
    typedef struct pokemon {
        int hp;
        int speed;
        int attack;
        char tier;
        char name[15];
    } pokemon;
    pokemon a, b, c;
    a.attack = 100;
    a.hp = 100;
    a.speed = 90;
    a.tier = 'A';
    strcpy(a.name, "Blastoise");

    // b.attack = a.attack;
    // b.hp = a.hp;
    // b.speed = a.speed;
    // b.tier = a.tier;
    // strcpy(b.name, a.name);

    b = a; // b me bhi a aa gaya  // deep copy

    b.attack = 200;

    printf("%d", b.attack);
    return 0;
}
// output
// 200




// 2:12:20+ par code
// strcpy(b.name, "Venusaur");
