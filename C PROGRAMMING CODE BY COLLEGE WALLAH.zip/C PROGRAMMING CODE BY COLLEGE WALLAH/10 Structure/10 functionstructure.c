// 2:40:13+

#include<stdio.h>
#include<string.h>
#include<stdbool.h>
void fun(pokemon p){
    printf("%d", p.hp);
    return;
}
int main() {
    typedef struct pokemon {
        int hp;
        int speed;
        int attack;
        char tier;
        char name[15];
    } pokemon;

    pokemon pikachu;
    pikachu.hp = 60;

    //printf("%d", pikachu.hp);
    fun(pikachu);

    return 0;
}
// output
// error



// 2:45:00+ par code 
#include<stdio.h>
#include<string.h>
#include<stdbool.h>
typedef struct pokemon {
    int hp;
    int speed;
    int attack;
    char tier;
    char name[15];
} pokemon;

void fun(pokemon p){
    printf("%d", p.hp);
    return;
}
int main() {
    pokemon pikachu;
    pikachu.hp = 60;
    
    //printf("%d", pikachu.hp);
    fun(pikachu);

    return 0;
}
// output
// 60




// 2:46:25+ par code (change kara sakta hu)
#include<stdio.h>
#include<string.h>
#include<stdbool.h>
typedef struct pokemon {
    int hp;
    int speed;
    int attack;
    char tier;
    char name[15];
} pokemon;

void fun(pokemon p){
    printf("%d", p.hp);
    return;
}
int main() {
    pokemon pikachu;
    pikachu.hp = 60;
    pikachu.attack = 50;
    pikachu.speed = 100;
    printf("%d\n", pikachu.hp);
    printf("%d\n", pikachu.attack);
    printf("%d\n", pikachu.speed);

    //fun(pikachu);

    return 0;
}
// output
// 60
// 50
// 100


// 2:47:34+ pass bu value 
#include<stdio.h>
#include<string.h>
#include<stdbool.h>
typedef struct pokemon {
    int hp;
    int speed;
    int attack;
    char tier;
    char name[15];
} pokemon;

void fun(pokemon p){
    printf("%d", p.hp);
    return;
}
void change(pokemon p) {
    p.hp = 70;
    p.attack = 60;
    p.speed = 110;
    return;
}

int main() {
    pokemon pikachu;
    pikachu.hp = 60;
    pikachu.attack = 50;
    pikachu.speed = 100;
    change(pikachu);
    printf("%d\n", pikachu.hp);
    printf("%d\n", pikachu.attack);
    printf("%d\n", pikachu.speed);

    //fun(pikachu);

    return 0;
}
// output
// 60
// 50
// 100