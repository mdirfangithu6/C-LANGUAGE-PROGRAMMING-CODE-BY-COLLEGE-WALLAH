// 2:51:52+
// Ques: Create a structure to specify data on students with these attributes: Roll number, Name, Department, Course, Year of joining. Create 2 structure variables. 
// Now, create a function to check if two students have the same Department. Pass the two structure variable as input to this function.

// by chatGPT
#include <stdio.h>
#include <string.h>

// Define structure for student
struct Student {
    int rollNumber;
    char name[50];
    char department[50];
    char course[50];
    int yearOfJoining;
};

// Function to check if two students are in the same department
int sameDepartment(struct Student s1, struct Student s2) {
    return strcmp(s1.department, s2.department) == 0;
}

int main() {
    // Creating two structure variables
    struct Student student1 = {101, "Alice", "Computer Science", "B.Tech", 2022};
    struct Student student2 = {102, "Bob", "Electrical", "B.Tech", 2022};

    // Check if they are in the same department
    if (sameDepartment(student1, student2)) {
        printf("Both students are in the same department.\n");
    } else {
        printf("Students are in different departments.\n");
    }

    return 0;
}
