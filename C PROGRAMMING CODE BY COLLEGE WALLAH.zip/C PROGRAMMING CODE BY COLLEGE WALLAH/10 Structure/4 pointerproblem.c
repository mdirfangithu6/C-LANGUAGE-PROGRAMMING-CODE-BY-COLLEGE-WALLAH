// 1:21:40+ par code
#include<stdio.h>
int main() {
    int x = 5;
    int y = 7;
    int* a = &x;
    int* b = &y;
    printf("%p\n", a);
    printf("%p\n", b);
    return 0;
}
// utftudcjx8
// jyftdurst4


// 1:24:34+ par code
#include<stdio.h>
int main() {
    int x = 5, y = 7;
    int* a = &x; b = &y;
    printf("%p\n", a);
    printf("%p\n", b);
    return 0;
}
// output
// ek error de raha hai



// 1:25:48+ par code
#include<stdio.h>
int main() {
    int x = 5, y = 7;
    int* a = &x, b = y; 
    printf("%p\n", a);
    printf("%d\n", b);
    return 0;
}
// output
// tffgfjdfkyt
// 7




// 1:26:08+ (wapas aate hai)
#include<stdio.h>
int main(){
    int x=5,y=7;
    int* a,b; // int* x and int y
    printf("%p\n",a);
    printf("%p\n",b);
    return 0;
}


// 1:27:33+ (typedef se solve kar sakte hai) 
#include<stdio.h>
typedef int* pointer;
int main(){
    int x=5, y=7;
    pointer a = &x, b = &y; // int* x and int y
    printf("%p\n",a);
    printf("%p\n",b);
    return 0;
}
// output
// ghfdtrsdjf8
// htjdsrjsxf4


// 1:29:10+
#include<stdio.h>
typedef int* int_pointer;
int main(){
    int x=5,y=7;
    int_pointer a = &x, b = &y; // int* x and int y
    printf("%p\n",a);
    printf("%p\n",b);
    return 0;
}