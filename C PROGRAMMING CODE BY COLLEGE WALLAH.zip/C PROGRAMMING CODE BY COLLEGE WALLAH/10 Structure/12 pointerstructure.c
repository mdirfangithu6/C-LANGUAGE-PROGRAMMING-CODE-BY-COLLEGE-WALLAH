// 2:56:14+

#include <stdio.h>
#include <string.h>
#include <stdbool.h>

typedef struct pokemon {
    int hp;
    int speed;
    int attack;
    char tier;
    char name[15];
} pokemon;

int main() {
    pokemon pikachu;

    // int* x -> address of integer value
    pokemon* x = &pikachu;
    printf("%p", x);

    return 0;
}
// output
// 0x7ffcae8394d0




// 3:01:35+ par code
#include <stdio.h>
#include <string.h>
#include <stdbool.h>

typedef struct pokemon {
    int hp;
    
    int attack;
    int speed;
    char tier;
    char name[15];
} pokemon;

int main() {
    pokemon pikachu;
    pikachu.hp = 60;
    pikachu.attack = 70;
    pikachu.speed = 100;
    pikachu.tier = 'A';
    strcpy(pikachu.name, "Pikachu");

    // int* x -> address of integer value
    pokemon* x = &pikachu;
    printf("%p\n", &pikachu.hp);
    printf("%p\n", &pikachu.attack);
    printf("%p\n", &pikachu.speed);
    printf("%p\n", &pikachu.tier);
    printf("%p\n", pikachu.name);
    printf("%p", x);
    return 0;
}
// // output
// 0x7ffc16ed7af0
// 0x7ffc16ed7af4
// 0x7ffc16ed7af8
// 0x7ffc16ed7afc
// 0x7ffc16ed7afd
// // 0x7ffc16ed7af0



// 3:05:13+ par code
#include <stdio.h>
#include <string.h>
#include <stdbool.h>

typedef struct pokemon {
    int hp;
    
    int attack;
    int speed;
    char tier;
    char name[15];
} pokemon;

int main() {
    pokemon pikachu;
    // pikachu.hp = 60;
    // pikachu.attack = 70;
    // pikachu.speed = 100;
    // pikachu.tier = 'A';
    // strcpy(pikachu.name, "Pikachu");

    // int* x -> address of integer value
    pokemon* x = &pikachu;
    // printf("%p\n", &pikachu.hp);
    // printf("%p\n", &pikachu.attack);
    // printf("%p\n", &pikachu.speed);
    // printf("%p\n", &pikachu.tier);
    // printf("%p\n", pikachu.name);
    // printf("%p", x);

    (*x).hp = 70; // pikachu,hp = 70
    printf("%d", pikachu.hp);
    return 0;
}
// outut
// 70



// 3:13:13+ wapas late hai wala code
#include <stdio.h>
#include <string.h>
#include <stdbool.h>

typedef struct pokemon {
    int hp;
    
    int attack;
    int speed;
    char tier;
    char name[15];
} pokemon;

int main() {
    pokemon pikachu;
    pikachu.hp = 60;
    pikachu.attack = 70;
    pikachu.speed = 100;
    pikachu.tier = 'A';
    strcpy(pikachu.name, "Pikachu");

    // int* x -> address of integer value
    pokemon* x = &pikachu;
    printf("%d\n", pikachu.hp);
    // printf("%p\n", &pikachu.attack);
    // printf("%p\n", &pikachu.speed);
    // printf("%p\n", &pikachu.tier);
    // printf("%p\n", pikachu.name);
    // printf("%p", x);

    (*x).hp = 70; // pikachu,hp = 70
    printf("%d", pikachu.hp);
    return 0;
}
// output
// 60
// 70





// pass by reference
#include <stdio.h>
#include <string.h>
#include <stdbool.h>

typedef struct pokemon {
    int hp;
    
    int attack;
    int speed;
    char tier;
    char name[15];
} pokemon;
void change(pokemon* p){
    (*p).hp = 70;
    (*p).attack = 80;
    (*p).speed = 110;
    (*p).tier = 'S';
    strcpy((*p).name, "Raichu");
    return;
}
int main() {
    pokemon pikachu;
    pikachu.hp = 60;
    pikachu.attack = 70;
    pikachu.speed = 100;
    pikachu.tier = 'A';
    strcpy(pikachu.name, "Pikachu");

    // int* x -> address of integer value
    pokemon* x = &pikachu;
    printf("%d\n", pikachu.hp);
    printf("%d\n", pikachu.attack);
    printf("%d\n", pikachu.speed);
    printf("%c\n", pikachu.tier);
    printf("%s\n", pikachu.name);

    change(&pikachu);

    printf("%d\n", pikachu.hp);
    printf("%d\n", pikachu.attack);
    printf("%d\n", pikachu.speed);
    printf("%c\n", pikachu.tier);
    printf("%s\n", pikachu.name);
    
    return 0;
}
// output
// 60
// 70
// 100
// A
// Pikachu
// 70
// 80
// 110
// S
// Raichu





// 3:18:25+ dusra tarika pointer ke through  assing print larne ka ect
#include <stdio.h>
#include <string.h>
#include <stdbool.h>

typedef struct pokemon {
    int hp;
    
    int attack;
    int speed;
    char tier;
    char name[15];
} pokemon;
void change(pokemon* p){
    // (*p).hp = 70; // ( (*x).something = x->something
    p->hp = 70;
    p->attack = 80;
    p->speed = 110;
    p->tier = 'S';
    strcpy(p->name, "Raichu");
    return;
}
int main() {
    pokemon pikachu;
    pikachu.hp = 60;
    pikachu.attack = 70;
    pikachu.speed = 100;
    pikachu.tier = 'A';
    strcpy(pikachu.name, "Pikachu");

    // int* x -> address of integer value
    pokemon* x = &pikachu;
    printf("%d\n", pikachu.hp);
    printf("%d\n", pikachu.attack);
    printf("%d\n", pikachu.speed);
    printf("%c\n", pikachu.tier);
    printf("%s\n", pikachu.name);

    change(&pikachu);

    printf("%d\n", pikachu.hp);
    printf("%d\n", pikachu.attack);
    printf("%d\n", pikachu.speed);
    printf("%c\n", pikachu.tier);
    printf("%s\n", pikachu.name);
    
    return 0;
}



// 3:22:43+ par code 
// better initialize 
#include <stdio.h>
#include <string.h>
#include <stdbool.h>

typedef struct pokemon {
    int hp;
    
    int attack;
    int speed;
    char tier;
    char name[15];
} pokemon;
void change(pokemon* p){
    // (*p).hp = 70; // ( (*x).something = x->something
    p->hp = 70;
    p->attack = 80;
    p->speed = 110;
    p->tier = 'S';
    strcpy(p->name, "Raichu");
    return;
}
int main() {
    pokemon pikachu = {60,70,100,'A', "pikachu"};
    // pikachu.hp = 60;
    // pikachu.attack = 70;
    // pikachu.speed = 100;
    // pikachu.tier = 'A';
    // strcpy(pikachu.name, "Pikachu");

    // int* x -> address of integer value
    pokemon* x = &pikachu;
    printf("%d\n", pikachu.hp);
    printf("%d\n", pikachu.attack);
    printf("%d\n", pikachu.speed);
    printf("%c\n", pikachu.tier);
    printf("%s\n", pikachu.name);

    change(&pikachu);

    printf("%d\n", pikachu.hp);
    printf("%d\n", pikachu.attack);
    printf("%d\n", pikachu.speed);
    printf("%c\n", pikachu.tier);
    printf("%s\n", pikachu.name);
    
    return 0;
}
