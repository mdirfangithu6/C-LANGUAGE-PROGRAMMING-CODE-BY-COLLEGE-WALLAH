// 1:47:26+ or 1:51:08+ par code
// Ques : A record contains name of criketer, his age, number of test matches that he has played and the average runs that he has scored in each test match.
// Create an array of structure to hold records of 20 such cricketer and then write a program to read these records

#include<stdio.h>
#include<string.h>

int main() {
    typedef struct cricketer {
        char name[15];
        int age;
        int noOfMatches;
        float average;
    } cricketer;

    // 3 cricketers
    cricketer arr[3];

    for(int i = 0; i < 3; i++) {
        scanf("%[^\n]s", arr[i].name); //scanf("%s", arr[i].name);
        scanf("%d", &arr[i].age);
        scanf("%d", &arr[i].noOfMatches);
        scanf("%f", &arr[i].average);
    }

    for(int i = 0; i < 3; i++) {
        printf("Name : %s\n", arr[i].name);
        printf("Age : %d\n", arr[i].age);
        printf("Number of matches played : %d\n", arr[i].noOfMatches);
        printf("Average : %f\n\n", arr[i].average);
    }

    return 0;
}
// output











// 2:01:50+ par code 
// last name se
#include <stdio.h>
#include <string.h>

int main() {
    typedef struct cricketer {
        char firstname[15];
        char lastname[15];
        int age;
        int noOfMatches;
        float average;
    } cricketer;

    // 3 cricketers
    cricketer arr[3];
    for(int i = 0; i < 3; i++) {
        scanf("%s", arr[i].firstname);
        scanf("%s", arr[i].lastname);
        scanf("%d", &arr[i].age);
        scanf("%d", &arr[i].noOfMatches);
        scanf("%f", &arr[i].average);
    }

    for(int i = 0; i < 3; i++) {
        printf("Name : %s %s \n", arr[i].fistname, arr[i].lastname);
        printf("Age : %d\n", arr[i].age);
        printf("Number of matches played : %d\n", arr[i].noOfMatches);
        printf("Average : %f\n", arr[i].average);
    }

    return 0;
}