// 44:10+ par code
// Ques : Create a structure type 'book' with name, price and number of pages as its attributes

#include <stdio.h>
#include <string.h>

int main() {
    struct book {
        char name[50];
        int noOfPages;
        float price;
    } a, b, c;

    a.noOfPages = 100;
    a.price = 411.5;
    a.name = "Secret Seven";

    printf("%d\n", a.noOfPages);
    printf("%f\n", a.price);
    printf("%s\n", a.name);

    return 0;
}
// output
// error aa gya



// 50:30+ par code
#include <stdio.h>
#include <string.h>

int main() {
    struct book {
        char name[5];
        int noOfPages;
        float price;
    } a, b, c;

    a.noOfPages = 100;
    a.price = 411.5;
    // a.name = "Secret Seven";
    a.name[0] = 'S';
    a.name[1] = 'e';
    a.name[2] = 'v';
    a.name[3] = 'e';
    a.name[4] = 'n';
    printf("%d\n", a.noOfPages);
    printf("%f\n", a.price);
    printf("%s\n", a.name);

    return 0;
}
// output
// 100
// 411.500000
// seven >/


// 52:40+ par code
#include <stdio.h>
#include <string.h>

int main() {
    struct book {
        char name[5];
        int noOfPages;
        float price;
    } a, b, c;

    a.noOfPages = 100;
    a.price = 411.5;
    // a.name = "Secret Seven";
    a.name[0] = 'S';
    a.name[1] = 'E';
    a.name[2] = 'V';
    a.name[3] = 'E';
    a.name[4] = 'N';
    // printf("%d\n", a.noOfPages);
    // printf("%f\n", a.price);
    // printf("%s\n", a.name);
    char ch[13]; // = "Secret Seven";
    ch = "Secret Seven";
    printf("%s", ch);
    return 0;
}
// output
// problem


// 56:00+ problem solve wala code
#include <stdio.h>
#include <string.h>

int main() {
    struct book {
        char name[5];
        int noOfPages;
        float price;
    } a, b, c;

    a.noOfPages = 100;
    a.price = 411.5;
    // a.name = "Secret Seven";
    a.name[0] = 'S';
    a.name[1] = 'E';
    a.name[2] = 'V';
    a.name[3] = 'E';
    a.name[4] = 'N';
    // printf("%d\n", a.noOfPages);
    // printf("%f\n", a.price);
    // printf("%s\n", a.name);
    char ch[13]; 
    strcpy(ch,"Secret Seven");
    printf("%s", ch);
    return 0;
}
// output
// Secret Seven


// 56:30+ Main code
#include <stdio.h>
#include <string.h>

int main() {
    struct book {
        char name[50];
        int noOfPages;
        float price;
    } a, b, c;

    a.noOfPages = 100;
    a.price = 411.5;
    strcpy(a.name,"Secret Seven");


    printf("%d\n", a.noOfPages);
    printf("%f\n", a.price);
    printf("%s\n", a.name);

    return 0;
}
// output
// 100
// 411.50000
// Secret Seven

// b.noOfPages = 100;
// b.price = 411.5;
// strcopy(b.name,"Secret Seven");

// printf("%d\n", b.noOfPages);
// printf("%f\n", b.price);
// printf("%s\n", b.name);




// 1:18:00+ par code
#include <stdio.h>
#include <string.h>

int main() {
    typedef struct Book {
        char name[50];
        int noOfPages;
        float price;
    } Book;

    struct Book d;
    struct Book a;
    struct Book b;
    struct Book c;

    // Book d;
    // Book a;
    // Book b;
    // Book c;
    

    a.noOfPages = 100;
    a.price = 411.5;
    strcpy(a.name,"Secret Seven");


    printf("%d\n", a.noOfPages);
    printf("%f\n", a.price);
    printf("%s\n", a.name);

    return 0;
}
// output
// 100
// 411.50000
// Secret Seven