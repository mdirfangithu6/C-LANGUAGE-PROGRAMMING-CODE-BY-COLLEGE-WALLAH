// 1:29:29+ or 1:32:15+ par code
#include<stdio.h>

int main() {
    typedef struct pokemon {
        int hp;
        int speed;
        int attack;
        char tier;
    } pokemon;

    pokemon arr[3]; // arr[0], arr[1], ... arr[2]

    arr[0].attack = 50;
    arr[0].hp = 100;
    arr[0].speed = 30;
    arr[0].tier = 'A';

    arr[1].attack = 150;
    arr[1].hp = 100;
    arr[1].speed = 130;
    arr[1].tier = 'S';

    arr[2].attack = 50;
    arr[2].hp = 30;
    arr[2].speed = 80;
    arr[2].tier = 'B';

    for(int i=0; i<3; i++) {
        printf("%d\n", arr[i].attack);
        printf("%d\n", arr[i].hp);
        printf("%d\n", arr[i].speed);
        printf("%c\n", arr[i].tier);
    }
    return 0;
}
// output
// 50
// 100
// 30
// A
// 150
// 100
// 130
// S
// 50
// 30
// 80
// B

// 1:39:18+ par code
// naam edit
#include<stdio.h>
#include<stdio.h>
int main() {
    typedef struct pokemon {
        int hp;
        int speed;
        int attack;
        char tier;
    } pokemon;

    pokemon arr[3]; // arr[0], arr[1], ... arr[2]

    arr[0].attack = 50;
    arr[0].hp = 100;
    arr[0].speed = 30;
    arr[0].tier = 'A';
    strcopy(arr[].name,"Charizard");

    arr[1].attack = 150;
    arr[1].hp = 100;
    arr[1].speed = 130;
    arr[1].tier = 'S';
    strcopy(arr[].name,"Mewtwo");

    arr[2].attack = 50;
    arr[2].hp = 30;
    arr[2].speed = 80;
    arr[2].tier = 'B';
    strcopy(arr[].name,"Pikachu");

    for(int i=0; i<3; i++) {
        printf("%s\n", arr[i].name);
        printf("Attack : %d\n", arr[i].attack);
        printf("HP : %d\n", arr[i].hp);
        printf("Speed : %d\n", arr[i].speed);
        printf("Tier : %c\n", arr[i].tier);
    }
    return 0;
}
// output
// Charizard
// Attack : 50
// HP : 100
// Speed : 30
// Tier : A

// Mewtwo
// Attack : 150
// HP : 100
// Speed : 130
// Tier : S

// Pikachu
// Attack : 50
// HP : 30
// Speed : 80
// Tier : B




// 1:44:15+ par code
// user input wala 
// by chatGPT

#include <stdio.h>
#include <string.h>

typedef struct pokemon {
    char name[20];
    int hp;
    int speed;
    int attack;
    char tier;
} pokemon;

int main() {
    pokemon arr[3]; // 3 Pokémon objects

    for (int i = 0; i < 3; i++) {
        printf("Enter details for Pokemon %d:\n", i + 1);

        printf("Name: ");
        scanf(" %19[^\n]", arr[i].name); // Reads string with spaces

        printf("Attack: ");
        scanf("%d", &arr[i].attack);

        printf("HP: ");
        scanf("%d", &arr[i].hp);

        printf("Speed: ");
        scanf("%d", &arr[i].speed);

        printf("Tier (A/B/C/S): ");
        scanf(" %c", &arr[i].tier); // Space before %c to ignore newline
    }

    printf("\n--- Pokemon Details ---\n");
    for (int i = 0; i < 3; i++) {
        printf("\n%s\n", arr[i].name);
        printf("Attack: %d\n", arr[i].attack);
        printf("HP: %d\n", arr[i].hp);
        printf("Speed: %d\n", arr[i].speed);
        printf("Tier: %c\n", arr[i].tier);
    }

    return 0;
}