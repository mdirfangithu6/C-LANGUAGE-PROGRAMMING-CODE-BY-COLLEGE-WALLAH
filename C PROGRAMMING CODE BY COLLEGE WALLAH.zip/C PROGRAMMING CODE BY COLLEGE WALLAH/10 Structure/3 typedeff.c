// 1:11:34+ par code
// Typedef
// &&

#include<stdio.h>
typedef float realNumber;

int main(){
    int x;
    realNumber y = 3.1415;
    return 0;
}
// output


// 1:15:00+ par code
#include<stdio.h>
typedef float realNumber;

int main(){
    int x;
    realNumber y = 3.1415;
    printf("%f", y);
    return 0;
}
// output
// 3.1415


// 1:16:58+ par code
#include<stdio.h>
typedef float realNumber;
typedef int Integer;

int main(){

    Integer x = 5;
    realNumber y = 3.1415;
    printf("%d", x);

    return 0;
}
// output
// 5
