// 2:13:04+
// Ques: Create a structure 'date' that contains three members namely date, month and year. Create 2 structure variables with different dates and now compare the two. 
// If the dates are equal then display message as "Equal" otherwise "Unequal".

#include<stdio.h>
#include<string.>
int main(){
    typedef struct date {
        int day;
        int month;
        int year;
    } date;
    
    date a, b;
    
    // a -> 5/12/1999
    // b -> 19/1/2023
    
    a.day = 5;
    a.month = 12;
    a.year = 1999;
    
    b.day = 19;
    b.month = 1;
    b.year = 2023;

    if(a==b) printf("The day are same");
    else printfa("The day are different");

    return 0;
}
// output
// error



// 2:18:14+ par code
#include<stdio.h>
#include<string.h>
int main(){
    typedef struct date {
        int day;
        int month;
        int year;
    } date;
    
    date a, b;
    
    // a -> 5/12/1999
    // b -> 19/1/2023
    
    a.day = 5;
    a.month = 12;
    a.year = 1999;
    
    b.day = 19;
    b.month = 1;
    b.year = 2023;

    if(a.day==b.day) printf("The dates are same");
    else printf("The dates are different");

    return 0;
}
// output
// The day are different


// 2:19:27+ par code
// individually wala code 
#include<stdio.h>
#include<string.h>
#include<stdbool.h>
int main(){
    typedef struct date {
        int day;
        int month;
        int year;
    } date;
    
    date a, b;
    
    // a -> 5/12/1999
    // b -> 19/1/2023
    
    a.day = 5;
    a.month = 12;
    a.year = 1999;
    
    b.day = 19;
    b.month = 1;
    b.year = 2023;

    bool flag = true;

    if (a.day != b.day) flag = false;
    if (a.month != b.month) flag = false;
    if (a.year != b.year) flag = false;

    if (flag == true) printf("the dates are same");
    else printf("the dates are different");

    return 0;
}
// output
// the dates are different



// 2:22:00+ par code
// Ques : Now create another structure variable by assinging the first date to it. Compare the first and third dates.
#include<stdio.h>
#include<string.h>
#include<stdbool.h>
int main(){
    typedef struct date {
        int day;
        int month;
        int year;
    } date;
    
    date a, b;
    
    // a -> 5/12/1999
    // b -> 19/1/2023
    
    a.day = 5;
    a.month = 12;
    a.year = 1999;
    
    b.day = 19;
    b.month = 1;
    b.year = 2023;

    // bool flag = true;

    // if (a.day != b.day) flag = false;
    // if (a.month != b.month) flag = false;
    // if (a.year != b.year) flag = false;

    // if (flag == true) printf("the dates are same");
    // else printf("the dates are different");

    date c;
    c = a;
    bool flag = true;

    if (a.day != c.day) flag = false;
    if (a.month != c.month) flag = false;
    if (a.year != c.year) flag = false;

    if (flag == true) printf("the dates are same");
    else printf("the dates are different");
    
    return 0;
}
// output
// the dates are same
