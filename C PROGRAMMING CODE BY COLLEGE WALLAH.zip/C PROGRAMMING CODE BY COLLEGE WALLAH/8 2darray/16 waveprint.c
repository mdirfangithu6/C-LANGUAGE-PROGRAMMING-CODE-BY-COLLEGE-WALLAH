//3:17:51+
//Ques: Given an n x m matrix 'a', print all elements of the matrix in spiral order. (Leetcode - 54)

#include<stdio.h>

int main(){
    int m;
    printf("Enter no of rows of 1st matrix : ");
    scanf("%d", &m);

    int n;
    printf("Enter no of columns of 1st matrix : ");
    scanf("%d", &n);

    int a[m][n];
    printf("Enter elements of 1st matrix : ");
    for(int i=0; i<m; i++){
        for(int j=0; j<n; j++)
        {
            scanf("%d", &a[i][j]);
        }
    }

    // wave print
    for(int i=0; i<m; i++){
        if(i%2==0){
            for(int j=0; j<n; j++)
            {
                printf("%d", a[i][j]);
            }
        }
        else{
            for(int j=n-1; j>=0; j--){
                printf("%d", a[i][j]);
            }
        }
        printf("\n");
    }
    return 0;
}

// // Output 
// Enter no of rows of 1st matrix : 3
// Enter no of columns of 1st matrix : 3
// Enter elements of 1st matrix :
// 1 2 3
// 4 5 6
// 7 8 9
// 123
// 654
// 789



// Acha se wala code
#include<stdio.h>

int main(){
    int m;
    printf("Enter no of rows of 1st matrix : ");
    scanf("%d", &m);

    int n;
    printf("Enter no of columns of 1st matrix : ");
    scanf("%d", &n);

    int a[m][n];
    printf("Enter elements of 1st matrix : ");
    for(int i=0; i<m; i++){
        for(int j=0; j<n; j++){
            scanf("%d", &a[i][j]);
        }
    }

    // wave print
    printf("\n");
    for(int i=0; i<m; i++)
    {
        if(i%2==0){
            for(int j=0; j<n; j++){
                printf("%d ", a[i][j]);
            }
        }
        else{
            for(int j=n-1; j>=0; j--){
                printf("%d ", a[i][j]);
            }
        }
        printf("\n");
    }
    return 0;
}

// Output 
// Enter no of rows of 1st matrix : 3
// Enter no of columns of 1st matrix : 3
// Enter elements of 1st matrix :
// 1 2 3
// 4 5 6
// 7 8 9

// 1 2 3
// 6 5 4
// 7 8 9