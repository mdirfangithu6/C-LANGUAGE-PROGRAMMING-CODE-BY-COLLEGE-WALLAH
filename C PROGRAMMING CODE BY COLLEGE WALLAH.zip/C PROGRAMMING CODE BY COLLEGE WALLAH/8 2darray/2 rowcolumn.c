// 40:23+ par code

#include<stdio.h>
int main(){
    int arr[][3] = {1,2,3,4,5,6};
    return 0;
}

// ya
#include<stdio.h>
int main(){
    int arr[][3] = {{1,2,3},{4,5,6}};
    return 0;
}