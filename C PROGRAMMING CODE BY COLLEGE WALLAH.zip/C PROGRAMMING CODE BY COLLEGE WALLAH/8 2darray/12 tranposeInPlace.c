// 1:33:30+
// Ques : write a program to change the given nxn matrix to its transpose.

#include <stdio.h>
int main(){
    int n;
    printf("Enter the number of rows/ columns : ");
    scanf("%d", &n);
    printf("Enter all the elements\n");
    int arr[n][n]; // n*n element
    // input
    for (int i=0; i<n; i++){
        for (int j=0; j<n; j++){
            scanf("%d ", &arr[i][j]);
        }
    }
    // transpose
    for (int i=0; i<n; i++){
        for (int j=0; j<n; j++){
            // swap arr[i][j] and arr[j][i]
            int temp = arr [i][j];
            arr[i][j] = arr[j][i];
            arr[j][i] = temp;
        }
    }
    // output
    for (int i=0; i<n; i++){
        for (int j=0; j<n; j++){
            printf("%d", arr[i][j]);
        }
        printf("\n");
    }

    return 0;
}
// output
// Enter the number of rows/ columns : 3
// Enter all teh element 
// 1 2 3
// 4 5 6 
// 7 8 9 
// 1 2 3
// 4 5 6 
// 7 8 9 



// main code 
// bas ek change huaa
#include <stdio.h>
int main(){
    int n;
    printf("Enter the number of rows/ columns : ");
    scanf("%d", &n);
    printf("Enter all the elements\n");
    int arr[n][n]; // n*n element
    // input
    for (int i=0; i<n; i++){
        for (int j=0; j<n; j++){
            scanf("%d ", &arr[i][j]);
        }
    }
    // transpose
    for (int i=0; i<n; i++){
        for (int j=i; j<n; j++){ // for (int j=0; j<=i; j++){
            // swap arr[i][j] and arr[j][i]
            int temp = arr [i][j];
            arr[i][j] = arr[j][i];
            arr[j][i] = temp;
        }
    }
    // output
    for (int i=0; i<n; i++){
        for (int j=0; j<n; j++){
            printf("%d", arr[i][j]);
        }
        printf("\n");
    }

    return 0;
}
// output
// Enter the number of rows/ columns : 3
// Enter all teh element 
// 1 2 3
// 4 5 6 
// 7 8 9 

// 1 4 7
// 2 5 8
// 3 6 9
