// 1:06:15+
// Homework : Write a program to print the row number having the maximum sum in a given matrix.
// by chatGPT

#include <stdio.h>

int main() {
    int n, m;
    printf("Enter number of rows and columns: ");
    scanf("%d %d", &n, &m);

    int a[100][100]; // assuming max size 100x100
    printf("Enter elements of the matrix:\n");
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < m; j++) {
            scanf("%d", &a[i][j]);
        }
    }

    int maxSum = -1e9; // very small number
    int maxRow = -1;

    for (int i = 0; i < n; i++) {
        int rowSum = 0;
        for (int j = 0; j < m; j++) {
            rowSum += a[i][j];
        }

        if (rowSum > maxSum) {
            maxSum = rowSum;
            maxRow = i;
        }
    }

    printf("Row with the maximum sum is: %d (0-based index)\n", maxRow);
    printf("Maximum row sum = %d\n", maxSum);

    return 0;
}
