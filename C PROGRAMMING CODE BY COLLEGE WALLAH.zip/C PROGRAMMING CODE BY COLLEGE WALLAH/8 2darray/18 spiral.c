// 3:31:21+ or 3:48:45+ par code
// Ques: Given an n x m matrix 'a', print all elements of the matrix in spiral order. (Leetcode - 54)

// 3:31:21+ or 3:48:45+ par code
// Ques: Given an n x m matrix 'a', print all elements of the matrix in spiral order. (Leetcode - 54)

#include<stdio.h>
int main(){
    int m;
    printf("Enter no of rows of 1st matrix : ");
    scanf("%d", &m);

    int n;
    printf("Enter no of columns of 1st matrix : ");
    scanf("%d", &n);

    int a[m][n];
    printf("Enter elements of 1st matrix : ");
    for(int i=0; i<m; i++){
        for(int j=0; j<n; j++){
            scanf("%d", &a[i][j]);
        }
    }
    // spiral print
    printf("\n");
    int minr = 0;
    int maxr = m-1;
    int minc = 0;
    int maxc = n-1;
    int tne = m*n;
    int count = 0;
    while(count<tne){
        // print the minimum row
        for(int j=minc; j<=maxc; j++){
            printf("%d ", a[minr][j]);
        }
        minr++;
        // print the maximum column
        for(int i=minr; i<=maxr; i++){
            printf("%d", a[i][maxc]);
        }
        maxc--;

        // print the maximum row
        for(int j=maxc; j>=minc; j--){
            printf("%d", a[maxr][j]);
        }
        maxr--;

        // print the minimum column
        for(int i=maxr; i>=minr; i--){
            printf("%d", a[i][minc]);
        }
        minc++;
    }
    return 0;
}
// output
// Enter no of rows of 1st matrix : 5
// Enter no of columns of 1st matrix : 6
// Enter elements of 1st matrix : 
// 1 2 3 4 5 6 
// 7 8 9 10 11 12
// 13 14 15 16 17 18
// 19 20 21 22 23 24
// 25 26 27 28 29 30


// Segmentation fault

// 4:01:25+ par code
// count++;
#include<stdio.h>
int main(){
    int m;
    printf("Enter no of rows of 1st matrix : ");
    scanf("%d", &m);

    int n;
    printf("Enter no of columns of 1st matrix : ");
    scanf("%d", &n);

    int a[m][n];
    printf("Enter elements of 1st matrix : ");
    for(int i=0; i<m; i++){
        for(int j=0; j<n; j++){
            scanf("%d", &a[i][j]);
        }
    }
    // spiral print
    printf("\n");
    int minr = 0;
    int maxr = m-1;
    int minc = 0;
    int maxc = n-1;
    int tne = m*n;
    int count = 0;
    while(count<tne){
        // print the minimum row
        for(int j=minc; j<=maxc; j++){
            printf("%d ", a[minr][j]);
            count++;
        }
        minr++;
        // print the maximum column
        for(int i=minr; i<=maxr; i++){
            printf("%d", a[i][maxc]);
            count++;
        }
        maxc--;

        // print the maximum row
        for(int j=maxc; j>=minc; j--){
            printf("%d", a[maxr][j]);
            count++;
        }
        maxr--;

        // print the minimum column
        for(int i=maxr; i>=minr; i--){
            printf("%d", a[i][minc]);
            count++;
        }
        minc++;
    }
    return 0;
}
// output
// Enter no of rows of matrix : 3
// Enter no of columns of matrix : 3

// Enter elements of matrix :
// 1 2 3
// 4 5 6
// 7 8 9

// 1 2 3 6 8 9 7 4 5


// Enter no of rows of matrix : 3
// Enter no of columns of matrix : 4

// Enter elements of matrix :
// 1 2 3 4
// 5 6 7 8 
// 9 10 11 12

// 1 2 3 4 8 12 11 10 9 5 6 7 6





// 4:14:40+ par code
// Choti si galti wala code
#include<stdio.h>
int main(){
    int m;
    printf("Enter no of rows of 1st matrix : ");
    scanf("%d", &m);

    int n;
    printf("Enter no of columns of 1st matrix : ");
    scanf("%d", &n);

    int a[m][n];
    printf("Enter elements of 1st matrix : ");
    for(int i=0; i<m; i++){
        for(int j=0; j<n; j++){
            scanf("%d", &a[i][j]);
        }
    }
    // spiral print
    printf("\n");
    int minr = 0;
    int maxr = m-1;
    int minc = 0;
    int maxc = n-1;
    int tne = m*n;
    int count = 0;
    while(count<tne){
        // print the minimum row
        for(int j=minc; j<=maxc; j++){
            printf("%d ", a[minr][j]);
            count++;
        }
        minr++;
        if(count>=tne) break;
        // print the maximum column
        for(int i=minr; i<=maxr; i++){
            printf("%d ", a[i][maxc]);
            count++;
        }
        maxc--;
        if(count>=tne) break;
        // print the maximum row
        for(int j=maxc; j>=minc; j--){
            printf("%d ", a[maxr][j]);
            count++;
        }
        maxr--;
        if(count>=tne) break;
        // print the minimum column
        for(int i=maxr; i>=minr; i--){
            printf("%d ", a[i][minc]);
            count++;
        }
        minc++;
        if(count>=tne) break;
    }
    return 0;
}
// output
// Enter no of rows of 1st matrix : 3
// Enter no of columns of 1st matrix : 4
// Enter elements of 1st matrix : 
// 1 2 3 4
// 5 6 7 8
// 9 10 11 12

// 1 2 3 4 8 12 11 10 9 5 6 7 




// 4:15:32+ par code
// dusre tarike se 

#include<stdio.h>
int main(){
    int m;
    printf("Enter no of rows of 1st matrix : ");
    scanf("%d", &m);

    int n;
    printf("Enter no of columns of 1st matrix : ");
    scanf("%d", &n);

    int a[m][n];
    printf("Enter elements of 1st matrix : ");
    for(int i=0; i<m; i++){
        for(int j=0; j<n; j++){
            scanf("%d", &a[i][j]);
        }
    }
    // spiral print
    printf("\n");
    int minr = 0;
    int maxr = m-1;
    int minc = 0;
    int maxc = n-1;
    int tne = m*n;
    int count = 0;
    while(count<tne){
        // print the minimum row
        for(int j=minc; j<=maxc && count<tne; j++){
            printf("%d ", a[minr][j]);
            count++;
        }
        minr++;
        // print the maximum column
        for(int i=minr; i<=maxr && count<tne; i++){
            printf("%d ", a[i][maxc]);
            count++;
        }
        maxc--;
        // print the maximum row
        for(int j=maxc; j>=minc && count<tne; j--){
            printf("%d ", a[maxr][j]);
            count++;
        }
        maxr--;
        // print the minimum column
        for(int i=maxr; i>=minr && count<tne; i--){
            printf("%d ", a[i][minc]);
            count++;
        }
        minc++;
    }
    return 0;
}
// output
// Enter no of rows of 1st matrix : 3
// Enter no of columns of 1st matrix : 4
// Enter elements of 1st matrix : 
// 1 2 3 4
// 5 6 7 8
// 9 10 11 12

// 1 2 3 4 8 12 11 10 9 5 6 7 