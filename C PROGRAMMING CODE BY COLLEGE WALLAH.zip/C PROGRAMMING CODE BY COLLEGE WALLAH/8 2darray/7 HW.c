// 1:00:43+
// HW : Find out the maximum element & minimum element is a 2D array, & the index of maximum 

// bt chatGPT

// part 1 (Find out the maximum element & minimum element is a 2D array)
#include <stdio.h>

int main() {
    int rows, cols;
    printf("Enter number of rows and columns: ");
    scanf("%d %d", &rows, &cols);

    int arr[100][100]; // assuming max 100x100 size
    printf("Enter elements of the array:\n");
    
    for(int i = 0; i < rows; i++) {
        for(int j = 0; j < cols; j++) {
            scanf("%d", &arr[i][j]);
        }
    }

    int max = arr[0][0];
    int min = arr[0][0];

    for(int i = 0; i < rows; i++) {
        for(int j = 0; j < cols; j++) {
            if(arr[i][j] > max)
                max = arr[i][j];
            if(arr[i][j] < min)
                min = arr[i][j];
        }
    }

    printf("Maximum element: %d\n", max);
    printf("Minimum element: %d\n", min);

    return 0;
}


// part 2 (the index of maximum )
#include <stdio.h>

int main() {
    int rows, cols;
    printf("Enter number of rows and columns: ");
    scanf("%d %d", &rows, &cols);

    int arr[100][100]; // assuming max 100x100 size
    printf("Enter elements of the array:\n");
    
    for(int i = 0; i < rows; i++) {
        for(int j = 0; j < cols; j++) {
            scanf("%d", &arr[i][j]);
        }
    }

    int max = arr[0][0];
    int maxRow = 0, maxCol = 0;

    for(int i = 0; i < rows; i++) {
        for(int j = 0; j < cols; j++) {
            if(arr[i][j] > max) {
                max = arr[i][j];
                maxRow = i;
                maxCol = j;
            }
        }
    }

    printf("Maximum element: %d\n", max);
    printf("Index of maximum element: [%d][%d]\n", maxRow, maxCol);

    return 0;
}
