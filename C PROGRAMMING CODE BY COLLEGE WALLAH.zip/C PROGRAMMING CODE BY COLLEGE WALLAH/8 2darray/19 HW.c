// 4:18:10+
// HW: Given a positive integer n, generate a nxn matrix filled with elements from 1 to n² in spiral order. (Leetcode - 59)

// by chatGPT
#include <stdio.h>

void generateSpiralMatrix(int n) {
    int matrix[n][n];
    int top = 0, bottom = n - 1;
    int left = 0, right = n - 1;
    int num = 1;

    while (top <= bottom && left <= right) {
        // Fill top row
        for (int i = left; i <= right; i++)
            matrix[top][i] = num++;
        top++;

        // Fill right column
        for (int i = top; i <= bottom; i++)
            matrix[i][right] = num++;
        right--;

        // Fill bottom row
        for (int i = right; i >= left; i--)
            matrix[bottom][i] = num++;
        bottom--;

        // Fill left column
        for (int i = bottom; i >= top; i--)
            matrix[i][left] = num++;
        left++;
    }

    // Print the matrix
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++)
            printf("%4d", matrix[i][j]);
        printf("\n");
    }
}

int main() {
    int n;
    printf("Enter the value of n: ");
    scanf("%d", &n);
    generateSpiralMatrix(n);
    return 0;
}