// 1:17:45+
// Ques : Write a program to print the transpose of the matrix entered by the user. (Leetcode - 867)

#include <stdio.h>
int main(){
    int r;
    printf("Enter the number of rows : ");
    scanf("%d", &r);
    int c;
    printf("Enter the number of column : ");
    scanf("%d", &c);
    printf("Enter all the elements\n");
    int arr[r][c]; // r*c total element
    for (int i = 0; i < r; i++){
        for (int j = 0; j < c; j++){
            scanf("%d ", &arr[i][j]);
        }
    }
    printf("\n");
    for (int i = 0; i < r; i++){
        for (int j = 0; j < c; j++){
            printf("%d ", arr[i][j]);
        }
        printf("\n");
    }

    return 0;
}
// iska output
// Enter the number of rows : 2
// Enter the number of column : 3
// Enter all the elements
// 1 2 3
// 4 5 6

// 1 2 3
// 4 5 6



// main code
#include <stdio.h>
int main(){
    int r;
    printf("Enter the number of rows : ");
    scanf("%d", &r);
    int c;
    printf("Enter the number of column : ");
    scanf("%d", &c);
    printf("Enter all the elements\n");
    int arr[r][c]; // r*c total element
    for (int i = 0; i < c; i++){
        for (int j = 0; j < r; j++){
            scanf("%d ", &arr[j][i]);
        }
    }
    // 1 2 3
    // 4 5 6

    // 1 4
    // 2 5
    // 3 6
    printf("\n");
    for (int i = 0; i < c; i++){  //c = 3 r = 2
        for (int j = 0; j < r; j++){ // r = 2
            printf("%d ", arr[j][i]);
        }
        printf("\n");
    }

    return 0;
}
// output
// 1 2 3
// 4 5 6

// 1 4
// 2 5
// 3 6



// 1:27:24+
// Ques : Write a program to print the transpose of the matrix entered by the user.
// & store it in a seperate matrix 
#include <stdio.h>
int main(){
    int r;
    printf("Enter the number of rows : ");
    scanf("%d", &r);
    int c;
    printf("Enter the number of column : ");
    scanf("%d", &c);
    printf("Enter all the elements\n");
    int arr[r][c]; // r*c total element
    for (int i = 0; i < c; i++){
        for (int j = 0; j < r; j++){
            scanf("%d ", &arr[j][i]);
        }
    }
    // 1 2 3
    // 4 5 6

    // 1 4
    // 2 5
    // 3 6
    int brr[c][r];
    printf("\n");
    for (int i = 0; i < c; i++){  //c = 3 r = 2
        for (int j = 0; j < r; j++){ // r = 2
            // printf("%d ", arr[j][i]);
            brr[i][j] = arr[j][i];
        }
    }
    // printingbrr 
    for(int i=0; i<c; i++){
        for(int j=0; j<r; j++){
            printf("%d", brr[i][j]);
        }
        printf("\n");
    }

    return 0;
}
// output
// Enter the number of rows : 2
// Enter the number of column : 3
// Enter all the elements
// 1 2 3
// 4 5 6

// 1 4
// 2 5
// 3 6