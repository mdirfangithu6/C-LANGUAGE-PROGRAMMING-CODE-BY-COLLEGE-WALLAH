// 41:50+ par code
// Ques : Write a program to store roll number and makrs obtained by 4 stdudents side by side in a matrix.
// Name     roll no  marks 
// raghar   76       80
// sanket   57       81
// urvi     40       90
// manvi    21       95
// by chatGPT

#include <stdio.h>

struct Student {
    char name[20];
    int roll_no;
    int marks;
};

int main() {
    struct Student students[4] = {
        {"raghar", 76, 80},
        {"sanket", 57, 81},
        {"urvi", 40, 90},
        {"manvi", 21, 95}
    };

    printf("Name\t Roll No\t Marks\n");
    for(int i = 0; i < 4; i++) {
        printf("%s\t %d\t\t %d\n", students[i].name, students[i].roll_no, students[i].marks);
    }

    return 0;
}