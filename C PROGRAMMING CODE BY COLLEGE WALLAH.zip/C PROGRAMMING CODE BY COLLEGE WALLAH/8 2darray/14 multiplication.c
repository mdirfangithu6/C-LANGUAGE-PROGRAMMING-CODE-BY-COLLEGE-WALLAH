// 2:11:33+ or 2:47:16+ par code
// Ques : Write a program to print the multiplication of two matrices given by the user.

#include<stdio.h>
int main() {
    // 1 2
    // 3 4
    // 5 6
    int a[3][2] = {{1,2}, {3,4}, {5,6}};
    // 1 2 3 4
    // 5 6 7 8
    int b[2][4] = {{1,2,3,4}, {5,6,7,8}};
    int res[3][4];
    // multiplying
    int cr = 2;
    for(int i=0;i<3;i++) {
        for(int j=0;j<4;j++) {
            // i row of a[i][i] and j column of b[i][i]
            // (a[i][0],a[i][1],a[i][2]......) * (b[0][j],b[1][j],b[2][j]......)
            res[i][j] = 0;
            for(int k=0;k<cr;k++) {
                res[i][j] += a[i][k]*b[k][j];
            }
        }
    }
    // print res
    // 11 14 17 20
    // 23 30 37 44
    // 35 46 57 68
    for(int i=0;i<3;i++) {
        for(int j=0;j<4;j++) {
            printf("%d ",res[i][j]);
        }
        printf("\n");
    }
    return 0;
}

// output , normaly apne matrix ko print kar ke  print dekh lete hai
// 11 14 17 20
// 23 30 37 44
// 35 46 57 68



// 3:03:40+
// khud ke matrix

#include<stdio.h>
int main() {
    
    int m = 3;
    int n = 2;
    int a[m][n] = {{1,2}, {3,4}, {5,6}};
    
    int p = 2;
    int q = 4;
    int b[p][q] = {{1,2,3,4}, {5,6,7,8}};
    int res[m][q];
    // multiplying
    // int cr = n;
    for(int i=0;i<m;i++) {
        for(int j=0;j<q;j++) {
            // i row of a[i][i] and j column of b[i][i]
            // (a[i][0],a[i][1],a[i][2]......) * (b[0][j],b[1][j],b[2][j]......)
            res[i][j] = 0;
            for(int k=0;k<n;k++) {
                res[i][j] += a[i][k]*b[k][j];
            }
        }
    }
    // print res
    
    for(int i=0;i<m;i++) {
        for(int j=0;j<q;j++) {
            printf("%d ",res[i][j]);
        }
        printf("\n");
    }
    return 0;
}
// output
// aise array nahi liya jata hai




// 3:06:00+
// input lenge wala code
// next file me hai-> file no 15 (15 multiplyinput)