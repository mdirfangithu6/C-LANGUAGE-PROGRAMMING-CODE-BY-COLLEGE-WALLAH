// 49:16+
// Ques : Write a program to add two matrices. 

#include <stdio.h>

int main() {
    int arr[2][2] = {1,2,3,4};
    int brr[2][2] = {5,6,7,8};
    printf("\n");
    int res[2][2];

    for(int i = 0; i < 2; i++) {
        for(int j = 0; j < 2; j++) {
            res[i][j] = arr[i][j] + brr[i][j];
        }
    }
    for(int i = 0; i < 2; i++) {
        for(int j = 0; j < 2; j++) {
            printf("%d ", res[i][j]);
        }
        printf("\n");
    }

    return 0;
}
// output
// 6 8
// 10 12



// 54:18+ par code
// HW : Do it without using extra matrix

// by chatGPT
#include <stdio.h>

int main() {
    int arr[2][2] = {1, 2, 3, 4};
    int brr[2][2] = {5, 6, 7, 8};

    // Add brr to arr directly
    for(int i = 0; i < 2; i++) {
        for(int j = 0; j < 2; j++) {
            arr[i][j] += brr[i][j];
        }
    }

    // Print the updated arr matrix
    for(int i = 0; i < 2; i++) {
        for(int j = 0; j < 2; j++) {
            printf("%d ", arr[i][j]);
        }
        printf("\n");
    }

    return 0;
}