// 3:06:28+ 
// perfect code

#include<stdio.h>
int main() {
    // 1st matric order
    int m;
    printf("Enter no of rows 1st matrix : ");
    scanf("%d", &m);
    int n;
    printf("Enter no of column of 1st martix : ");
    scanf("%d", &n);
    int a[m][n];
    // input the first matrix
    printf("\n Enter elements of 1st matrix : ");
    for(int i=0; i<m; i++){
        for(int j=0; j<n; j++){
            scanf("%d", &a[i][j]);
        }
    }
    // 2nd matric order
    int p;
    printf("Enter no of rows 2nd matrix : ");
    scanf("%d", &p);
    int q;
    printf("Enter no of column of 2nd martix : ");
    scanf("%d", &q);
    int b[p][q];
    // input the first matrix
    printf("\n Enter elements of 2nd matrix : ");
    for(int i=0; i<p; i++){
        for(int j=0; j<q; j++){
            scanf("%d", &b[i][j]);
        }
    }

    // check
    if(n!=p){
        printf("The ");
    }
    return 0;
}

// iska output
// Enter no of rows of 1st matrix : 2
// Enter no of columns of 1st matrix : 3
// Enter elements of 1st matrix :
// 1 2 3
// 4 5 6
// Enter no of rows of 2nd matrix : 2
// Enter no of columns of 2nd matrix : 3
// Enter elements of 2nd matrix :
// 1 2 3
// 4 5 6
// Matrices cannot be multiplied






// main code
#include<stdio.h>
int main() {
    // 1st matric order
    int m;
    printf("Enter no of rows 1st matrix : ");
    scanf("%d", &m);
    int n;
    printf("Enter no of column of 1st martix : ");
    scanf("%d", &n);
    int a[m][n];
    // input the first matrix
    printf("\n Enter elements of 1st matrix : ");
    for(int i=0; i<m; i++){
        for(int j=0; j<n; j++){
            scanf("%d", &a[i][j]);
        }
    }
    // 2nd matric order
    int p;
    printf("Enter no of rows 2nd matrix : ");
    scanf("%d", &p);
    int q;
    printf("Enter no of column of 2nd martix : ");
    scanf("%d", &q);
    int b[p][q];
    // input the first matrix
    printf("\n Enter elements of 2nd matrix : ");
    for(int i=0; i<p; i++){
        for(int j=0; j<q; j++){
            scanf("%d", &b[i][j]);
        }
    }

    // check
    if(n!=p){
        printf("The ");
    }
    else {
        // multiplication
        int res[m][q];
        for(int i=0;i<m;i++) {
            for(int j=0;j<q;j++) {
                res[i][j] = 0;
                // i row of a , j column of b
                for(int k=0;k<n;k++) {
                    res[i][j] += a[i][k]*b[k][j];
                }
            }
        }
        // print
        printf("The resultand matrix is : \n");
        for(int i=0;i<m;i++) {
            for(int j=0;j<q;j++) {
                printf("%d ", res[i][j]);
            }
            printf("\n");
        }

    }
    return 0;
}
// output
// Enter no of rows of 1st matrix : 3
// Enter no of columns of 1st matrix : 3
// Enter elements of 1st matrix :
// 1 0 0
// 0 1 0
// 0 0 1
// Enter no of rows of 2nd matrix : 3
// Enter no of columns of 2nd matrix : 3
// Enter elements of 2nd matrix :
// 1 0 0
// 0 1 0
// 0 0 1
// The resultant matrix is :
// 1 0 0
// 0 1 0
// 0 0 1