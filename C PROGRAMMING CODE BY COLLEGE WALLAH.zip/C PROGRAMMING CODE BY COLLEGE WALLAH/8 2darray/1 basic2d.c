// 14:00+ par code

#include<stdio.h>
int main(){
    int arr[2][2];
    arr[0][0] = 1;
    arr[0][1] = 2;
    arr[1][0] = 3;
    arr[1][1] = 4;
    // 1 2 
    // 3 4
    return 0;
}

// 16:42+ par code
// dusra tarika 
#include<stdio.h>
int main(){
    // 1 2 
    // 3 4
    int arr[2][2] = {{1,2},{3,4}};

    return 0;
}


// 18:30+ or 28:08+ par code
// array print 
#include<stdio.h>
int main(){
    // 1 2 
    // 3 4
    int arr[2][2] = {{1,2},{3,4}};
    for(int i=0; i<2; i++){
        for(int j=0; j<2; j++){
            printf("%d ", arr[i][j]);
        }
        printf("\n");
    }

    return 0;
}
// output
// 1 2 
// 3 4



// 29:14+ par code
#include<stdio.h>
int main(){
    // 1 2 
    // 3 4
    int arr[3][3] = {{1,2,3},{3,4,5},{4,5,6}};
    // 1 2 3 
    // 3 4 5
    // 4 5 6
    for(int i=0; i<3; i++){
        for(int j=0; j<3; j++){
            printf("%d ", arr[i][j]);
        }
        printf("\n");
    }

    return 0;
}
// output
// 1 2 3 
// 3 4 5
// 4 5 6



// 30:55+ par code
// user se input 
#include<stdio.h>
int main(){
    int arr[3][3];
    for(int i=0; i<3; i++){
        for(int j=0; j<3; j++){
            scanf("%d ", &arr[i][j]);
        }
    }
    printf("\n");
    for(int i=0; i<3; i++){
        for(int j=0; j<3; j++){
            printf("%d ", arr[i][j]);
        }
        printf("\n");
    }

    return 0;
}
// output
// 1 2 3 3 2 1 0 0 0
// 1 2 3
// 3 2 1
// 0 0 0 



// 32:50+ par code
// user se row column ka input
#include<stdio.h>
int main(){
    int r;
    printf("Enter the number of rows : ");
    scanf("%d", &r);
    int c;
    printf("Enter the number of column : ");
    scanf("%d", &c);
    int arr[r][c]; // r*c total element
    for(int i=0; i<r; i++){
        for(int j=0; j<c; j++){
            scanf("%d ", &arr[i][j]);
        }
    }
    printf("\n");
    for(int i=0; i<r; i++){
        for(int j=0; j<c; j++){
            printf("%d ", arr[i][j]);
        }
        printf("\n");
    }

    return 0;
}
// output
// Enter the number of rows : 
// Enter the number of column : 