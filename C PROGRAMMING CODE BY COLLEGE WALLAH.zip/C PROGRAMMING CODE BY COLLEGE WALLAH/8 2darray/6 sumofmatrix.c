// 54:27+
// Ques : Find the sum of a given matrix of n x m. 

#include<stdio.h>
int main(){
    int r;
    printf("Enter the number of rows : ");
    scanf("%d", &r);
    int c;
    printf("Enter the number of column : ");
    scanf("%d", &c);
    printf("Enter all the elements\n");
    int arr[r][c]; // r*c total element
    for(int i=0; i<r; i++){
        for(int j=0; j<c; j++){
            scanf("%d ", &arr[i][j]);
        }
    }
    printf("\n");
    for(int i=0; i<r; i++){
        for(int j=0; j<c; j++){
            printf("%d ", arr[i][j]);
        }
        printf("\n");
    }
    int sum = 0;
    for(int i=0; i<r; i++){
        for(int j=0; j<c; j++){
            sum += arr[i][j];
        }
    }
    printf("the sum of the given matrix is %d", sum);
    return 0;
}
// output
// Enter the number of rows:3
// Enter the number of columns: 3
// Enter all the elements
// 1 2 3
// 2 3 4
// 4 5 6

// 1 2 3
// 2 3 4
// 4 5 6
// the sum of the given matrix is 30