// 2:07:07+
// Ques : Count the number of triplets whose sum is equal to the given value x.

#include<stdio.h>
int main(){
    int arr[8] = {1,2,3,4,5,6,7,8};
    int totalTriplets = 0;
    int x =12;
    for(int i=0; i<=7; i++){
        for(int j=i+1; j<=7; j++){
            for(int k=j+1; k<=7; k++){
                if(arr[i] + arr[j] + arr[k] == x){
                    totalTriplets++;
                }
            }
        }
    }
    printf("%d", totalTriplets);
    return 0;
}
// output
// 6



// 2:11:50+ par code
// totalTriplets print wala code
#include<stdio.h>
int main(){
    int arr[8] = {1,2,3,4,5,6,7,8};
    int totalTriplets = 0;
    int x =12;
    for(int i=0; i<=7; i++){
        for(int j=i+1; j<=7; j++){
            for(int k=j+1; k<=7; k++){
                if(arr[i] + arr[j] + arr[k] == x){
                    totalTriplets++;
                    printf("(%d,%d,%d)\n", arr[i],arr[j],arr[k]);
                }
            }
        }
    }
    printf("%d", totalTriplets);
    return 0;
}
// output
// (1,3,8)
// (1,4,7)
// (1,5,6)
// (2,3,7)
// (2,4,6)
// (3,4,5)
// 6