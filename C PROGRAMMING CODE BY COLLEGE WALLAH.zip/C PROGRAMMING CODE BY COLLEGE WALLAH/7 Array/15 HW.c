// 1:52:38+ par code
// HW : Count the number of element in given array greater than a given number x.
// arr[7] = 1,2,3,4,5,6,7
// int x = 4;
// int count = 0;

// by chatGPt

#include <stdio.h>

int main() {
    int arr[7] = {1, 2, 3, 4, 5, 6, 7};
    int x = 4;
    int count = 0;

    for(int i = 0; i < 7; i++) {
        if(arr[i] > x) {
            count++;
        }
    }

    printf("Number of elements greater than %d = %d\n", x, count);

    return 0;
}
// output
// Number of elements greater than 4 = 3