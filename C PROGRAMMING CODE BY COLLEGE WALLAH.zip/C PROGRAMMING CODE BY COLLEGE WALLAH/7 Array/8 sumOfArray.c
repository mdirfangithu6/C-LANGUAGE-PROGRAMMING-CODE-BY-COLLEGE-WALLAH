// 1:13:17+
// Ques : Calculate the sum of the all the elements in the given array.

#include<stdio.h>
int main(){
    int arr[5] = {1,2,3,4,5};
    int sum = 0;
    for(int i=0; i<=4; i++){
        sum = sum + arr[i];
    }
    printf("%d", sum);
    return 0;
}
// output
// 15