// 44:59+ par code
// Ques : Are the following array declarations correct?
// int a(25);
// int size = 10,b[size];
// int c = {0,1,2};

#include<stdio.h>
int main(){
    int size = 10,b[size];
    //printf("%d", size);
    b[0] = 2;
    printf("%d", b[0]);
    return 0;
}
// output
// 2