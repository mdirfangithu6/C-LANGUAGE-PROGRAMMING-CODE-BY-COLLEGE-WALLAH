// 1:45:47+ par code
// Ques : Given an array of integers, change the value of all odd indexed element to its second multiple and increment all even indexed value by 10.
#include<stdio.h>
int main (){
    int arr[7] = {1,2,3,4,5,6,7};
    for(int i=0; i<=6; i++){
        if(i%2!=0){
            arr[i]*=2;
        }
        else{
            arr[i]+=10;
        }
    }
    return 0;
}



// 1:52:00+ par code
// aur ek kam kar lete hai print 
#include<stdio.h>
int main (){
    int arr[7] = {1,2,3,4,5,6,7};
    for(int i=0; i<=6; i++){
        if(i%2!=0){
            arr[i]*=2;
        }
        else{
            arr[i]+=10;
        }
    }
    for(int i=0; i<=6; i++){
        printf("%d", arr[i]);
    }
    return 0;
}
// output
// 11 4 13 8 15 12 17 