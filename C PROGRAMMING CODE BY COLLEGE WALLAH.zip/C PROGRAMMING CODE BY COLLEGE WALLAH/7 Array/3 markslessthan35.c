// 38:49+
// Ques : Given an array of marks of 10 students, if the student is less than 35 print its roll number. 
// [roll number here refers to the index of the array.]

#include<stdio.h>
int main(){
    int marks[10] = {95,90,31,25,100,50,65,89,97,30};
    for(int i=0; i<10; i++){
        printf("%d ", marks[i]);
    }

    return 0;
}
// output
// 95 90 31 25 100 50 65 89 97 30




// code 2
// 43:35+ 
#include<stdio.h>
int main(){
    int marks[10] = {95,90,31,25,100,50,65,89,97,30};
    for(int i=0; i<10; i++){
        if(marks[i]<35){
            printf("%d ", marks[i]);
        }
    }

    return 0;
}
// output
// 31 25 30




// code 3
// 44:20+ = marks ka index
#include<stdio.h>
int main(){
    int marks[10] = {95,90,31,25,100,50,65,89,97,30};
    for(int i=0; i<10; i++){
        if(marks[i]<35){
            printf("%d ", i);
        }
    }

    return 0;
}
// output
// 2 3 9 

// HW : is code se  user se input wala 
by chatGPT
#include<stdio.h>

int main(){
    int marks[10];

    // User input
    printf("Enter marks for 10 students:\n");
    for(int i = 0; i < 10; i++){
        printf("Student %d: ", i);
        scanf("%d", &marks[i]);
    }

    // Check and print indexes of students who scored less than 35
    printf("Indexes of students who scored less than 35: ");
    for(int i = 0; i < 10; i++){
        if(marks[i] < 35){
            printf("%d ", i);
        }
    }

    return 0;
}