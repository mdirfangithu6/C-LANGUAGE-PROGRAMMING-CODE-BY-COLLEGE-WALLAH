// 2:12:51+
// Ques : Find the second largest element in the given Array.

#include<stdio.h>
#include<limits.h>
int main(){
    int arr[7] = {-10,-4,-200,-80,-19,-5,-12};
    int max = INT_MIN; // sabse chhota number;
    int smax = INT_MIN;
    for(int i=0; i<=6; i++){
        if(max<arr[i]){
            max = arr[i];
        }
    }
    // max = -4;
    for(int i=0; i<=6; i++){
        if(arr[i]!=max && smax<arr[i]){
            smax = arr[i];
        }
    }
    printf("%d", smax);
    return 0;
}
// output
// -5


// 2:19:15+ par code
// single loop se
#include<stdio.h>
#include<limits.h>
int main(){
    int arr[7] = {1,2,3,4,5,6,7};
    int max = INT_MIN; // sabse chhota number;
    int smax = INT_MIN;
    for(int i=0; i<=6; i++){
        if(max<arr[i]){
            max = arr[i];
        }
        if(smax<arr[i] && max!=arr[i]){
            smax = arr[i];
        }
    }
    printf("%d", smax);
    return 0;
}
// output
// -2147483648
// int main ka value aaya 


// 2:24:05+ par code
// 5 ke jagah 3
#include<stdio.h>
#include<limits.h>
int main(){
    int arr[7] = {1,2,3,4,3,6,7};
    int max = INT_MIN; // sabse chhota number;
    int smax = INT_MIN;
    for(int i=0; i<=6; i++){
        if(max<arr[i]){
            max = arr[i];
        }
        if(smax<arr[i] && max!=arr[i]){
            smax = arr[i];
        }
    }
    printf("%d", smax);
    return 0;
}
// output
// 3
// galat aaya




// 2:24:43+ or 2:25:10+ par code
// main code
#include<stdio.h>
#include<limits.h>
int main(){
    int arr[7] = {1,2,3,4,5,6,7};
    int max = INT_MIN; // sabse chhota number;
    int smax = INT_MIN;
    for(int i=0; i<=6; i++){
        if(max<arr[i]){
            smax = max; // smax i snow previous max
            max = arr[i]; // max is a new max
        }
    }
    printf("%d", smax);
    return 0;
}
// output
// 6




// 2:31:40+ par code code
#include<stdio.h>
#include<limits.h>
int main(){
    int arr[7] = {7,6,5,4,3,2,1};
    int max = INT_MIN; // sabse chhota number;
    int smax = INT_MIN;
    for(int i=0; i<=6; i++){
        if(max<arr[i]){
            smax = max; // smax i snow previous max
            max = arr[i]; // max is a new max
        }
    }
    printf("%d", smax);
    return 0;
}
// output
// -2147483648
// int main ka value aaya 




// 2:31:57+ par code
// ek aur condition laga sakte hai wala code
#include<stdio.h>
#include<limits.h>
int main(){
    int arr[7] = {7,6,5,4,3,2,1};
    int max = INT_MIN; // sabse chhota number;
    int smax = INT_MIN;
    for(int i=0; i<=6; i++){
        if(max<arr[i]){
            smax = max; // smax i snow previous max
            max = arr[i]; // max is a new max
        }
        else if(smax<arr[i]){
            smax = arr[i];
        }
    }
    printf("%d", smax);
    return 0;
}
// output
// 6


// 2:32:45+ par code
// increasing number bhi ho jayega
#include<stdio.h>
#include<limits.h>
int main(){
    int arr[7] = {1,2,3,4,5,6,7}; //{7,6,5,4,3,2,1};
    int max = INT_MIN; // sabse chhota number;
    int smax = INT_MIN;
    for(int i=0; i<=6; i++){
        if(max<arr[i]){
            smax = max; // smax i snow previous max
            max = arr[i]; // max is a new max
        }
        else if(smax<arr[i]){
            smax = arr[i];
        }
    }
    printf("%d", smax);
    return 0;
}
// output
// 6


// 2:34:50+
// oobar khawar wale
#include<stdio.h>
#include<limits.h>
int main(){
    int arr[7] = {1,2,3,4,4,2,1};
    int max = INT_MIN; // sabse chhota number;
    int smax = INT_MIN;
    for(int i=0; i<=6; i++){
        if(max<arr[i]){
            smax = max; // smax i snow previous max
            max = arr[i]; // max is a new max
        }
        else if(smax<arr[i] && max!=arr[i]){
            smax = arr[i];
        }
    }
    printf("%d", smax);
    return 0;
}
// output
// 3