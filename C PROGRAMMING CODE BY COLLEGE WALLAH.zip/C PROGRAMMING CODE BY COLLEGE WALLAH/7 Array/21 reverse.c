// 2:46:06+ or 2:47:07+ par code
// **Ques : Write a program to reverse the array without using any extra array.

#include<stdio.h>
int main(){
    int arr[7] = {1,2,3,4,5,6,7};
    int brr[7];
    for(int i=0; i<=6; i++){
        brr[i] = arr[6-i];
    }
    for(int i=0; i<=6; i++){
        arr[i] = brr[6-i];
    }
    for(int i=0; i<=6; i++){
        printf("%d ",arr[i]);
    }
    return 0;
}
// output
// 7 6 5 4 3 2 1 


// 2:47:45+ or 2:49:06+ par code
// without using any extra array.
#include <stdio.h>

void reverse(int arr[]) {
    int i = 0;
    int j = 6;
    while (i < j) {
        // Swap arr[i] and arr[j]
        int temp = arr[i];
        arr[i] = arr[j];
        arr[j] = temp;
        i++;
        j--;
    }
    return;
}

int main() {
    int arr[7] = {1, 2, 3, 4, 5, 6, 7};
    reverse(arr);
    for (int i = 0; i <= 6; i++) {
        printf("%d ", arr[i]);
    }
    return 0;
}
// output
// 7 6 5 4 3 2 1 


// 2:52:35+ par code
// for lopp se 
#include <stdio.h>

void reverse(int arr[]) {
    for(int i=0, j=6; i<j; i++,j--){
        //arr[i] and arr[j];
        int temp = arr[i];
        arr[i] = arr[j];
        arr[j] = temp;
    }
    return;
}

int main() {
    int arr[7] = {1, 2, 3, 4, 5, 6, 7};
    reverse(arr);
    for (int i = 0; i <= 6; i++) {
        printf("%d ", arr[i]);
    }
    return 0;
}
// output
// 7 6 5 4 3 2 1 