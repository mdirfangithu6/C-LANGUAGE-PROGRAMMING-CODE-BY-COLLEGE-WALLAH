// 1:31:25+ par code
// Homework : Find the minimum value out of all the element in the array.
// by chatGPT

#include <stdio.h>

int main() {
    int arr[] = {12, 3, 7, 5, 2, 15}; // Example array
    int n = sizeof(arr) / sizeof(arr[0]);
    int min = arr[0];

    for(int i = 1; i < n; i++) {
        if(arr[i] < min) {
            min = arr[i];
        }
    }

    printf("Minimum value in the array = %d\n", min);

    return 0;
}
