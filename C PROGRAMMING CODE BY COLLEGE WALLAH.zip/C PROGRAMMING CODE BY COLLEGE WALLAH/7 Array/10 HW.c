// 1:18:20+ par code 
// Homework : Calculate the product of the all elements in the given array.

// by chatGPT

#include <stdio.h>

int main() {
    int arr[] = {2, 3, 4, 5}; // Example array
    int n = sizeof(arr) / sizeof(arr[0]);
    int product = 1;

    for(int i = 0; i < n; i++) {
        product *= arr[i];
    }

    printf("Product of all elements = %d\n", product);

    return 0;
}
// output
// Product of all elements = 120
