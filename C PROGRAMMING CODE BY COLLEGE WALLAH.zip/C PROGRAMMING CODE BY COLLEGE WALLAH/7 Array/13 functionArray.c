// 1:35:12+ par code

#include<stdio.h>
void fun(int a[]){

}
int main(){
    int arr[5] = {1,2,3,4,5,};
    fun(arr);
    return 0;
}


// 1:36:25+ par code
#include<stdio.h>
void fun(int a){
    a = 7;
    return;

}
int main(){
    // int arr[5] = {1,2,3,4,5,};
    // fun(arr);
    int a = 4;
    printf("%d\n", a);
    fun(a);
    printf("%d\n", a);
    return 0;
}
// output
// 4
// 4


// 1:39:10+ par code
// array e kya hota hai
#include<stdio.h>
void fun(int arr[]){ // void fun(int x[]){ 
    arr[0]= 10;      // x[0] = 109;
    return;
}
int main(){
    int arr[5] = {1,2,3,4,5};
    printf("%d\n", arr[0]);
    fun(arr);
    printf("%d\n", arr[0]);
    return 0;
}
// output
// 1
// 10



// 1:41:35+ par code
// swap wala
#include <stdio.h>

void fun(int x[]) {
    int temp = x[0];
    x[0] = x[1];
    x[1] = temp;
    return;
}

int main() {
    int arr[2] = {2, 9};
    printf("%d %d\n", arr[0], arr[1]);
    fun(arr);
    printf("%d %d\n", arr[0], arr[1]);
    return 0;
}
// output
// 2 9
// 9 2