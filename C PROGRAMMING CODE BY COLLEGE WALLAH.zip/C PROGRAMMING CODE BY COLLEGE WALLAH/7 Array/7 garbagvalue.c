// 1:07:37+ par code

#include<stdio.h>
int main(){
    int arr[4];
    printf("%d", arr[0]);
    return 0;
}
// output
// 123345&%$#

// 1:08:42+ par code
#include<stdio.h>
int main(){
    int x;
    printf("%d", x);
    return 0;
}
// output
// %#@%^125