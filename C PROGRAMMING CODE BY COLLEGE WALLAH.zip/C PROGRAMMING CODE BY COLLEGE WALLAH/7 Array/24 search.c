// 3:18:55+ 3:21:18+ par code
// Ques : Given array , & a number 'x'. Find out if 'x' lies in the array or not , if yes then print the index
// lenear search kahte hai

#include <stdio.h>
int main() {
    int arr[7] = {1, 2, 3, 4, 5, 6, 7};
    int x = 4;
    for (int i = 0; i <= 6; i++) {
        if(arr[i]==x){
            printf("%d is present in the array and its index is %d", x,i);
            break;
        }
    }
    return 0;
}
// output
// 4 is present in the array and its index is 3



// 3:24:10+ par code
#include <stdio.h>
int main() {
    int arr[7] = {12, 21, 30, 42, 55, 6, 7};
    int x = 21;
    for (int i = 0; i <= 6; i++) {
        if(arr[i]==x){
            printf("%d is present in the array and its index is %d", x,i);
            // break;
        }
    }
    return 0;
}
// output
// 21 is present in the array and its index is 1

// 3:24:27+ par code
// number (21)do baar hoto
#include <stdio.h>
int main() {
    int arr[7] = {12, 21, 30, 42, 21, 6, 7};
    int x = 21;
    for (int i = 0; i <= 6; i++) {
        if(arr[i]==x){
            printf("%d is present in the array and its index is %d\n", x,i);
            // break;
        }
    }
    return 0;
}
// output
// 21 is present in the array and its index is 1
// 21 is present in the array and its index is 4





// 3:25:25+ par code
// last index wala
#include <stdio.h>
int main() {
    int arr[7] = {12, 21, 21, 42, 21, 6, 7};
    int x = 21;
    for (int i = 6; i>=0; i--) {
        if(arr[i]==x){
            printf("%d is present in the array and its index is %d", x,i);
            break;
        }
    }
    return 0;
}
// output
// 21 is present in the array and its index is 4



// 3:26:28+ par code
// not present in the array wala code
#include <stdio.h>
int main() {
    int arr[7] = {1, 2, 3, 4, 5, 6, 7};
    int x = 4;
    int check = 0; // 0means the element is not present
    for (int i = 0; i <= 6; i++) {
        if(arr[i]==x){
            check = 1; // 1 means element is present
            break;
        }
    }
    if(check==0){
        printf("%d is not present in the array", x);
    }
    else{
        printf("%d is present in the array", x);
    }
    return 0;
}
// output
// 4 is present in the array



// 3:29:38+ par code
// naya data type
#include<stdio.h>
#include<stdbool.h>
int main() {
    int arr[7] = {1, 2, 3, 4, 5, 6, 7};
    int x = 21;
    bool flag = false; //false means not present
    for (int i = 0; i <= 6; i++) {
        if(arr[i]==x){
            flag = true; // true means present
            break;
        }
    }
    if(flag==false){
        printf("%d is not present in the array", x);
    }
    else{
        printf("%d is present in the array", x);
    }
    return 0;
}
// output
// 21 is present in the array




// 3:33:00+ par code
// is me chhoti si deekkat hai wala code (index print wala code)
#include<stdio.h>
#include<stdbool.h>
int main() {
    int arr[7] = {1, 2, 3, 4, 5, 6, 7};
    int x = 21;
    int idx = -1;
    bool flag = false; //false means not present
    for (int i = 0; i <= 6; i++) {
        if(arr[i]==x){
            flag = true; // true means present
            idx = i;
            break;
        }
    }
    if(flag==false){
        printf("%d is not present in the array", x);
    }
    else{
        printf("%d is present in the array and its index is %d", x,idx);
    }
    return 0;
}
// output
// 21 is present in the array and its index is 1