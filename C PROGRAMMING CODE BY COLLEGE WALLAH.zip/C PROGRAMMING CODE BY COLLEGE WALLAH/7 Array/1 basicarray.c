// 8:20+ par code
#include<stdio.h>
int main(){
    int a[5]; // 5 dabbe create to kar liye 

    return 0;
}



// code 2 
// 10:30+ = Declaration & Initialization
#include<stdio.h>
int main(){
    int arr[5] = {2,4,6,8,1};

    return 0;
}

// code 3
// 16:10+ = print array
#include<stdio.h>
int main(){
    int arr[5] = {2,4,6,8,1};
    printf("%d", arr[2]);
    return 0;
}
// output
// 6


// code 3
// 17:45+ = updation
#include<stdio.h>
int main(){
    int arr[5] = {2,4,6,8,1};
    arr[4] = 100; // {2,4,6,8,100};
    printf("%d", arr[4]);
    return 0;
}
// output
// 100



// code_3.1 
// 18:23+ par code
#include<stdio.h>
int main(){
    int arr[5] = {2,4,6,8,1};
    arr[4] = 100; // {2,4,6,8,100};
    arr[1] = 1; // {2,1,6,8,100};
    printf("%d", arr[1]);
    return 0;
}
// output
// 1


// code 4 = khurafati dimag
// 19:05+ par code
#include<stdio.h>
int main(){
    int arr[5] = {2,4,6,8,1};
    arr[4] = 100; // {2,4,6,8,100};
    arr[1] = 1; // {2,1,6,8,100};
    printf("%d", arr[10]);
    return 0;
}
// output
// error



// code 5 = float
// 20:18+ par code 
#include<stdio.h>
int main(){
    float a[3] = {1.2,3.4,5.7};
    printf("%f", a[2]);
    return 0;
}
// output
// 5.700000

// code 5.1 = char 
// 21:21+ par code
#include<stdio.h>
int main(){
    char arr[4] = {'a','n','Y','%'};
    printf("%c", arr[3]);
    return 0;
}
// output
// %



// 22:18+ kya yahih tarika hota Initialize karne ka
// dusra tarika (bekar hai)
#include<stdio.h>
int main(){
    int arr[5];
    arr[0] = 1;
    arr[1] = 3;
    arr[2] = 4;
    arr[3] = 10;
    arr[4] = 2;

    printf("%d", arr[3]);
    return 0;
}
// output
// 10





// 24:10+ taking inpur (user se input) bekar tarika hai
#include<stdio.h>
int main(){
    int arr[5];

    printf("Enter first element : ");
    scanf("%d", &arr[0]);
    printf("Enter seconf element : ");
    scanf("%d", &arr[1]);
    printf("Enter third element : ");
    scanf("%d", &arr[2]);
    printf("Enter fourth element : ");
    scanf("%d", &arr[3]);

    printf("%d", arr[2]);
    return 0;
}
// output
// Enter first element : 1
// Enter seconf element : 2
// Enter third element : 3
// Enter fourth element : 4
// 3




// 27:25 + loop se karo 
// pahle normal wala
#include<stdio.h>
int main(){
    int arr[5] = {2,4,6,8,1};

    printf("%d ", arr[0]);
    printf("%d ", arr[1]);
    printf("%d ", arr[2]);
    printf("%d ", arr[3]);
    printf("%d ", arr[4]);

    return 0;
}
// output
// 2 4 6 8 1 

// 28:26+ par code
// loop se 
#include<stdio.h>
int main(){
    int arr[5] = {2,4,6,8,1};
    for(int i=0; i<=4; i++){
        printf("%d ", arr[i]);
    }
    return 0;
}
// output
// 2 4 6 8 1 




// 30:32+ 
// array me input
#include<stdio.h>
int main(){
    int arr[5];
    for(int i=0; i<=4; i++){
        scanf("%d ", &arr[i]);
    }
    printf("%d", arr[1]);
    return 0;
}
// output
// 1
// 2
// 3
// 4
// 5

// 2


// 32:32+ par code
// isi ko sunder se 
#include<stdio.h>
int main(){
    int arr[5];
    for(int i=0; i<=4; i++){ // i = 0,1,2,3,4
        int a = i+1;
        printf("Enter element number %d\n", i);
        scanf("%d", &arr[i]);
    }
    // 
    printf("%d", arr[1]);
    return 0;
}
// output
// Enter element number 0
// 2
// Enter element number 1
// 3
// Enter element number 2
// 4
// Enter element number 3
// 7
// Enter element number 4
// 9
// 3


// 34:25+ time waste
#include<stdio.h>
int main(){
    int arr[5];
    for(int i=0; i<=4; i++){ // i = 0,1,2,3,4
        printf("Enter element number %d\n", i+1);
        scanf("%d ", &arr[i]);
    }
    // 
    printf("%d", arr[1]);
    return 0;
}
// output
// Enter element number 1
// 9
// Enter element number 2
// 8
// Enter element number 3
// 7
// Enter element number 4
// 6
// Enter element number 5
// 5
// 8


// 35:00+ pura ke pura array print karna 
#include<stdio.h>
int main(){
    int arr[5];
    for(int i=0; i<=4; i++){ // i = 0,1,2,3,4
        printf("Enter element number %d\n, i+1");
        scanf("%d ", &arr[i]);
    }
    for(int i=0; i<=5; i++){
        printf("%d ", arr[i]);
    }
    return 0;
}
// output
// Enter element number 11

// Enter element number 22

// Enter element number 33

// Enter element number 44

// Enter element number 55
// 1 2 3 4 5