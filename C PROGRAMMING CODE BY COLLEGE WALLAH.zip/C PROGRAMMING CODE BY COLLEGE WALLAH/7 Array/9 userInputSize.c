// 1:15:08+
// user se input lena wala code

#include<stdio.h>
int main(){
    int n;
    printf("Enter the size of array : ");
    scanf("%d", &n);
    int arr[n];
    return 0;
}
// output
// Enter the size of array : 5




// 1:16:30+
#include<stdio.h>
int main(){
    int n;
    printf("Enter the size of array : ");
    scanf("%d", &n);
    int arr[n];
    for(int i=0; i<=n-1; i++){
        scanf("%d", &arr[i]);
    }
    for(int i=0; i<=n-1; i++){
        printf("%d ", arr[i]);
    }
    return 0;
}
// output
// Enter the size of array : 5
// 1
// 2
// 3
// 5
// 4
// 1 2 3 5 4