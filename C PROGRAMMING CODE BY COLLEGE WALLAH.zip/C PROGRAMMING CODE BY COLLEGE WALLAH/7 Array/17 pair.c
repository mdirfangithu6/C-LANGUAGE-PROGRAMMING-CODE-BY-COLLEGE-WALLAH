// 1:58:12+ par code
// Ques : Find the total number of pairs in the Array whose sum is equal to the given values x.

#include<stdio.h>
int main(){
    int arr[8] = {1,2,3,4,5,6,7,8};
    int totalPairs = 0;
    int x =12;
    for(int i=0; i<=7; i++){
        for(int j=i+1; j<=7; j++){
            if(arr[i]+arr[j] == x){
                totalPairs++;
            }
        }
    }
    printf("%d", totalPairs);
    return 0;
}
// output
// 2


// 2:06:18+ par code
// print kar ke dekh lete hai
#include<stdio.h>
int main(){
    int arr[8] = {1,2,3,4,5,6,7,8};
    int totalPairs = 0;
    int x =12;
    for(int i=0; i<=7; i++){
        for(int j=i+1; j<=7; j++){
            if(arr[i]+arr[j] == x){
                totalPairs++;
                printf("(%d,%d)\n", arr[i], arr[j]);
            }
        }
    }
    printf("%d", totalPairs);
    return 0;
}
// output
// (4,8)
// (5,7)
// 2