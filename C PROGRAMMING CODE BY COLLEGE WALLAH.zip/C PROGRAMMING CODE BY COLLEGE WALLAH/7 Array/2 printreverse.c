// 36:15+ par code


#include<stdio.h>
int main(){
    int arr[5];
    for(int i=0; i<=4; i++){ // i = 0,1,2,3,4
        printf("Enter element number %d\n, i+1");
        scanf("%d ", &arr[i]);
    }
    for(int i=4; i>=0; i--){
        printf("%d ", arr[i]);
    }
    return 0;
}
// output
// Enter element number 1
// 1
// Enter element number 2
// 2
// Enter element number 3
// 5
// Enter element number 4
// 8
// Enter element number 5
// 0
// 0 8 5 2 1
