// 3:39:40+ par code
// Ques : WAp to find a dupicate element from a given array of intergers.

#include<stdio.h>
int main(){
    int arr[7] = {1,2,7,4,5,6,7};
    for(int i=0; i<=6; i++){
        for(int j=i+1; j<=6; j++){
            if(arr[i]==arr[j]){
                printf("%d is the dupicate element", arr[i]);
                break;
            }
        }
    }
    return 0;
}
// output
// 7 is the dupicate element