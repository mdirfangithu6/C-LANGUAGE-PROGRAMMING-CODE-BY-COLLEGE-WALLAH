// 3:35:42+ par code
// Ques : Given an array containing element from 1 to 100 except one element in this range is missimg. Find the missing element.

// by chatGPT
#include <stdio.h>

int findMissingNumber(int arr[], int size) {
    int total = 100 * 101 / 2; // Sum of numbers from 1 to 100
    int sum = 0;

    for (int i = 0; i < size; i++) {
        sum += arr[i];
    }

    return total - sum;
}

int main() {
    int arr[99]; // Since one number is missing, the array size is 99

    printf("Enter 99 numbers from 1 to 100 (one missing):\n");
    for (int i = 0; i < 99; i++) {
        scanf("%d", &arr[i]);
    }

    int missing = findMissingNumber(arr, 99);
    printf("The missing number is: %d\n", missing);

    return 0;
}
