// 48:45+ or 55:55+ par code
// Ques : Which element of the array does this expression referrence?
// num[4]

#include<stdio.h>
int main(){
    int arr[5] = {1,1,2,1,1};
    printf("%d\n", &arr[0]);
    printf("%d\n", &arr[1]);
    printf("%d\n", &arr[2]);
    printf("%d\n", &arr[3]);
    printf("%d\n", &arr[4]);
    return 0;
}
// output
