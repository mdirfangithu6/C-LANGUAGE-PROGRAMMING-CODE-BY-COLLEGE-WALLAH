// 1:19:10+ par code
// *Ques : Find the maximum value out of all the elements in the array.
#include<stdio.h>
int main(){
    int arr[7] = {1,4,2,8,19,5,12};
    int max = -1; //sabse chhota number 
    for(int i=0; i<7; i++){ // i<=7; ka ek problem aa raha hai online compiler me isi liye i<7; 
        if(max<arr[i]){
            max = arr[i];
        }
    }
    printf("%d", max);
    return 0;

}
// output
// 19


// 1:25:07+ par code
// - wala code
#include<stdio.h>
int main(){
    int arr[7] = {-10,-4,-200,-80,-19,-5,-12};
    int max = -1; // sabs chhota number
    for(int i=0; i<=6; i++){
        if(max<arr[i]){
            max = arr[i];
        }
    }
    printf("%d",max);
    return 0;
}
// output
// -1


// 1:26:45+ par code
// main code
#include<stdio.h>
int main(){
    int arr[7] = {-10,-4,-200,-80,-19,-5,-12};
    int max = arr[0]; // sabs chhota number
    for(int i=0;i<=6;i++){ // for(int i=1;i<=6;i++){
        if(max<arr[i]){
            max = arr[i];
        }
    }
    printf("%d",max);
    return 0;
}
// output
// -4


// 1:28:15+ par code
// 1 se bhi suru
#include<stdio.h>
int main(){
    int arr[7] = {-10,-4,-200,-80,-19,-5,-12};
    int max = arr[0]; // sabs chhota number
    for(int i=1;i<=6;i++){ // for(int i=1;i<=6;i++){
        if(max<arr[i]){
            max = arr[i];
        }
    }
    printf("%d",max);
    return 0;
}
// output
// -4





// 1:28:30+ par code
// INT_MIN wala code 
#include<stdio.h>
#include<limits.h>
int main(){
    int arr[7] = {-10, -4, -200, -80, -19, -5, -12};
    int max = INT_MIN; // sabse chhota number
    for(int i=0;i<=6;i++)
    {
        if(max<arr[i]) {
            max = arr[i];
        }
    }
    printf("%d",max);
    return 0;
}
// output
// -4




// 1:29:29+ par code
#include<stdio.h>
#include<limits.h>
int main(){
    int max = INT_MIN; // sabse chhota number
    printf("%d",max);
    return 0;
}
