// 2:53:35+
// Homework : If an array arr contains n elements, then check if the given array is a palindrome or not.
// by chatGPT

#include <stdio.h>
#include <stdbool.h>

int main() {
    int arr[] = {1, 2, 3, 2, 1}; // Example array
    int n = sizeof(arr) / sizeof(arr[0]);
    bool isPalindrome = true;

    for(int i = 0; i < n / 2; i++) {
        if(arr[i] != arr[n - i - 1]) {
            isPalindrome = false;
            break;
        }
    }

    if(isPalindrome) {
        printf("The array is a palindrome.\n");
    } else {
        printf("The array is not a palindrome.\n");
    }

    return 0;
}
// output
// The array is a palindrome.