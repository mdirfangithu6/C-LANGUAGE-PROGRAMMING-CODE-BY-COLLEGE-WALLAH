// 1:16:33+ or 1:18:22+ par code
// Ques : Take positive integer input and tell if it is divisible by 5 or 3 but not divisible by 15.

#include <stdio.h>

int main() {
    int n;
    printf("Enter a number : ");
    scanf("%d", &n);

    if (n % 5 == 0 || n % 3 == 0) {
        if (n % 15 != 0) {
            printf("The number is divisible by 5 or 3 but not 15.\n");
        } else if (n % 15 == 0) {
            printf("The number is divisible by 15.\n");
        }
    } else {
        printf("The number is not divisible by 3 or 5.\n");
    }

    return 0;
}
// output
// Enter a number : 10
// The number is divisible by 5 or 3 but not 15.

// Enter a number : 9
// The number is divisible by 5 or 3 but not 15.

// Enter a number : 15
// The number is divisible by 15.



// 1:20:37+ par code
//2nd tarika
#include<stdio.h>
int main(){
    int n;
    printf("enter a number : ");
    scanf("%d", &n);
    if((n%5==0 || n%3==0) && n%15!=0){
        printf("the number is divisible by 5 or 3 but not 15");
    } 
    else{
        printf("the number is not matching the required condition");
    }
    return 0;
}
// output
// enter a number