// 32:20+ par code
// Ques: If cost price and selling price of an item is input through the keyboard, write a program to determine whether the seller has made profit or incurred loss. Also determine how much profit he made or loss he incurred.

#include<stdio.h>
int main(){
    int cp; // dabba
    printf("Enter cost price : ");
    scanf("%d", &cp);
    int sp; // dabba
    printf("Enter selling price : ");
    scanf("%d", &sp);
    if(sp>cp) {
        printf("Profit");
    }
    if(cp>sp){
        printf("Loss");
    }
    return 0;

}
// output
// Enter cost price : 10
// Enter selling price : 12
// Profit

// Enter cost price : 100
// Enter selling price : 90
// Loss


// 33:04+ par code
#include<stdio.h>
int main(){
    int cp; // dabba
    printf("Enter cost price : ");
    scanf("%d", &cp);
    int sp; // dabba
    printf("Enter selling price : ");
    scanf("%d", &sp);
    if(sp>cp) {
        printf("Profit");
    }
    else{
        printf("Loss");
    }
    return 0;

}
// output
// Enter cost price : 10
// Enter selling price : 12
// Profit

// Enter cost price : 120
// Enter selling price : 110
// Loss

// Enter cost price : 100
// Enter selling price : 100
// Loss



// 40:30+ par code
#include<stdio.h>
int main(){
    int cp; // dabba
    printf("Enter cost price : ");
    scanf("%d", &cp);
    int sp; // dabba
    printf("Enter selling price : ");
    scanf("%d", &sp);
    if(sp>cp) {
        printf("Profit");
    }
    if(cp>sp){
        printf("Loss");
    }
    if(sp==cp){
        printf("No profit, no loss");
    }
    return 0;

}
// output
// Enter cost price : 10
// Enter selling price : 12
// Profit

// Enter cost price : 120
// Enter selling price : 110
// Loss

// Enter cost price : 100
// Enter selling price : 100
// No profit, no loss
