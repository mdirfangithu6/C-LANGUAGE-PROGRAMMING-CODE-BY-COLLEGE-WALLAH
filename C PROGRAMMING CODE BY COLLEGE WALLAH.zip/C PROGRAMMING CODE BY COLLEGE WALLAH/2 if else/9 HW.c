// 52:48+ par code
// Take positive integer input and tell if it is divisible by 5 and 3.
// by chatGPT
#include <stdio.h>

int main() {
    int num;
    // Prompt the user for input
    printf("Enter a positive integer: ");
    scanf("%d", &num);
    // Check if the number is positive
    if (num <= 0) {
        printf("Please enter a positive integer.\n");
        return 1; // Exit program with error code
    }
    // Check divisibility by 5 and 3
    if (num % 5 == 0 && num % 3 == 0) {
        printf("%d is divisible by both 5 and 3.\n", num);
    } else {
        printf("%d is not divisible by both 5 and 3.\n", num);
    }

    return 0; // Successful exit
}