//1:52:47+ 1:54:50+ par code 
// 21 Ques : Take input percentage of a student and print the Grade according to marks:
// 1) 91-100 Excellent
// 2) 81-90 Very Good
// 3) 71-80 Good
// 4) 61-70 Can do better
// 5) 51-60 Average
// 6) 41-50 Below Average
// 7) <40 Fail


// is code me ek problem hai

#include<stdio.h>
int main(){
    int n;
    printf("enter percentage :");
    scanf("%d", &n);
    //more than 80 -> A
    //more than 60 -> B
    //more than 40 -> C 
    //less than 40 -> D
    if(n>80){
        printf("A grade \n");
    }
    if(n>60){
        printf("B grade \n");
    }
    if(n>40){
        printf("C grade \n");
    }
    if(n<=40){
        printf("D grade n");
    }
    return 0;
}
// output
// enter percentage : 90
// A grade 
// B grade 
// C grade 




// 1:58:54+ par code
// sahih code

#include<stdio.h>
int main(){
    int n;
    printf("enter percentage :");
    scanf("%d", &n);
    //more than 80 -> A
    //more than 60 -> B
    //more than 40 -> C 
    //less than 40 -> D
    if(n>80){
        printf("A grade \n");
    }
    else if(n>60){
        printf("B grade \n");
    }
    else if(n>40){
        printf("C grade \n");
    }
    else{
        printf("D grade n");
    }
    return 0;
}
// output
// enter percentage :65
// B grade



// 2:00:25+ par code
// 2nd tareeka 

#include<stdio.h>
int main(){
    int n;
    printf("enter percentage :");
    scanf("%d", &n);
    //more than 80 -> A
    //more than 60 -> B
    //more than 40 -> C 
    //less than 40 -> D
    if(n > 80){
    printf("A grade\n");
    }
    else{
        if(n > 60){
            printf("B grade\n");
        }
        else{
            if(n > 40){
                printf("C grade\n");
            }
            else{
                printf("D grade\n");
            }
        }
    }
    return 0;
}
// output
// enter percentage :
