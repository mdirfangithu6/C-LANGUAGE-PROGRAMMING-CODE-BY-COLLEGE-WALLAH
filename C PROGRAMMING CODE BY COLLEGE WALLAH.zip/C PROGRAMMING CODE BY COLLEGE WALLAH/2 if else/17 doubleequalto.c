// 1:29:00+ par code
// 17: double equal to
#include<stdio.h>
int main(){
    int n = 7;
    if(n==2){
        printf("good morning");
    }
    else{
        printf("good evening");
    }
    return 0;
}
// output
// good evening