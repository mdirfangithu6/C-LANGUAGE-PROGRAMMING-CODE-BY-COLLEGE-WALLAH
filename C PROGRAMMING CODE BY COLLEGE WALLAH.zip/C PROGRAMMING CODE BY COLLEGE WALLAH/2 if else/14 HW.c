// 1:09:40+
// If the ages of Ram, Shyam and Ajay are input through the keyboard, write a program to determine the youngest of the three.
// by chatGPT

#include <stdio.h>

int main() {
    int ramAge, shyamAge, ajayAge;

    // Input the ages of Ram, Shyam, and Ajay
    printf("Enter the age of Ram: ");
    scanf("%d", &ramAge);

    printf("Enter the age of Shyam: ");
    scanf("%d", &shyamAge);

    printf("Enter the age of Ajay: ");
    scanf("%d", &ajayAge);

    // Determine the youngest
    if (ramAge < shyamAge && ramAge < ajayAge) {
        printf("Ram is the youngest.\n");
    } else if (shyamAge < ramAge && shyamAge < ajayAge) {
        printf("Shyam is the youngest.\n");
    } else if (ajayAge < ramAge && ajayAge < shyamAge) {
        printf("Ajay is the youngest.\n");
    } else {
        printf("Two or more people are of the same youngest age.\n");
    }

    return 0;
}