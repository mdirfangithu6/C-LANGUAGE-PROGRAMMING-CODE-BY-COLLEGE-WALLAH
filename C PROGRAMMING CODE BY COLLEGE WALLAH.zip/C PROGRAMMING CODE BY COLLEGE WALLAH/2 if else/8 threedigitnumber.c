// 49:00+ or 50:00+ par code
// Ques : Take positive integer input and tell if it is a three digit number or not.

#include<stdio.h>
int main(){
    int n;
    printf("enter a number : ");
    scanf("%d", &n);
    if(n>99 && n<1000){
        printf("It is a three digit number");
    }
    else{
        printf("It is not a three digit number");
    }
    return 0;
}
// output
// enter a number : 12
// It is not a three digit number

// enter a number : 998
// It is a three digit number