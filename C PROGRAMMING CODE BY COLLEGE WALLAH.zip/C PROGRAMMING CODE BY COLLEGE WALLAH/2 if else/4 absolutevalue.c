// 24:22+ or 26:10+ par coe
// Ques: Take integer input and print the absolute value of that integer

#include<stdio.h>
int main(){
    int n;
    printf("Enter a number : ");
    scanf("%d",&n);
    if(n<0){ // if n is negetive n = n * (-1);
        n=n*(-1);
    } 
    printf("The absolute value is : %d",n);
    return 0;

}
// output
// Enter a number : 7
// The absolute value is : 7

// Enter a number : -90
// The absolute value is : 90