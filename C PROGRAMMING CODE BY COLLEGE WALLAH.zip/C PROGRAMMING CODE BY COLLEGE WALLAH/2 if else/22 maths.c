// 2:03:30+ maths


// 2:03:36+ par code
// Ques: Given three points (x1, y1), (x2, y2) and (x3, y3), write a program to check if all the three points fall on one straight line.

// by chatGPT

#include <stdio.h>

// Function to check collinearity
int areCollinear(int x1, int y1, int x2, int y2, int x3, int y3) {
    // Using the area of triangle method
    int area = (x1*(y2 - y3) + x2*(y3 - y1) + x3*(y1 - y2));
    return area == 0;
}

int main() {
    int x1, y1, x2, y2, x3, y3;

    printf("Enter coordinates of first point (x1 y1): ");
    scanf("%d %d", &x1, &y1);

    printf("Enter coordinates of second point (x2 y2): ");
    scanf("%d %d", &x2, &y2);

    printf("Enter coordinates of third point (x3 y3): ");
    scanf("%d %d", &x3, &y3);

    if (areCollinear(x1, y1, x2, y2, x3, y3)) {
        printf("The points lie on the same straight line.\n");
    } else {
        printf("The points do not lie on the same straight line.\n");
    }

    return 0;
}