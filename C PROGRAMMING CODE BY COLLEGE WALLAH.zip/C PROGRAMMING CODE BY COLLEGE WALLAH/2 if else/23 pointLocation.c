//2:07:31+ par code
// Ques: Given a point (x, y), write a program to find out if it lies on the x-axis, y-axis or at the origin, viz. (0, 0).

#include<stdio.h>
int main(){
    int x, y;

    printf("Enter the coordinates : ");
    //scanf("%d",&x);
    //scanf("%d",&y);
    scanf("%d %d", &x, &y);

    if(y == 0){
        printf("Lies on x-axis");
    }
    else if(x == 0){
        printf("Lies on y-axis");
    }
    else{
        printf("The point is origin");
    }

    return 0;
}
// output
// Enter the coordinates : 4 0
// Lies on x-axis

// Enter the coordinates : 0 7
// Lies on y-axis

// Enter the coordinates : 0 0
// Lies on x-axis



// 2:12:40+ par code
// 2nd code
#include<stdio.h>
int main(){
    int x, y;
    printf("Enter the coordinates : ");
    //scanf("%d",&x);
    //scanf("%d",&y);
    scanf("%d %d", &x, &y);
    if(x==0 && y==0){
        printf("The point is origin");
    }
    else if(x==0){
        printf("Lies on y-axis");
    }
    else{
    printf("Lies on x-axis");
    }
    return 0;
}
// output
// Enter the coordinates : 0 0
// The point is origin

// Enter the coordinates : 5 6
// Lies on x-axis




// 2:41:18+ par code
// 3rd code
#include<stdio.h>
int main(){
    int x, y;
    printf("Enter the coordinates : ");
    //scanf("%d",&x);
    //scanf("%d",&y);
    scanf("%d %d",&x,&y);
    if(x==0 && y==0){
        printf("The point is origin");
    }
    else if(x==0){
        printf("Lies on y-axis");
    }
    else if(y==0){
    printf("Lies on x-axis");
    }
    else{
        printf("The point does not lie on x or y axis");
    }
    return 0;
}
// output
// Enter the coordinates : 