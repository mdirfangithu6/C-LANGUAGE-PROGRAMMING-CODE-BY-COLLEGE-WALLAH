// 53:58+ or 55:10+ par code
// Ques : Take positive integer input and if it is divisible by 5 or 3.

#include<stdio.h>
int main(){
    int n;
    printf("enter a number : ");
    scanf("%d", &n);
    if(n%5==0 || n%3==0){
        printf("the number is divisible by 5 or 3");
    }
    else{
        printf("the number is not divisible by 5 or 3");
    }
    return 0;
}
// output
// enter a number : 
// enter a number : 4
// the number is not divisible by 5 or 3

// enter a number : 10
// the number is divisible by 5 or 3