// 1:05:11+ par code
// Take 3 numbers input and tell if they can be the sides of a triangle.
#include <stdio.h>

int main() {
    int a, b, c;

    printf("Enter 1st side: ");
    scanf("%d", &a);

    printf("Enter 2nd side: ");
    scanf("%d", &b);  // <-- This was missing

    printf("Enter 3rd side: ");
    scanf("%d", &c);

    if ((a + b > c) && (b + c > a) && (c + a > b)) {
        printf("Valid triangle");
    } else {
        printf("Invalid triangle");
    }

    return 0;
}
// output
// Enter 1st side: 3
// Enter 2nd side: 4
// Enter 3rd side: 5
// Valid triangle


// Enter 1st side: 3
// Enter 2nd side: 4
// Enter 3rd side: 7
// InValid triangle