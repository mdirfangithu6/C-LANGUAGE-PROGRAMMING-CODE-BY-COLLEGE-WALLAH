// 20:51+ par code
// Ques : Take positive integer input and tell if it is divisible by 5 or not.


#include<stdio.h>
int main(){
    int n;
    printf("Enter a  number :");
    scanf("%d", &n);
    if(n%5==0){
        printf("Divisible by 5");
    }
    else{
        printf("NOt divisible by 5");
    }
    return 0;
}
// output
// Ente ra number : 10
// Divisible by 5