// 2:15:22+ Ternary Operator


// 2:16:20+ par code
#include<stdio.h>
int main(){
    int n;
    printf("Enter a number : ");
    scanf("%d", &n);
    // ternary operator
    //exp1 ? exp2 : exp3

    //n%2==0 ? printf("Even number"): printf("Odd number");

    if(n%2==0){
        printf("Even number");
    }
    else{
        printf("Odd number");
    }
    
}
// output
// Enter a number : 4
// Even number


// Enter a number : 5
// Odd number