// 1:39:04+ or 1:41:08+ par code
// Ques : Take 3 positive integers input and print the greatest of them.

#include<stdio.h>
int main(){
    int a,b,c;
    printf("Enter 1st number : ");
    scanf("%d", &a);
    printf("Enter 2nd number : ");
    scanf("%d", &b);
    printf("Enter 3rd number : ");
    scanf("%d", &c);
    if (a > b){ // b is out of race
        if(a>c){
            printf("%d is greatest", a);
        }
        else{
            printf("%d is greatest", c);
        }
    }
    else{
        if(b>c){
            printf("%d is greatest", b);
        }
        else{
            printf("%d is greatest", c);
        }
    }
    return 0;

}
// output
// Enter 1st number : 3
// Enter 2nd number : 6
// Enter 3rd number : 1
// 6 is greatest