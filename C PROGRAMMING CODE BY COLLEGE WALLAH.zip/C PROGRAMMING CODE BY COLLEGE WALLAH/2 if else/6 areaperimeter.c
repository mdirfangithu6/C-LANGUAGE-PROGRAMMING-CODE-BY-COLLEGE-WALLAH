// 41:38+ 42:46+ par code
// Ques: Given the length and breadth of a rectangle, write a program to find whether the area of the rectangle is greater than its perimeter.

#include<stdio.h>

int main(){
    int l;
    printf("Enter length : ");
    scanf("%d", &l);
    int b;
    printf("Enter breath : ");
    scanf("%d", &b);
    int area = l*b;
    int perimeter = 2 *(l+b);
    if(area>perimeter){
        printf("Area is greater than perimeter");
    }
    else{
        printf("Area is not greater than perimeter");
    }
    return 0;
}
// output
// Enter length : 10
// Enter breath : 3
// Area is greater than perimeter