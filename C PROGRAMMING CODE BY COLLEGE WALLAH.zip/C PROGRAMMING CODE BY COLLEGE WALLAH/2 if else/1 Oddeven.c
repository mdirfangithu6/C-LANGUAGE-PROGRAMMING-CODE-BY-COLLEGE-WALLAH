// 2:10+ par code
// Ques: Take position integer input and tell if it is even or odd
#include<stdio.h>
int main(){
    int n;
    printf("Enter a  number :");
    scanf("%d", &n);
    if(n%2==0){
        printf("Even number");
    }
    return 0;
}
// output
// Enter a  number : 6
// Even number



// 14:14+ par code
#include<stdio.h>
int main(){
    int n;
    printf("Enter a  number :");
    scanf("%d", &n);
    if(n%2==0){
        printf("Even number");
    }
    if(n%2!=0){
        printf("Odd number");
    }
    return 0;
}
// output
// Enter a  number : 7
// Odd number
    

//19:40+ par code
#include<stdio.h>
int main(){
    int n;
    printf("Enter a  number :");
    scanf("%d", &n);
    if(n%2==0){
        printf("Even number");
    }
    else{
        printf("Odd number");
    }
    return 0;
}
// output
// Enter a  number :