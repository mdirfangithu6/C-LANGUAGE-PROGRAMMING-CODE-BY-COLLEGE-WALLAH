// 57:00+ or 59:27+ par code
// *Ques : Take 3 positive integers input and print the greatest of them.

#include <stdio.h>

int main() {
    int a, b, c;

    printf("Enter 1st number : ");
    scanf("%d", &a);

    printf("Enter 2nd number : ");
    scanf("%d", &b);

    printf("Enter 3rd number : ");
    scanf("%d", &c);

    if (a > b && a > c) {
        printf("%d is greatest\n", a);
    } else if (b > a && b > c) {
        printf("%d is greatest\n", b);
    } else if (c > a && c > b) {
        printf("%d is greatest\n", c);
    } else {
        printf("There is a tie.\n");
    }

    return 0;
}
// output
// Enter 1st number : 2
// Enter 2nd number : 3
// Enter 3rd number : 4
// 4 is greatest