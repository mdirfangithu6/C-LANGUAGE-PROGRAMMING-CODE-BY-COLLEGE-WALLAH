// 1:04:05+ par code
//Take 4 positive integers input and print the greatest of them.
// by chatGPT
#include <stdio.h>

int main() {
    int a, b, c, d, greatest;

    // Taking input for the four positive integers
    printf("Enter four positive integers: ");
    scanf("%d %d %d %d", &a, &b, &c, &d);

    // Assuming the first number is the greatest
    greatest = a;

    // Comparing with the rest of the numbers
    if (b > greatest) {
        greatest = b;
    }
    if (c > greatest) {
        greatest = c;
    }
    if (d > greatest) {
        greatest = d;
    }

    // Printing the greatest number
    printf("The greatest number is: %d\n", greatest);

    return 0;
}