// 44:50+

#include<stdio.h>
int main(){
    int n; //4 bytes
    printf("Enter array's size : ");
    scanf("%d", &n);
    int arr[n]; // n*4
    for(int i=0; i<n; i++){
        scanf("%d", &arr[i]);
    }
    for(int i=0; i<n; i++){
        printf("%d ", arr[i]);
    }
}



// 54:00+ par code
#include<stdio.h>
int main(){
    int n; //4 bytes
    printf("Enter array's size : ");
    scanf("%d", &n);
    // int arr[n]; // n*4
    int* arr = new int[n];
    for(int i=0; i<n; i++){
        scanf("%d", &arr[i]);
    }
    for(int i=0; i<n; i++){
        printf("%d ", arr[i]);
    }
}




// 57:12+ par code
#include<stdio.h>
int main(){
    int a = sizeof(int);
    printf("%d",a);

}
// 
#include<stdio.h>
int main(){
    int a = sizeof(float);
    printf("%d",a);

}
// 
#include<stdio.h>
int main(){
    int a = sizeof(double);
    printf("%d",a);

}
// #include<stdio.h>
int main(){
    int a = sizeof(char);
    printf("%d",a);

}
// 
#include<stdio.h>
#include<stdbool.h>
int main(){
    int a = sizeof(bool);
    printf("%d",a);

}




// 1:00:25+ par code
#include<stdio.h>
#include<stdbool.h>
int main(){
    int* ptr = (int*) malloc(10*4);
    printf("%d", *ptr);
    ptr++;
    printf("%d", *ptr);
    ptr++;
    printf("%d", *ptr);
}