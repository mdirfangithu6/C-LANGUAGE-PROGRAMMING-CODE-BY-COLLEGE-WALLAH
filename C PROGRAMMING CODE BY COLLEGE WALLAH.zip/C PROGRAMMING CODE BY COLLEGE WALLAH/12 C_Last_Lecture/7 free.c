// 1:17:37+

#include<stdio.h>
#include<stdlib.h>
int main(){
    int x = 9;
    int* ptr = NULL;
    printf("%p", ptr);
}

// 1:21:43+ par code
#include<stdio.h>
#include<stdlib.h>
int main(){
    // int x = 9;
    // int* ptr = NULL;
    // printf("%p", ptr);
    int* ptr = (int*) calloc(10,4);
    int* p = ptr;
    p++;
    free(ptr);
}
// 1:22:40+ ya fir
#include<stdio.h>
#include<stdlib.h>
int main(){
    // int x = 9;
    // int* ptr = NULL;
    // printf("%p", ptr);
    int* ptr = (int*) calloc(10,4);
    int* p = ptr; // starting pe set kar diya
    ptr--;
    free(p);
}
