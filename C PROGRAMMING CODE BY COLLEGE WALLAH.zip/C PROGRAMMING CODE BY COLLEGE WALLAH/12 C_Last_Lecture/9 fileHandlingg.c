// 1:36:44+

#include<stdio.h>
int main(){
    FILE* ptr = fopen("irfan.txt", "r");
    char str[100];
    while(fgets(str, 100, ptr) != NULL){
        printf("%s", str);
    }
}
// output
// Hi. My name is irfan
// and, I tech Mathematics



// 1:42:57+ par code
// creating a file
#include<stdio.h>
int main(){
    FILE* ptr = fopen("Pw.txt", "w");
}



// 1:43:35+ par code
#include<stdio.h>
int main(){
    FILE* ptr = fopen("CW.txt", "w");
    char str[] = "Placement lagegi yahi se";
    fputs(str, ptr);
    fclose(ptr);
}