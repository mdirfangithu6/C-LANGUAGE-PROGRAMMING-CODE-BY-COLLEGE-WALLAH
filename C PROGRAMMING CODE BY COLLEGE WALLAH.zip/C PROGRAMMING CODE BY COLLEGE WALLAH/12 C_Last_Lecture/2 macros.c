// 16:02+ or 18:30+ par code
#include<stdio.h>
#define PI 3.14159265359
int main(){
    double x = 3.14159265359;
    printf("%lf", x);
    // float -> 6 decimal places
}

// 20:24+ par code
#include<stdio.h>
#define PI 3.14159265359
int main(){
    double x = 3.14159265359;
    printf("%.11f", x);
    // float -> 6 decimal places
}

// 21:40+ par code
#include<stdio.h>
#define PI 3.14159265359
int main(){
    long double x = 3.14159265359;
    printf("%.17Lf", x);
    // float -> 6 decimal places
}



// 22:56+ par code
#include<stdio.h>
#define PI 3.14159265359
float area (float r){
    return PI*r*r;
}
int main(){
    printf("%f", area(5.3));
}
// output


// 24:20+ par Marcro Functions
#include<stdio.h>
#define PI 3.14159265359
#define area(r) (PI*r*r)
// float area (float r){
//     return PI*r*r;
// }
int main(){
    printf("%f", area(5.3));
}