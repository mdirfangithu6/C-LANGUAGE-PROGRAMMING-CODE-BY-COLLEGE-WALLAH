// 25:27+
// Ques : Write a program to input week number(1-7) and print day of week name using switch case. 

#include<stdio.h>
int main(){
    int n;
    printf("enter day number (1-7) : ");
    scanf("%d", &n);
    switch (n){
        case 1:
            printf("Monday\n");
            break;
        case 2:
            printf("Tuesday\n");
            break;
        case 3:
            printf("Wednesda\ny");
            break;
        case 4:
            printf("Thusday\n");
            break;
        case 5:
            printf("Friday\n");
            break;
        case 6:
            printf("Saturday\n");
            break;
        case 7:
            printf("Sanday\n");
            break;
        default:
            pritf("Invalid Number")
    }  
}
// output