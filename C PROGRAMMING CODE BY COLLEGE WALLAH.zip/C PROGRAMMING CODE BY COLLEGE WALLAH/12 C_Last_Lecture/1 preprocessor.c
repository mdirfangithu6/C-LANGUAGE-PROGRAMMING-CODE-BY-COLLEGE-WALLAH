// 4:40+ par code
#include<stdio.h>
int main(){
    printf("hello");
}

// 7:00+ par code
#include<stdio.h>
#include<math.h>
int main(){
    float x = sqrt(2);
    printf("%f", x);
}
// output
// 1.414214


// 8:00+ par code
#include<stdio.h>
#include<math.h>
int main(){
    float x = cbrt(8);
    printf("%f", x);
}
// output
// 2


// 8:40+ par
#include<stdio.h>
#include<math.h>
int main(){
    int x = __INT_MAX__;
    printf("%d", x);
    // 2147483647
}
// output
// 2147483647

// 10:30+ par code
#include<stdio.h>
#include<math.h>
int main(){
    int x = __INT_MAX__;
    int y = 2147483647;
    printf("%d", y);
    // 2147483647
}
// output


// 10:56+ par code
#include<stdio.h>
#include<math.h>
int main(){
    int x = __INT_MAX__;
    long y = 2147483648;
    printf("%ld", y);
    // 2147483647
}
// output
// 2147483648

// 13:30+ par code
#include<stdio.h>
#include<math.h>
#include<limits.h>
int main(){
    int x = INT_MAX; //INT_MIN
    printf("%d", x);
    // 2147483647
}
// output
// 2147483647


// 15:13+ par code
#include<stdio.h>
#include<math.h>
#include<limits.h>
int main(){
    int x = INT_MAX;
    long y = LONG_MAX;
    // 9223372036854775807
    printf("%ld", y); 
    // 2147483647
}