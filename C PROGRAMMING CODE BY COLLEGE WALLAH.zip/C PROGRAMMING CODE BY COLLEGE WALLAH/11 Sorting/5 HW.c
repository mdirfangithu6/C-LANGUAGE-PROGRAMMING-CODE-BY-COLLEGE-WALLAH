// 3:55:46+
// HW: Given an integer array and an integer k where k <= size of array, We need to return the kth smallest element of the array.
// by chatGPT

#include <stdio.h>

// Function to sort the array (using Bubble Sort for simplicity)
void sort(int arr[], int n) {
    for (int i = 0; i < n-1; i++) {
        for (int j = 0; j < n-i-1; j++) {
            if (arr[j] > arr[j+1]) {
                // Swap
                int temp = arr[j];
                arr[j] = arr[j+1];
                arr[j+1] = temp;
            }
        }
    }
}

// Function to return kth smallest element
int kthSmallest(int arr[], int n, int k) {
    sort(arr, n);
    return arr[k-1]; // k-1 because of 0-based indexing
}

int main() {
    int arr[] = {12, 3, 5, 7, 19};
    int n = sizeof(arr)/sizeof(arr[0]);
    int k = 2;

    int result = kthSmallest(arr, n, k);
    printf("The %dth smallest element is %d\n", k, result);

    return 0;
}