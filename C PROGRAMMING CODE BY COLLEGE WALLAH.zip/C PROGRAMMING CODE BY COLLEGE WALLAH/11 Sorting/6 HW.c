// 3:58:08+
// Ques: Given an array of digits (values are from 0 to 9), the task is to find the minimum possible sum of two numbers formed from digits of the array.
// Please note that all digits of the given array must be used to form the two numbers.
// by chatGPT

#include <stdio.h>
#include <stdlib.h>

// Function to compare two integers for qsort
int compare(const void *a, const void *b) {
    return (*(int *)a - *(int *)b);
}

// Function to find the minimum possible sum
int minSum(int arr[], int n) {
    // Sort the digits
    qsort(arr, n, sizeof(int), compare);

    // Form two numbers using alternate digits
    int num1 = 0, num2 = 0;
    for (int i = 0; i < n; i++) {
        if (i % 2 == 0)
            num1 = num1 * 10 + arr[i];
        else
            num2 = num2 * 10 + arr[i];
    }

    return num1 + num2;
}

int main() {
    int arr[] = {6, 8, 4, 5, 2, 3};
    int n = sizeof(arr) / sizeof(arr[0]);

    int result = minSum(arr, n);
    printf("The minimum possible sum is %d\n", result);

    return 0;
}