// 3:36:41+ or 3:40:27+
// Ques : Given an integer array arr, move all 0's to the end odf it while maintaining the relative order of the non_zero element

#include<stdio.h>
int main() {
    int arr[9] = {5, 0, 2, 0, 0, 4, 1, 3, 0};
    int ans[9];
    int idx = 0;
    for(int i=0; i<9; i++) {
        if(arr[i] != 0) {
            ans[idx] = arr[i];
            idx++;
        }
    }
    
    for(int i=0; i<9; i++) {
        printf("%d ", ans[i]);
    }
    
    return 0;
}
// output
// garbage value aa raha hai


// 3:43:55+ par code
#include<stdio.h>
int main() {
    int arr[9] = {5, 0, 2, 0, 0, 4, 1, 3, 0};
    int ans[9];
    int idx = 0;
    for(int i=0; i<9; i++) {
        if(arr[i] != 0) {
            ans[idx] = arr[i];
            idx++;
        }
    }
    while (idx!=9){
        ans[idx] = 0;
        idx++;
    }
    
    for(int i=0; i<9; i++) {
        printf("%d ", ans[i]);
    }
    
    return 0;
}
// output
// 5 2 4 1 3 0 0 0 0






// 3:46:50+ par code
// Ques: Given an integer array arr, move all 0's to the end of it while maintaining the relative order of the non-zero elements.
// Note that you must do this in-place without making a copy of the array.
#include<stdio.h>
#include <stdbool.h>
int main() {
    int arr[9] = {5, 0, 2, 0, 0, 4, 1, 3, 0};
    int n = 9;
    printf("\n Original Array : \n");
    for(int i=0; i<9; i++) {
        printf("%d ", arr[i]);
    }
    // int ans[9];
    // int idx = 0;
    // for(int i=0; i<9; i++) {
    //     if(arr[i] != 0) {
    //         ans[idx] = arr[i];
    //         idx++;
    //     }
    // }
    // while (idx!=9){
    //     ans[idx] = 0;
    //     idx++;
    // }
    // pusing zeros in place
    for(int i=0; i<n-1; i++) {
        for(int j=0; j<n-1-i; j++) { 
            if(arr[j]==0) {
                int temp = arr[j];
                arr[j] = arr[j+1];
                arr[j+1] = temp;
                flag = false;
            }
        }
    }
    printf("\n Pushed the zeroe : \n");
    for(int i=0; i<9; i++) {
        printf("%d ", arr[i]);
    }
    
    return 0;
}
// output
// Original Array 
// 5 0 2 0 0 4 1 3 0
// Pushed the zeroe
// 5 2 4 1 3 0 0 0 0 