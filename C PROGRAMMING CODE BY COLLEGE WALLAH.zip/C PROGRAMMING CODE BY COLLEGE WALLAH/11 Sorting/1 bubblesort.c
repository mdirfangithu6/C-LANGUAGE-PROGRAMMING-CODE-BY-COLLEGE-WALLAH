// 1:32:02+ par code

#include <stdio.h>

int main() {
    int arr[5] = {5, 4, 3, 2, 1};
    int n = 5;

    for(int i=0; i<=n; i++) {
        printf("%d ", arr[i]);
    }

    // Bubble sort
    for(int i=0; i<n-1; i++) {
        for(int j=0; j<n-2; j++) {
            if(arr[j] > arr[j + 1]) {
                int temp = arr[j];
                arr[j] = arr[j+1];
                arr[j+1] = temp;
            }
        }
    }
    printf("\n");
    for(int i=0; i<n; i++) {
        printf("%d ", arr[i]);
    }

    return 0;
}
// output
// 5 4 3 2 1
// 1 2 3 4 5 





// 1:53:00+ par code
#include <stdio.h>
#include <stdbool.h>

int main() {
    int arr[5] = {5, 4, 3, 2, 1};
    int n = 5;  

    for(int i = 0; i < n; i++) {
        printf("%d", arr[i]);
    }
    // bubble sort
    for(int i = 0; i < n - 1; i++) {
        bool flag = true;  // array is not sorted yet
        for(int j = 0; j < n - 1 - i; j++) {
            if(arr[j] > arr[j + 1]) {
                int temp = arr[j];
                arr[j] = arr[j + 1];
                arr[j + 1] = temp;
                flag = false; 
            }
        }
        if(flag == true) break; 
    }

    printf("\n");
    for(int i = 0; i < n; i++) {
        printf("%d ", arr[i]);
    }

    return 0;
}
// output
// 54321
// 1 2 3 4 5 



// HW 
// Bubble sort -> Unsorted array -> ascending order
// like-> 3 2 5 1 4 -> 5 4 3 2 1 
// & 
// sort in descendng order 