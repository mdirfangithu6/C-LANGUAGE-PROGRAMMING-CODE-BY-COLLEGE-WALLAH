// 1:48:30+ par code
#include<stdio.h>
#include<string.h>
int main(){
    char* str = "Irfan";
    int x = strlen(str);
    printf("%d",x);
    return 0;
}
// output
// 5



// 1:50:50+ par code
#include <stdio.h>
#include <string.h>

int my_strlen(char *ptr) {
    int len = 0;
    while (*ptr != '\0') {
        len++;
        ptr++;
    }
    return len;
}

int main() {
    char s1[12] = "Irfan";
    char s2[12];
    strcpy(s2, s1);
    printf("%s", s2);
    return 0;
}
// output
// Irfan



// 1:52:17+ par code
#include <stdio.h>
#include <string.h>

int my_strlen(char *ptr) {
    int len = 0;
    while (*ptr != '\0') {
        len++;
        ptr++;
    }
    return len;
}

int main() {
    char s1[12] = "Irfan";
    char s2[12];
    strcpy(s2, s1);
    s2[0] = 'M';
    printf("%s", s2);
    return 0;
}
// output
// Mrfan


// 1:52:50+ par code
// s1 print
#include <stdio.h>
#include <string.h>

int my_strlen(char *ptr) {
    int len = 0;
    while (*ptr != '\0') {
        len++;
        ptr++;
    }
    return len;
}

int main() {
    char s1[12] = "Irfan";
    char s2[12];
    strcpy(s2, s1);
    s2[0] = 'M';
    printf("%s", s1);
    return 0;
}
// output
// Irfan


// 1:53:53+ par code
#include <stdio.h>
#include <string.h>

int my_strlen(char *ptr) {
    int len = 0;
    while (*ptr != '\0') {
        len++;
        ptr++;
    }
    return len;
}

int main() {
    char s1[] = "Irfan";
    char s2[] = "Gabriel"
    strcat(s1, s2);
    printf("%s", s1);
    return 0;
}
// output
// error


// 1:55:50+ par code
#include <stdio.h>
#include <string.h>

int my_strlen(char *ptr) {
    int len = 0;
    while (*ptr != '\0') {
        len++;
        ptr++;
    }
    return len;
}

int main() {
    char s1[20] = "Irfan";  
    char s2[] = "Gabriel"; 
    strcat(s1, s2);
    printf("%s", s1);
    return 0;
}
// output
// IrfanGabriel


// 1:56:14+ par code
#include <stdio.h>
#include <string.h>

int my_strlen(char *ptr) {
    int len = 0;
    while (*ptr != '\0') {
        len++;
        ptr++;
    }
    return len;
}

int main() {
    char* s1 = "Irfan";  //read only
    char* s2 = "Gabriel"; //read only
    strcat(s1, s2);
    printf("%s", s1);
    return 0;
}
// output
// error



// 1:57:15+ par code
// Inserting a charater in a string
// Write a function to insert a new character in a string at a given position.
#include <stdio.h>
#include <string.h>

int my_strlen(char *ptr) {
    int len = 0;
    while (*ptr != '\0') {
        len++;
        ptr++;
    }
    return len;
}

int main() {
    char str[20] = "College";
    printf("%s\n", str);
    // 2nd inder pe 'l'
    for(int i = 6; i>=2; i--){
        str[i+1] = str[i];
    }
    str[2] = 'K';
    printf("%s", str);
    return 0;
}
// output
// College
// CoKllege