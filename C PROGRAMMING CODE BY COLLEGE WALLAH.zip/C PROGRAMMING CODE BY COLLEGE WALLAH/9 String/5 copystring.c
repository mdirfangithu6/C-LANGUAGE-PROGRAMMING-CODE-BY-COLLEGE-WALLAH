// 1:38:10+
#include<stdio.h>
#include<string.h>

int main(){
    char s1[] = "Physics Wallah";
    char* s2 = s1;
    s1[0] = 'M';
    printf("%s", s2);
    return 0;
}
// output
// Mhysic Wallah


// 1:41:36+
#include<stdio.h>
#include<string.h>

int main(){
    char s1[] = "Physics Wallah";
    // char* s2 = s1; // s2 is a shallow copy
    // s1[0] = 'M';
    // printf("%s", s2);
    char s2[] =  "Physics Wallah";
    s2[0] = 'M';
    printf("%s", s1);
    printf("%s", s2);
    return 0;
}
// output
// Physics Wallah
// Mhysics Wallah


// address
#include<stdio.h>
#include<string.h>

int main(){
    char s1[] = "Physics Wallah";
    // char* s2 = s1; // s2 is a shallow copy
    // s1[0] = 'M';
    // printf("%s", s2);
    char s2[] =  "Physics Wallah";
    // s2[0] = 'M';
    printf("%p\n", s1);
    printf("%p", s2);
    return 0;
}
// jhfdyjsdfdyfud8
// jhfdyjsdfdyfud8




// hW




// 1:44:33+
#include<stdio.h>
#include<string.h>

int main(){
    char s1[] = "Physics Wallah";
    // 
    // char* s2 = s1; // s2 is a shallow copy
    // s1[0] = 'M';
    // printf("%s", s2);
    char s2[] = s1;
    // s2[0] = 'M';
    printf("%p\n", s1);
    printf("%p", s2);
    return 0;
}

#include<stdio.h>
#include<string.h>

int main(){
    char s1[] = "Physics Wallah";
    // 
    // char* s2 = s1; // s2 is a shallow copy
    // s1[0] = 'M';
    // printf("%s", s2);
    char s2[15];
    s2 = s1;
    // s2[0] = 'M';
    printf("%p\n", s1);
    printf("%p", s2);
    return 0;
}
// pointer rakhu 1:45:38+
#include<stdio.h>
#include<string.h>

int main{
    char* s1[] = "Physics Wallah";
    // 
    // char* s2 = s1; // s2 is a shallow copy
    // s1[0] = 'M';
    // printf("%s", s2);
    char* s2;
    s2 = s1;
    // s2[0] = 'M';
    printf("%s\n", s1);
    printf("%s", s2);
    return 0;
}
// physics Wallah
// physics Wallah


// 1:46:08+
#include<stdio.h>
#include<string.h>

int main{
    char* s1[] = "Physics Wallah";
    // 
    // char* s2 = s1; // s2 is a shallow copy
    // s1[0] = 'M';
    // printf("%s", s2);
    char* s2;
    s2 = s1;
    s2 =  "College Wallah";
    // s2[0] = 'M';
    printf("%s\n", s1);
    printf("%s", s2);
    return 0;
}
// physics Wallah
// College Wallah