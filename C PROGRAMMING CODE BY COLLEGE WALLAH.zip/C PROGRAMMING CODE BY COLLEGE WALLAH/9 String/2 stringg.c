// 27:51+
#include<stdio.h>
int main(){
    char ch[] = "Hello";
    return 0;
}
// Hello




// 28:33+
#include<stdio.h>
int main(){
    char arr[] = "Hello";
    int i = 0;
    whie(i<5){
        printf("%c",arr[i]);
        i++;
    }
    return 0;
}
// Hello




// 29:29+
#include<stdio.h>
int main(){
    char arr[] = "Collage Wallah";
    int i = 0;
    while(i<14){
        printf("%c",arr[i]);
        i++;
    }
    return 0;
}
// Collage Wallah




// 30:00+
#include<stdio.h>
int main(){
    char arr[] = "collage wallah is best\0";
    int i = 0;
    while(arr[i]!='\0'){
        printf("%c",arr[i]);
        i++;
    }
    return 0;
}
// collage wallah is best



//36:25+
#include<stdio.h>
int main(){
    char arr[20] = "collagewallah\0";

    int i = 0;
    while(arr[i]!='\0'){
        printf("%c",arr[i]);
        i++;
    }
    return 0;
}
// collagewallah




// 40:45+
#include<stdio.h>
int main(){
    char str[20] = "collegewallah";
    str[1] = 98; //'b';
    int i =0;
    while(str[i]!='\0'){
        printf("%c",str[i]);
        i++;
    }
    return 0;
}
// cbllegewallah
#include<stdio.h>
int main(){
    char str[20] = "collegewallah";
    str[1] = 98; //'b';
    int i =0;
    while(str[i]!='\0'){
        printf("%c",i[str]);
        i++;
    }
    return 0;
}
// cbllegewallah



//43:11+
#include<stdio.h>
int main(){
    char str[20] = "collegewallah";
    int i = 0;
    while(str[i]!='\0'){
        printf("%c",*(str+i)); //*(i+str));
        i++;
    }
    return 0;
}
// collegewallah



//44:16+
#include<stdio.h>
int main(){
    char str[] = "Hello!";
    //char arr[] = {'H','e', 'l','l','o','!'}; // size = 6;
    // str[1] = 'b';
    int i = 0;
    while(str[i]!='\0'){
        printf("%c",str[i]);
        i++;
    }
    return 0;
}
// Hello!


//48:00+
#include<stdio.h>
#include<string.h>
int main(){
    char str[] = "College wallah is best";
    printf("%s",str);
    return 0;
}
// College wallah is best




//50:10+
#include<stdio.h>
#include<string.h>
int main(){
    char str[] = "College wallah is best";
    puts(str);
    return 0;
}
// College wallah is best



// 50:38+
#include<stdio.h>
#include<string.h>
int main(){
    char str[] = "collegewallah";
    puts("hello Everyone");
    return 0;
}
// hello Everyone




//51:22+
#include<stdio.h>
#include<string.h>
int main(){
    char str[40];
    // scanf("%s", str); // only the forst word sill be considered

    gets(str); // entire sentence can be input
    printf("your input was : %s",str);
    return 0;
}
// 


// 55:32+
#include<stdio.h>
#include<string.h>
int main(){
    char str[40];
    scanf("%[^\n]s", str); // only the forst word sill be considered

    // gets(str); // entire sentence can be input
    printf("your input was : %s",str);
    return 0;
}
// 