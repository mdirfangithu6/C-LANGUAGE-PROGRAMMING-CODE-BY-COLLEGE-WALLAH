// 1:08:44+ par code
#include<stdio.h>
#include<string.h>

int main(){
    char str[] = "College Wallah";
    char* ptr = &str[0];
    printf("%p", ptr);
    return 0;
}
// output
// 0x7ffcf3de5439


// 1:10:45+ par code
#include<stdio.h>
#include<string.h>

int main(){
    char str[] = "College Wallah";
    //char* ptr = &str[0];
    printf("%p\n", &str[0]);
    printf("%p", str);
    return 0;
}
// output
// 0x7fff4776e4b1
// 0x7fff4776e4b1



// 1:12:22+ par code
#include<stdio.h>
#include<string.h>

int main(){
    char str[] = "College Wallah";
    char* ptr = str; // ptr now points tp str[0]
    printf("%p\n", &str[0]);
    printf("%p", str);
    return 0;
}
// output
// 0x7fff00937bc9
// 0x7fff00937bc9



// 1:13:13+ (loop se throw karna hai string ko)
#include<stdio.h>
#include<string.h>

int main(){
    char str[] = "College Wallah";
    char* ptr = str; // ptr now points to str[0]
    int i = 0;
    while(str[i]!='\0'){
        printf("%c",str[i]);
        i++;
    }
    return 0;
}
// output
// College Wallah



// 1:14:20+ par code
#include<stdio.h>
#include<string.h>

int main(){
    char str[] = "College Wallah";
    char* ptr = str; // ptr now points to str[0]
    int i = 0;
    while(*ptr!='\0'){
        printf("%c",*ptr);
        ptr++;
        i++;
    }
    return 0;
}
// output
// College Wallah



// 1:23:18+ par code
#include<stdio.h>
#include<string.h>

int main(){
    char str[] = "College Wallah";
    // char* ptr = str; // ptr now points to str[0]
    // int i = 0;
    // while(str[i]!='\0'){
    //     printf("%c",str[i]);
    //     i++;
    // }

    str[0] = 'D';
    printf("%s", str);
    return 0;
}
// output
// Dollege Wallah


// 1:24:06+ par code
#include<stdio.h>
#include<string.h>

int main(){
    char str[] = "College Wallah";
    // char* ptr = str; // ptr now points to str[0]
    // int i = 0;
    // while(str[i]!='\0'){
    //     printf("%c",str[i]);
    //     i++;
    // }

    char* ptr = "College Wallah";
    printf("%s", ptr);
    return 0;
}
// output
// College Wallah




// 1:26:30+ par code
#include<stdio.h>
#include<string.h>

int main(){
    char str[] = "College Wallah";
    str = "Physics Wallah"; // This line will cause an error
    printf("%s", str);
    return 0;
}




//1:27:22+ (lekin char by char me kar sakta hu)
#include<stdio.h>
#include<string.h>

int main(){
    char str[] = "College Wallah";
    str[0] = 'P';
    printf("%s", str);
    return 0;
}
// output
// Pollege Wallah


// 1:28:58+ pointer 
#include<stdio.h>
#include<string.h>

int main(){
    char* ptr = "College Wallah";
    ptr = "Physics Wallah";
    printf("%s", ptr);
    return 0;
}
// output
// Physics Wallah


// 1:30:57+
#include<stdio.h>
#include<string.h>

int main(){
    char str[] = "College Wallah";
    char* ptr = str;
    ptr = "Physics Wallah";
    printf("%s", str);
    return 0;
}
// output
// college Wallah



// 1:33:33+ par code
#include<stdio.h>
#include<string.h>

int main(){
    char str[] = "College Wallah";
    // char* ptr = str;
    // ptr = "Physics Wallah";
    char* p = str;
    *p = 'P';
    printf("%s", str);
    return 0;
}
// Pollege Wallah