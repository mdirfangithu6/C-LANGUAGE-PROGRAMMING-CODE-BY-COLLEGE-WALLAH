// 56:56+ 1:00:15+ par code
// Reverse a string

#include<stdio.h>
#include<string.h>
int main(){
    char str[40];
    puts("Enter a string");
    gets(str);
    puts("The reverse is : ");
    puts(str);
    return 0;
}
// output
// 


// 1:01:33+
#include<stdio.h>
#include<string.h>
int main(){
    char str[15];
    puts("Enter a string");
    scanf("%[^\n]s", str); 
    puts("The reverse is : "); // automatically \n bhi de deta hai 

    puts(str);
    return 0;
}
// output
// Enter a string
// irfan
// The reverse is : 
// irfan



// 1:02:25+ par code
#include<stdio.h>
#include<string.h>
int main(){
    char str[40];
    puts("Enter a string");
    scanf("%[^\n]s", str); 
    puts("The size is : "); // automatically \n bhi de deta hai 
    // size
    int size = 0;
    int i = 0;
    while (str[i]!='\0'){
        size++;
        i++;
    }
    printf("%d", size);
    return 0;
}
// output
// Enter a string
// irfan
// The size is : 
// 5



// 1:04:47+ par code
// main code 
#include<stdio.h>
#include<string.h>
int main(){
    char str[40];
    puts("Enter a string");
    scanf("%[^\n]s", str); 
    // size
    int size = 0;
    int k = 0;
    while (str[k]!='\0'){
        size++;
        k++;
    }
    for(int i=0; j=size-1; i<=j; i++; j--){
        char temp = str[i];
        str[i] = str[j];
        str[j] = temp;
    }
    puts("The reverse string is : ");
    puts(str);
    return 0;
}
// output
// Enter a string
// irfan
// The reverse string is : 
// nafri