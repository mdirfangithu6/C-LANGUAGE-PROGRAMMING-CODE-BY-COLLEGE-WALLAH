// 4:00+ par code
#include<stdio.h>
int main(){
    char arr[5] = {'a','t','l','a','s'};
    printf("%c",arr[2]);
    return 0;
}
// output
// l

// 9:52+
#include<stdio.h>
int main(){
    int a[4] = {1,2,3,4};
    printf("%p\n", &a[0]);
    printf("%p\n", &a[1]);
    printf("%p\n", &a[2]);
    printf("%p\n", &a[3]);
    char arr[5] = {'a','t','l','a','s'};
    //printf("%c",arr[2]);
    return 0;
}
// output
// uhfgsfdhg0
// wkggsyghj4
// wuerhgurh8
// hwguhgjwrc


// 11:00+
#include<stdio.h>
int main(){
    int a[4] = {1,2,3,4};
    // printf("%p\n", &a[0]);
    // printf("%p\n", &a[1]);
    // printf("%p\n", &a[2]);
    // printf("%p\n", &a[3]);
    char arr[4] = {'a','t','l','a',};
    printf("%p\n", &arr[0]);
    printf("%p\n", &arr[1]);
    printf("%p\n", &arr[2]);
    printf("%p\n", &arr[3]);
    //printf("%c",arr[2]);
    return 0;
}
// output
// 0x7fff462f1d3c
// 0x7fff462f1d3d
// 0x7fff462f1d3e
// 0x7fff462f1d3f


// 13:48+
#include<stdio.h>
int main(){
    char ch = 'A';
    printf("%c", ch);
    return 0;
}
// A

// 14:14+
#include<stdio.h>
int main(){
    char ch = 'A';
    printf("%d", ch);
    return 0;
}
// 65

// 14:35+ (dusra tarika)
#include<stdio.h>
int main(){
    char ch = 'A';
    int x = (int)ch;
    printf("%d", x);
    return 0;
}
// 65


// 18:40+
#include<stdio.h>
int main(){
    int arr[] = {1,2,3,4,5};
    for(int i=0; i<5; i++){
        printf("%d ", arr[i]);
    }
    return 0;
}
// output
// 1 2 3 4 5 

// 19:50+ (aor tarika) Null character
#include<stdio.h>
int main(){
    char arr[] = {'H','e','l','l','o'};
    char ch = 'a';
    printf("%c",ch);
    return 0;
}
// a


// 22:01+
#include<stdio.h>
int main(){
    char arr[] = {'H','e','l','l','o'};
    char ch = 'ab';
    printf("%c",ch);
    return 0;
}
// error


// 22:28+ Null character
#include<stdio.h>
int main(){
    char arr[] = {'H','e','l','l','o'};
    char ch = '\0'; // null charater
    printf("%d",ch);
    return 0;
}
// output 


// 23:41+
#include<stdio.h>
int main(){
    char arr[] = {'H','e','l','l','o'};
    char ch = '\0'; // null charater
    int x = 0;
    char a = (char)x; // a-> '\0'
    printf("%c",a);
    return 0;
}
// output



// 24:41+
#include<stdio.h>
int main(){
    char arr[] = {'H','e','l','l','o','\0'};
    // char ch = '\0'; // null charater
    // int x = 0;
    // char a = (char)x; // a-> '\0'
    int i = 0;
    while(arr[i]!='\0'){
        printf("%c ", arr[i]);
        i++;
    }
    return 0;
}
// output
// H e l l o



// 26:00+
#include<stdio.h>
int main(){
    char arr[] = {'H','e','l','l','o','\!'};
    // char ch = '\0'; // null charater
    // int x = 0;
    // char a = (char)x; // a-> '\0'
    int i = 0;
    while(arr[i]!='!'){
        printf("%c ",arr[i]);
        i++;
    }
    return 0;
}
// output
// H e l l o