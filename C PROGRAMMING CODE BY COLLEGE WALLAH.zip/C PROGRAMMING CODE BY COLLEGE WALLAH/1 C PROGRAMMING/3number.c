// 35:50 + par code
#include<stdio.h>
int main(){
    int x = 5;
    printf("x");
    return 0;
}
// output
// x


// 37:22+ par code
#include<stdio.h>
int main(){
    int x = 5;
    printf("%d", x);
    return 0;
}
// output
// 5


#include<stdio.h>
int main(){
    int x;
    x = 5;
    printf("%d", x);
    return 0;
}
// output
// 5



// 39:37+ par code
#include<stdio.h>
int main(){
    int x;
    x = 7;
    printf("%d",x);
    x = 9;
    printf("\n");
    printf("%d",x);
    return 0;
}
// output
// 7
// 9



// 40:42+ par code
#include<stdio.h>
int main(){
    int x;
    x = 7;
    printf("%d",x);
    x = 9;
    printf("\n");
    printf("%d",x);
    x = 200;
    printf("\n%d",x);
    return 0;
}
// output
// 7
// 9
// 200




// 43:10+ par code
#include<stdio.h>
int main(){
    int x;
    x = 7;
    printf("%d",x);
    x = x + 5;
    printf("\n");
    printf("%d",x);
    return 0;
}
// output
// 7
// 12



// 47:38+ par code
#include<stdio.h>
int main(){
    int x;
    x = 7;
    printf("%d",x);
    x = x + 5;
    printf("\n");
    printf("%d",x);
    printf("\n");
    x = x - 12;
    printf("%d",x);
    return 0;
}
// output
// 7
// 12
// 0