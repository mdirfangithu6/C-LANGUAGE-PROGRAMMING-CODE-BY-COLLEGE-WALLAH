// 2:27:38+ par code

#include<stdio.h>
int main(){
    int p,q;
    printf("Enter values of p and q");
    scanf("%d %d",&p,&q);
    printf("p=%d q=%d",p,q);
    return 0;
}
// output
// Enter values of p and q 40 50
// p = 40 q = 50