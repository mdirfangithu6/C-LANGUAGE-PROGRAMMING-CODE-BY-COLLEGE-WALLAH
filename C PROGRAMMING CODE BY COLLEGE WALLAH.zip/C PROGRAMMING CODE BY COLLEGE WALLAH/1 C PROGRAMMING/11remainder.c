// 2:32:26+ 2:39:10+ par code
// Example : Take two integers input, a and b : a>b, and find the remainder when a is divided by b.

#include<stdio.h>
int main(){
    int a,b; //a>b

    printf("Enter Division : ");
    scanf("%d", &a);
    printf("Enter Division : ");
    scanf("%d", &b);
    int q = a/b;
    int r = a - b*q; // divisor * qoutient +Remainder = Divident
    printf("The Remainder when %d is divided by %d is : %d", a,b,r);

    return 0;
}
// output
// Enter Division :41
// Enter Division :6
// The Remainder when 41 is divided by 6 is : 5



// 2:44:40+ par code

#include<stdio.h>
int main(){
    int a,b; //a>b

    printf("Enter Division : ");
    scanf("%d", &a);
    printf("Enter Division : ");
    scanf("%d", &b);
    // int q = a/b;
    // int r = a - b*q; // divisor * qoutient +Remainder = Divident
    // printf("The Remainder when %d is divided by %d is : %d", a,b,r);

    int r = a % b;
    printf("The Remainder when %d is divided by %d is : %d", a,b,r);
    return 0;
}
// output
// Enter Division :41
// Enter Division :6
// The Remainder when 41 is divided by 6 is : 5