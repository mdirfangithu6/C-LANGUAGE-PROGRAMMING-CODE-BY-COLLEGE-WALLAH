// 2:59:50+ par code

#include<stdio.h>
int main(){
    float x = 5.7;
    int y = x; 
    printf("%d\n", y);
    float z = x - y;
    printf("%f", z);
    return 0;
}
// output
// 5
// 0.700000