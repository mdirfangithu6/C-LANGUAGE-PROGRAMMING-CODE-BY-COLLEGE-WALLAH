// 2:17:20+ par code
#include<stdio.h>
int main(){
    int x = 5;
    printf("%d", x);
    return 0;
}
// output
// 5



// 2:18:45+ par code
#include<stdio.h>
int main(){
    int x = 5;
    printf("%d", &x);
    return 0;
}
// output
// 7jgf8452487


// 2:21:10+ par code
#include<stdio.h>
int main(){
    int x = 5;
    scanf("%d", &x);
    printf("The numbler you entered is : %d", &x);
    return 0;
}
// output
// 6
// The numbler you entered is : 6



#include<stdio.h>
int main(){
    int x = 5;
    scanf("%d", x);
    printf("The numbler you entered is : %d", &x);
    return 0;
}
// output
// 6
// segmentation fault