// 1:52:57+ par code

#include<stdio.h>
int main(){
    float p, r,t,si; //4dabble create ho jaate
    p=152;
    r=10;
    t=2;
    si=(p*r*t)/100;
    printf("%f",si);
    return 0;
}
// output
// 30.400000



// 2:08:47+ par code
#include <stdio.h>

int main() {
    float principal, rate, time, si; //; //4dabble create ho jaate

    printf("Enter principal: ");
    scanf("%f", &principal);

    printf("Enter rate: ");
    scanf("%f", &rate);

    printf("Enter time: ");
    scanf("%f", &time);

    si = (principal * rate * time) / 100;

    printf("Your simple interest is: %f\n", si);
    
    return 0;
}
// output
// Enter principal: 