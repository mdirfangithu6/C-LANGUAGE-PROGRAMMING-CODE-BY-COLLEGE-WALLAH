

#include<stdio.h>
int main(){
    int a = 41; 
    int b = 6; 
    int r = a % b;
    printf("%d", r);
    return 0;
}
// output
// 5


// 2:48:22+ par code
#include<stdio.h>
int main(){
    int a = 2; // a>b
    int b = 6; 
    int r = a % b;
    printf("%d", r);
    return 0;
}
// output
// 2