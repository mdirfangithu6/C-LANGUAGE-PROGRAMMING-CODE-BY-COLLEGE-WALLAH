// Arithmetic operations on int data type

// 51:08+ par code
#include <stdio.h>
int main(){
    int x = 5;
    int y = 2;
    printf("%d", x+y);
    printf("%d", x-y);
    printf("%d", x*y);
    printf("%d", x/y);

    return 0;
}
// output
// 7
// 3
// 10
// 2


// 57:02+ par code
#include <stdio.h>
int main(){
    int x = 4;
    int y = 2;
    int z = x + y;
    printf("%d", z);

    return 0;
}
// output
// 6






// 1:02:00+ par code
#include<stdio.h>
int main(){
    float x = 5;
    float y = 2;
    float z = 5.0 /2;
    printf("%f",z);
    return 0;
}
// output
// 2.500000