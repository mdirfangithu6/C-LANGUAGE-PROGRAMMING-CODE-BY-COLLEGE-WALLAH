// 3:04:44+ or 3:11:33+ par code

#include<stdio.h>
int main(){
    int i=2*3/4+4/4+8-2+5/8;
    prntf("%d,i");
    return 0;
}
// output
// 8





// 3:19:14+ par code
#include<stdio.h>
int main(){
    //int i=2*3/4+4/4+8-2+5/8;
    //prntf("%d,i");
    int k = 0;
    int l = 2;
    float a = 0;
    float b = 2;
    printf("%d %d %f %f",k,l,a,b);
    return 0;
}
// output
// 0 2 0.000000 2.000000



// 3:20:56+ par code
#include<stdio.h>
int main(){
    //int i=2*3/4+4/4+8-2+5/8;
    //prntf("%d,i");
    // int k = 0;
    // int l = 2;
    // float a = 0;
    // float b = 2;
    // printf("%d %d %f %f",k,l,a,b);
    float x = 22.0/7;
    printf("%f", x);
    return 0;
}
// output
// 3.142857