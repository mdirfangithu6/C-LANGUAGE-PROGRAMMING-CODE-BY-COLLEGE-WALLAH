#include<stdio.h>
int main()
{
    print("\n");
    return 0;
}
// output
// 