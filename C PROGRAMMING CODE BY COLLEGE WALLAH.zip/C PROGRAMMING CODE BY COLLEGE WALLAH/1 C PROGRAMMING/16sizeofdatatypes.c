// 3:43:48+ par code

#include<stdio.h>
int main(){
    int a = 30 * 1000 + 2768;
    printf("%d",a);    
    return 0;
}
// output
// 32768


// 3:45:17+ par code
#include<stdio.h>
int main(){
    short a = 30 * 1000 + 2768;
    printf("%d",a);    
    return 0;
}
// output
// -32768