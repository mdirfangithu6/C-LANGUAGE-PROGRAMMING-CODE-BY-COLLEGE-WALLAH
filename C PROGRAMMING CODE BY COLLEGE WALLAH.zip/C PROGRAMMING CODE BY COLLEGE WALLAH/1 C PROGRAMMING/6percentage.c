// 1:22:10+ par code

#include<stdio.h>
int main(){
    float m1 = 95;
    float m2 = 77;
    float m3 = 92;
    float m4 = 99;
    float m5 = 86;
    float p =(m1+m2+m3+m4+m5)/5;
    printf("percentage of 5 subjects is :%f", p);
    return 0;
}
// output
// percentage of 5 subjects is :89.800003




// 1:30:40+
// HW: Print percentage of 4 subject marks are out of 40
// by chatGPT

#include <stdio.h>

int main() {
    int subject1, subject2, subject3, subject4;
    int totalMarks = 160; // 4 subjects * 40 marks each
    int obtainedMarks;
    float percentage;

    // Input marks for 4 subjects
    printf("Enter marks for Subject 1 (out of 40): ");
    scanf("%d", &subject1);
    
    printf("Enter marks for Subject 2 (out of 40): ");
    scanf("%d", &subject2);
    
    printf("Enter marks for Subject 3 (out of 40): ");
    scanf("%d", &subject3);
    
    printf("Enter marks for Subject 4 (out of 40): ");
    scanf("%d", &subject4);

    // Calculate total obtained marks
    obtainedMarks = subject1 + subject2 + subject3 + subject4;

    // Calculate percentage
    percentage = (obtainedMarks * 100.0) / totalMarks;

    // Display result
    printf("Total Marks Obtained: %d out of %d\n", obtainedMarks, totalMarks);
    printf("Percentage: %.2f%%\n", percentage);

    return 0;
}
// output
// Enter marks for Subject 1 (out of 40): 67
// Enter marks for Subject 2 (out of 40): 54
// Enter marks for Subject 3 (out of 40): 88
// Enter marks for Subject 4 (out of 40): 32
// Total Marks Obtained: 241 out of 160
// Percentage: 150.62%