// 8:12+ par code
#include<stdio.h>
int main(){
    print("hello world");
    return 0;
}
// output
// hello world