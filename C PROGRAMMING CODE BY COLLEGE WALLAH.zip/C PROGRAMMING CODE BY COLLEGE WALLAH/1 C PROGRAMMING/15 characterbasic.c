// 3:21:42+ or 3:24:55+ par code

#include<stdio.h>
int main(){
    char ch ='a';
    printf("%c",ch);
    return 0;
}
// output
// a



// 3:28:15+ par code
#include<stdio.h>
int main(){
    char ch ='a';
    printf("%d",ch);
    return 0;
}
// output
// 97