// 1:13:00+ par code

#include<stdio.h>
int main(){
    int r = 5;
    float v = 4 * 3.14 * r * r * r / 3;
    printf("the volume is : %f",v);
    return 0;
}
// output
// the volume is : 523.333313



// 1:32:12+ par code
#include<stdio.h>
int main(){
    int r = 5;
    int pi = 3.1415;
    float v = 4 * pi * r * r * r / 3;
    printf("the volume is : %f",v);
    return 0;
}