// 1:58:29+ par code 

#include<stdio.h>
int main(){
    float radius =10;
    float pi = 3.1415;
    float area = pi *radius *radius;
    printf ("the area of circle is : %f",area);
    return 0;
}
// output
// the area of circle is : 314.150024


#include<stdio.h>
int main(){
    float radius;
    printf("enter radius:");
    scanf("%f", &radius);
    float pi =3.1415;
    float area = pi *radius *radius;
    printf ("the area of circle is :%f",area);
    return 0;
}
// output
// enter radius: