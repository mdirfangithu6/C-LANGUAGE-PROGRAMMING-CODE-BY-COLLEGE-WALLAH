// 1:22:03+ par code
// Ques : Make a function which calculate 'a' raised to the power 'b' using recursion .

// loop se 
#include<stdio.h>
int power(int a, int b){
    int x = 1;
    for(int i=1; i<=b; i++){
        x = x*a;
    }
    return x;
}

int main(){
    int a;
    printf("Enter power : ");
    scanf("%d", &a);
    int b;
    printf("Enter power : ");
    scanf("%d", &b);
    int p = power(a,b);
    printf("%d raisesd to the power %d is %d", a,b,p);
    return 0;
}
// output
// Enter base : 2
// Enter power : 4
// 2 raisesd to the power 4 is 16



// 1:25:40+ or 1:28:20+ par code
// recursion se
#include<stdio.h>
int power(int a, int b){
    if(b==0) return 1;
    int recAns = a*power(a,b-1);
    return recAns; //return a*power(a,b-1);
}

int main(){
    int a;
    printf("Enter base : ");
    scanf("%d", &a);
    int b;
    printf("Enter power : ");
    scanf("%d", &b);
    int p = power(a,b);
    printf("%d raisesd to the power %d is %d", a,b,p);
    return 0;
}
// output
// Enter base : 3
// Enter power : 4
// 3 raisesd to the power 4 is 81 