// 1:46:00+ or 1:55:00+ par code
// Ques : Stair Path

#include<stdio.h>
int stair(int n){
    if(n==1) return 1; // 1:59:23+ par code = if((n==1) || (n==2))   or if(n<=2)
    if(n==2) return 2;
    int totslWays = stair(n-1) + stair(n-2);
    return totalWays;
}

int main(){
    int n;
    printf("enter a number : ");
    scanf("%d", ways);
    int ways = stair(n);
    printf("%d", ways);
    return 0;
}
// output
// enter a number : 5
// 8


