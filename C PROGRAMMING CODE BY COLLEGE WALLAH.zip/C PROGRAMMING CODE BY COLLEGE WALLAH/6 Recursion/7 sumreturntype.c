// 1:18:50+ par code
// Ques : Print sum from  1 to n (Return type)

#include<stdio.h>
int sum(int n){
    if(n==1 || n==0) return 1;
    int recAns = n+sum(n-1);
    return recAns;
}
int main(){
    int n;
    printf("Enter a number : ");
    scanf("%d", &n);
    int fact = sum(n);
    printf("%d", fact);
    return 0;
}
// output
// Enter a number : 5
// 15

// Enter a number : 10
// 55