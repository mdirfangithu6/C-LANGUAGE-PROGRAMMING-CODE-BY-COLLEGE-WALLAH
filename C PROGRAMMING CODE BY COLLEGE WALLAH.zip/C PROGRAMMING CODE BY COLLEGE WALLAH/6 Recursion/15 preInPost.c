// 3:13:22+ Pre In Post


// 3:14:14+ par code
#include <stdio.h>

void preInPost(int n) {
    if (n == 0) return;
    
    printf("Pre %d\n", n);  // Pre-order print
    preInPost(n - 1);       // Recursive call
    printf("In %d\n", n);   // In-order print
    preInPost(n - 1);       // Recursive call
    printf("Post %d\n", n); // Post-order print
    
    return;
}

int main() {
    int n;
    printf("Enter a number: ");
    scanf("%d", &n);
    
    preInPost(n);  // Call the recursive function
    
    return 0;
}
// output
// Enter a number: 2
// Pre 2
// Pre 1
// In 1
// Post 1
// In 2
// Pre 1
// In 1
// Post 1
// Post 2