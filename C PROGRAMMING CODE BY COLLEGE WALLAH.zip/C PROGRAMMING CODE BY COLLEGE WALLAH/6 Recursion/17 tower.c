// 3:37:17+ or4:05:25+ par code
// Ques : Tower of HANOI

#include<stdio.h>
void tower(int n, char s, char h, char d){
    if(n==0) return;
    tower(n-1,s,d,h);
    printf("%c -> %c\n",s,d);
    tower(n-1,h,s,d);
    return;
}
int main(){
    int n;
    printf("Enter number of disks : ");
    scanf("%d", &n);
    tower(n,'A','B','C');
    return 0;
}
// output
// Enter number of disks : 2
// A -> B
// A -> C
// B -> C


// Enter number of disks : 3
// A -> C
// A -> B
// C -> B
// A -> C
// B -> A
// B -> C
// A -> C