// 3:33:03+ par code

// Ques: Print zig-zag

// Input    Output
// 1        111
// 2        211121112
// 3        321112111232111211123
// 4        432111211123211121112343211121112321112111234

#include <stdio.h>

void zigzag(int n) {
    if (n == 0) return;
    
    printf("%d ", n);  // Print the current number
    zigzag(n - 1);     // Recursive call
    printf("%d ", n);  // Print the current number again
    zigzag(n - 1);     // Recursive call
    printf("%d ", n);  // Print the current number once more
    
    return;
}

int main() {
    int n;
    printf("Enter a number: ");
    scanf("%d", &n);
    
    zigzag(n);  // Call the recursive function
    
    return 0;
}
// output
// Enter a number: 4
// 4 3 2 1 1 1 2 1 1 1 2 3 2 1 1 1 2 1 1 1 2 3 4 3 2 1 1 1 2 1 1 1 2 3 2 1 1 1 2 1 1 1 2 3 4 