// 14:54+ par code

#include <stdio.h>

int factorial(int n){
    int fact = 1;
    for(int i = 2; i <= n; i++){
        fact = fact * i;
    }
    return fact;
}

int main(){
    int n;
    printf("Enter a number: ");
    scanf("%d", &n);
    int fact = factorial(n);
    printf("%d", fact);
    return 0;
}
// output
// Enter a number : 5
// 120



// 17:15+ par code
#include <stdio.h>

int factorial(int n){
    return n*factorial(n-1);
}

int main(){
    int n;
    printf("Enter a number: ");
    scanf("%d", &n);
    int fact = factorial(n);
    printf("%d", fact);
    return 0;
}
// output 
// Enter a number : 5
// Segmentation fault



// 24:24+ par code
#include <stdio.h>

int factorial(int n){
    if(n==1  || n==0) return 1; // base case
    return n*factorial(n-1);
}

int main(){
    int n;
    printf("Enter a number: ");
    scanf("%d", &n);
    int fact = factorial(n);
    printf("%d", fact);
    return 0;
}
// output
// Enter a number: 4
// 24



// 31:40+ par code
#include <stdio.h>

int factorial(int n){
    if(n==1  || n==0) return 1; // base case
    int recAns = n*factorial(n-1);
    return recAns;
}

int main(){
    int n;
    printf("Enter a number: ");
    scanf("%d", &n);
    int fact = factorial(n);
    printf("%d", fact);
    return 0;
}
// output
// Enter a number : -3
// 1