// 2:00:55+ par code
// Ques : Stair Path -2

// by chatGPT

#include <stdio.h>

int stair(int n) {
    if(n == 0) return 1;           // base case: 1 way to stay at 0th step
    if(n < 0) return 0;            // no way if steps go negative

    // total ways = 1-step + 2-step + 3-step
    return stair(n - 1) + stair(n - 2) + stair(n - 3);
}

int main() {
    int n;
    printf("Enter a number: ");
    scanf("%d", &n);  // Corrected from 'ways' to '&n'

    int ways = stair(n);
    printf("Total ways to reach step %d: %d\n", n, ways);
    return 0;
}
// output
// Enter a number: 4
// Total ways to reach step 4: 7