// 55:49+ or 57:25+ par code
// Ques : Print 1 to n (after recursive call) 

#include<stdio.h>
void increasing(int n){
    if(n==0) return; // base case
    increasing(n-1); // caal
    printf("%d\n", n); // code
    return;
}
int main(){
    int n;
    printf("Enter a number : ");
    scanf("%d", &n);
    increasing(n);
    return 0;
}
// output
// Enter a number : 5
// 1
// 2
// 3
// 4
// 5