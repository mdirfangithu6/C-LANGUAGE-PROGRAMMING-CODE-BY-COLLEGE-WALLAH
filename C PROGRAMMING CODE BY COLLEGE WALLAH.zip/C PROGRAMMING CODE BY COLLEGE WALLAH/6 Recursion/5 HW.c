// 1:05:00+ par code
// Homewoek : Print Dcreasing - incrreasing
// n = 4-> 
// 4
// 3
// 2
// 1
// 1
// 2
// 3
// 4
// Hint : call se pehle, call ke baad 
// HW : n=3-> DRY RUN

// by chatGPT

#include <stdio.h>

void printPattern(int n) {
    if (n == 0) return; // base case

    printf("%d\n", n);       // call se pehle print (decreasing)
    printPattern(n - 1);     // recursive call
    printf("%d\n", n);       // call ke baad print (increasing)
}

int main() {
    int n = 4;
    printPattern(n);
    return 0;
}
// output
// 4
// 3
// 2
// 1
// 1
// 2
// 3
// 4