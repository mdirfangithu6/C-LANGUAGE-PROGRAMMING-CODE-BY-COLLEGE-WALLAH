// 1:29:37+ or 1:34:15+ par code
// *Multiple Calls
// Ques : Write a function to calculatte the nth fibonacci number using recursion.

#include<stdio.h>
int fibo(int n){
    int ans1 = fibo(n-1);
    int ans2 = fibo(n-2);
    int ans = ans1 + ans2;
    return ans;

}

int main(){
    int n;
    printf("Enter a number: ");
    scanf("%d",&n);
    //int x = fibo(n);
    printf("%d", fibo(n));
    return 0;
}
// output
// Enter a number : 


// 1:37:45+ par code
// 3 line ko hatao wala code
#include<stdio.h>
int fibo(int n){
    if(n==1 || n==2) return 1;
    return fibo(n-1) + fibo(n-2);
}

int main(){
    int n;
    printf("Enter a number : ");
    scanf("%d", &n);
    // int x = fibo(n);
    printf("%d", fibo(n));
    return 0;
}
// output
// Enter a number : 7
// 13


// 1:38:27+ par code
// is se bhi chota
#include<stdio.h>
int fibo(int n){
    if(n<=2) return 1;
    return fibo(n-1) + fibo(n-2);
}

int main(){
    int n;
    printf("Enter a number : ");
    scanf("%d", &n);
    // int x = fibo(n);
    printf("%d", fibo(n));
    return 0;
}
// output
// Enter a number : 1
// 1