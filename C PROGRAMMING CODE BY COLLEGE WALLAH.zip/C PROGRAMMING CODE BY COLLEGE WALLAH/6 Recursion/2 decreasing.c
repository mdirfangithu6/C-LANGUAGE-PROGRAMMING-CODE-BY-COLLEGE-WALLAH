// 33:18+ par code
// Ques : Print n to 1

#include<stdio.h>
void greeting(int n){
    for(int i=1; i<=n; i++){
        printf("Good morning\n");
    }
    return;
}
int main(){
    int n;
    printf("Enter a number : ");
    scanf("%d", &n);
    greeting(n);
    return 0;
}
// output
// Enter a number : 5
// Good morning
// Good morning
// Good morning
// Good morning
// Good morning



// 37:10+ par code
#include<stdio.h>
void greeting(int n){
    printf("Good Morning : ");
    greeting(n-1);
    return 0;
}
int main(){
    int n;
    printf("Enter a number : ");
    scanf("%d", &n);
    greeting(n);
    return 0;
}
// output
// Enter a number : 5
// Segmentation fault



// 38:20+ par code
#include<stdio.h>
void greeting(int n){
    if(n==0) return;
    printf("Good Morning : ");
    greeting(n-1);
    return 0;
}
int main(){
    int n;
    printf("Enter a number : ");
    scanf("%d", &n);
    greeting(n);
    return 0;
}
// Enter a number : 4
// Good morning
// Good morning
// Good morning
// Good morning



// 45:20+ Ques : Print n to 1
#include<stdio.h>
void decreasing(int n){
    if(n==0) return;
    printf("%d\n", n);
    decreasing(n-1);
    return 0;
}
int main(){
    int n;
    printf("Enter a number : ");
    scanf("%d", &n);
    decreasing(n);
    return 0;
}
// output
// Enter a number : 4
// 4
// 3
// 2
// 1