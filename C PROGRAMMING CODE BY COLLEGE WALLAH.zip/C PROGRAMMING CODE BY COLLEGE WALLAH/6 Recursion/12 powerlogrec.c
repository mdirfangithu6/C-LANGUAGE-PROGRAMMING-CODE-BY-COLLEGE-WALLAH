// 2:03:45+ or 2:10:00+ par code
// Ques : Power function (logarithmic)

#include<stdio.h>
int power(int a, int b){
    if(b==0) return 1;
    int recAns = a*power(a,b-1);
    return recAns;
}
int main(){
    int a;
    printf("Enter base : ");
    scanf("%d", &a);
    int b;
    printf("Enter power : ");
    scanf("%d", &b);
    int p = power(a,b);
    printf("%d raised to the power %d is %d", a,b,p);
    return 0;
}
// output
// Enter base : 3
// Enter power : 4
// 3 raised to the power 4 is 81


// 2:10:26+ par code
#include<stdio.h>
int powerlog(int a, int b){
    if(b==1) return a;
    int recAns = a*powerlog(a,b-1);
    return recAns;
}
int main(){
    int a;
    printf("Enter base : ");
    scanf("%d", &a);
    int b;
    printf("Enter power : ");
    scanf("%d", &b);
    int p = powerlog(a,b);
    printf("%d raised to the power %d is %d", a,b,p);
    return 0;
}
// output
// Enter base : 3
// Enter power : 4
// 3 raised to the power 4 is 81

// Enter base : 3
// Enter power : 0
// Segmentation fault



// 2:11:09+ par code
#include<stdio.h>
int powerlog(int a, int b){
    if(b==0) return 1;
    int recAns = a*powerlog(a,b-1);
    return recAns;
}
int main(){
    int a;
    printf("Enter base : ");
    scanf("%d", &a);
    int b;
    printf("Enter power : ");
    scanf("%d", &b);
    int p = powerlog(a,b);
    printf("%d raised to the power %d is %d", a,b,p);
    return 0;
}
// output
// Enter base : 3
// Enter power : 4
// 3 raised to the power 4 is 81





// 2:11:40+ par code
// odd no ka power nikal deta hai lekin 0 ka nahi
#include<stdio.h>
int powerlog(int a, int b){
    if(b==1) return a;
    int x = powerlog(a,b/2);
    int recAns = x *x;
    return recAns;
}
int main(){
    int a;
    printf("Enter base : ");
    scanf("%d", &a);
    int b;
    printf("Enter power : ");
    scanf("%d", &b);
    int p = powerlog(a,b);
    printf("%d raised to the power %d is %d", a,b,p);
    return 0;
}
// output
// Enter base : 3
// Enter power : 8
// 3 raised to the power 8 is 6561


// 2:19:50+ par code
#include<stdio.h>
int powerlog(int a, int b){
    if(b==1) return a;
    if(b%2==0){ // even
        return powerlog(a,b/2) * powerlog(a,b/2);
    }
    else{
        return powerlog(a,b/2) * powerlog(a,b/2);
    }
}
int main(){
    int a;
    printf("Enter base : ");
    scanf("%d", &a);
    int b;
    printf("Enter power : ");
    scanf("%d", &b);
    int p = powerlog(a,b);
    printf("%d raised to the power %d is %d", a,b,p);
    return 0;
}
// output
// Enter base : 2
// Enter power : 7
// 2 raised to the power 7 is 128
// upar wali code ko acha karna
#include<stdio.h>
int powerlog(int a, int b){
    if(b==1) return a;
    int x = power;og(a,b/2);
    if(b%2==0){ // even
        return x*x;
    }
    else{
        return x*x*a;
    }
}
int main(){
    int a;
    printf("Enter base : ");
    scanf("%d", &a);
    int b;
    printf("Enter power : ");
    scanf("%d", &b);
    int p = powerlog(a,b);
    printf("%d raised to the power %d is %d", a,b,p);
    return 0;
}
// output
// Enter base : 2
// Enter power : 1
// 2 raised to the power 1 is 2

// Enter base : 2
// Enter power : 3
// 2 raised to the power 1 is 8

// Enter base : 2
// Enter power : 5
// 2 raised to the power 1 is 32


// Enter base : 2
// Enter power : 0
// Segmentation fault



// 2:22:54+ par code
// 0 wala ka code
#include<stdio.h>
int powerlog(int a, int b){
    if(b==0) return 1;
    // if(b==1) return a;
    int x = powerlog(a,b/2);
    if(b%2==0){
        return x*x;
    }
    else{
        return x*x*a;
    }
}
int main(){
    int a;
    printf("Enter base : ");
    scanf("%d", &a);
    int b;
    printf("Enter base : ");
    scanf("%d", &b);
    int p = powerlog(a,b);
    printf("%d raised to the power %d is %d", a,b,p);
    return 0;
}
// output
// Enter base : 

