// 1:06:33+ par code
// Ques : Print sum from 1 to n (Parameterised)

// loop se
#include <stdio.h>

void sum(int n) {
    int s = 0;
    for(int i = 1; i <= n; i++) {
        s = s + i;
    }
    printf("%d\n", s); 
    return;
}

int main() {
    int n;
    printf("Enter a number: ");
    scanf("%d", &n);  
    sum(n);
    return 0;
}
// output
// Enter a number : 5
// 15


// 1:09:00+ par code
// Recursion se 
#include<stdio.h>
void sum(int n, int s){
    if(n==0) return;
    sum(n-1, s+n);
    return;
}
int main(){
    int n;
    printf("Enter a number : ");
    scanf("%d", &n);
    sum(n,0);
    return 0;
}
// output
// Enter a number : 5



// 1:13:21+ par code
#include<stdio.h>
void sum(int n, int s){
    if(n==0){
        printf("%d", s);
        return;
    }
    sum(n-1, s+n);
    return;
}

int main(){
    int n;
    printf("Enter a number : ");
    scanf("%d", &n);
    sum(n,0);
    return 0;
}
// output
// Enter a number : 6
// 21