// 1:56:18+ par code
// Ques : Swap 2 numbers

#include<stdio.h>

int main(){
    int a;
    printf("Enter a : ");
    scanf("%d",&a);
    
    int b;
    printf("Enter b : ");
    scanf("%d",&b);
    
    int temp;
    temp = a;
    a = b;
    b = temp;
    
    printf("The value of a is %d\n", a);
    printf("The value of b is %d", b);
    
    return 0;
}
// output
// Enter a : 5
// Enter b : 9
// The value of a is 9
// The value of b is 5


// 2:02:00+ or 2:04:44+ par code
// Ques : Swap 2 numbers without using third variable
#include<stdio.h>

int main(){
    int a;
    printf("Enter a : ");
    scanf("%d",&a);
    
    int b;
    printf("Enter b : ");
    scanf("%d",&b);
    
    a = a + b;
    b = a - b;
    a = a - b;
    
    printf("The value of a is %d\n", a);
    printf("The value of b is %d", b);
    
    return 0;
}
// output
// Enter a : 5
// Enter b : 3
// The value of a is 3
// The value of b is 5


// 2:07:10+ or 2:09:00+ par code
// Paas by value & Paas vy reference
#include<stdio.h>

void swap(int a, int b){
    int temp = a;
    a = b;
    b = temp;
    return;
}

int main(){
    int a;
    printf("Enter a : ");
    scanf("%d",&a);
    
    int b;
    printf("Enter b : ");
    scanf("%d",&b);
    
    swap(a,b);
    
    printf("The value of a is %d\n",a);
    printf("The value of b is %d",b);
    
    return 0;
}
// output
// Enter a : 2
// Enter b : 9
// The value of a is 2
// The value of b is 9

// Paas by value ho raha hai 