// 1:24:24+ or 1:30:20+ par code
// Ques : Pascal triangle

#include<stdio.h>

int factorial(int x){
    int fact = 1;
    for(int i=2; i<=x; i++){
        fact = fact * i;
    }
    return fact;
}

int combination(int n, int r){
    int ncr = factorial(n) / (factorial(r) * factorial(n - r));
    return ncr;
}
#include <stdio.h>

int main(){
    int n;
    printf("Enter n : ");
    scanf("%d", &n);
    
    for(int i=0; i<=n; i++){
        for(int j=0; j<=i; j++){
            printf("*");
        }
        printf("\n");
    }

    return 0;
}
// iska output
// Enter n : 5
// *
// **
// ***
// ****
// *****
// ******



// 1:35:07+ par code
#include<stdio.h>

int factorial(int x){
    int fact = 1;
    for(int i=2; i<=x; i++){
        fact = fact * i;
    }
    return fact;
}

int combination(int n, int r){
    int ncr = factorial(n) / (factorial(r) * factorial(n - r));
    return ncr;
}
#include <stdio.h>

int main(){
    int n;
    printf("Enter n : ");
    scanf("%d", &n);
    
    for(int i=0; i<=n; i++){
        for(int j=0; j<=i; j++){
            int icj = combination(i,j);
            printf("%d", icj);
        }
        printf("\n");
    }

    return 0;
}
// output
// Enter n : 5
// 1
// 11
// 121
// 1331
// 14641
// 15101051


// 1:46:00+ par code
#include <stdio.h>

int main(){
    int n;
    printf("Enter n : ");
    scanf("%d", &n);
    
    for(int i=0; i<=n; i++){
        int first = 1;
        for(int j=0; j<=i; j++){
            printf("%d ",first);
            first = first * (i-j)/(j+1); //iC(j=1)
        }
        printf("\n");
    }
    return 0;
}
// output
// Enter n : 5
// 1 
// 1 1 
// 1 2 1 
// 1 3 3 1 
// 1 4 6 4 1 
// 1 5 10 10 5 1 
