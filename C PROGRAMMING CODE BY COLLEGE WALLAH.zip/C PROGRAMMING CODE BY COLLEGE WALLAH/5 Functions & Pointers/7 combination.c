// 1:05:53+
// Ques : Combination and Permutation

#include<stdio.h>

int main(){
    int n;
    printf("Enter n : ");
    scanf("%d",&n);
    int r;
    printf("Enter r : ");
    scanf("%d",&r);
    int nfact = 1; // n!
    int rfact = 1; // r!
    int nrfact = 1; // n-r !

    for(int i=2;i<=n;i++){
        nfact = nfact*i;
    }

    for(int i=2;i<=r;i++){
        rfact = rfact*i;
    }

    for(int i=2;i<=n-r;i++){
        nrfact = nrfact*i;
    }

    int ncr = nfact/(rfact*nrfact);
    printf("%d",ncr);

    return 0;
}
// output
// Enter n : 7
// Enter r : 3
// 35



#include<stdio.h>

int factorial(int x){
    int fact = 1;
    for(int i=2; i<=x; i++){
        fact = fact * i;
    }
    return fact;
}
int main(){
    int a = factorial(4);
    printf("%d", a);
    return 0;
}
// output
// 24


// 1:16:50+ par code
#include<stdio.h>

int factorial(int x){
    int fact = 1;
    for(int i=2; i<=x; i++){
        fact = fact * i;
    }
    return fact;
}

int main(){
    int n;
    printf("Enter n : ");
    scanf("%d", &n);

    int r;
    printf("Enter r : ");
    scanf("%d", &r);

    int nfact = factorial(n); // n!
    int rfact = factorial(r); // r!
    int nrfact = factorial(n-r); // (n-r)!

    int ncr = nfact / (rfact * nrfact);
    printf("%d", ncr);

    return 0;
}
// output
// Enter n : 7
// Enter r : 3
// 35



// 1:21:30+ par code
#include<stdio.h>

int factorial(int x){
    int fact = 1;
    for(int i=2; i<=x; i++){
        fact = fact * i;
    }
    return fact;
}

int main(){
    int n;
    printf("Enter n : ");
    scanf("%d", &n);

    int r;
    printf("Enter r : ");
    scanf("%d", &r);
    int ncr = factorial(n)/factorial(r)*factorial(n-r);
    ;printf("%d", nrc);
    return 0;
} 
// output
// Enter n : 5
// Enter r : 2
// 10



// 1:22:25+ par code
#include<stdio.h>

int factorial(int x){
    int fact = 1;
    for(int i=2; i<=x; i++){
        fact = fact * i;
    }
    return fact;
}
int combination(int n, int r){
    int ncr = factorial(n)/(factorial(r)*factorial(n-r));
    return ncr;
}

int main(){
    int n;
    printf("Enter n : ");
    scanf("%d", &n);

    int r;
    printf("Enter r : ");
    scanf("%d", &r);
    int ncr = combination(n,r);
    printf("%d", ncr);
    return 0;
} 
// output
// Enter n : 7
// Enter r : 3
// 35