// 3:14:09+ par code
// HW : Print the factorials of first 'n' numbers using function
// by chatGPT

#include <stdio.h>

// Function to calculate factorial
long long factorial(int num) {
    long long fact = 1;
    for(int i = 1; i <= num; i++) {
        fact *= i;
    }
    return fact;
}

int main() {
    int n;

    // Input the number of terms
    printf("Enter the value of n: ");
    scanf("%d", &n);

    // Print factorials from 1 to n
    for(int i = 1; i <= n; i++) {
        printf("Factorial of %d = %lld\n", i, factorial(i));
    }

    return 0;
}
// output
// Enter the value of n: 