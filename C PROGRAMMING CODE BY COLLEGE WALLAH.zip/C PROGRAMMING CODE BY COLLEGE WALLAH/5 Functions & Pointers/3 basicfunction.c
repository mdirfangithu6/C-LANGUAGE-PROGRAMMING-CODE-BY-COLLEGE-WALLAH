// 28:32+ How function work: ek ke andar doosra, doosre ke andar teesra

// 28:45+ par code
#include<stdio.h>
void england(){
    printf("You are in England\n");
    return;
}
void australia(){
    printf("You are in Australia\n");
    england(); // calling eng land
    return;
}
void india(){
    printf("You are in India\n");
    australia(); // calling australia
    return;
}
int main(){
    india(); // calling india
    return 0;
}
// output
// You are in India
// You are in Australia
// You are in England
