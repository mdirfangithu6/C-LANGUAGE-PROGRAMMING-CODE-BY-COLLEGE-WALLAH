// 3:14:24+ par code
// HW : Print first 'n' fibonacci numbers.
// by chatGPT

#include <stdio.h>

// Function to print Fibonacci series
void printFibonacci(int n) {
    int a = 0, b = 1, next;

    for(int i = 1; i <= n; i++) {
        printf("%d ", a);
        next = a + b;
        a = b;
        b = next;
    }
}

int main() {
    int n;

    // Input the number of terms
    printf("Enter the number of Fibonacci terms: ");
    scanf("%d", &n);

    // Print the Fibonacci sequence
    printf("Fibonacci series:\n");
    printFibonacci(n);

    return 0;
}
// output
// Enter the number of Fibonacci terms: 