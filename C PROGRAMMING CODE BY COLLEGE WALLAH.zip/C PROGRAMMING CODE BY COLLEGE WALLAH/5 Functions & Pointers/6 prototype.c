// 57:35+ function prototype

// normal
#include<stdio.h>
void fun(){
    printf("Hello");
}
int main(){
    fun()
    return 0;
}
// output
// Hello


// proto type wala
// 58:10+ par code
#include<stdio.h>
int main(){
    void fun();
    fun();
    return 0;
}
void fun(){
    printf("Hello");
}
// output
// Hello



// 1:00:45+ par code
#include<stdio.h>
int main(){
    void india();
    india(); // calling india // 1
    return 0;
}
void india(){
    printf("You are in India\n"); // 2
    void australia();
    australia(); // calling australia // 3
    return; //9

}
void australia(){
    printf("You are in Australia\n");//4
    void england();
    england(); // calling england //5
    return; //8
}
void england(){
    printf("You are in England\n"); //6
    return;//7
}