// 1:38:31+
// Homework : npr -> function =n!/(n-r)!