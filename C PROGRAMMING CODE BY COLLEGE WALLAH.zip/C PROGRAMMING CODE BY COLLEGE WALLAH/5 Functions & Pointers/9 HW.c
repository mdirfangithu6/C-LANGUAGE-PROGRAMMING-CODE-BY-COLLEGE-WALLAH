// 1:38:34+
// Ques : Pascal triangle
//       1
//      1 1
//     1 2 1
//    1 3 3 1
//   1 4 6 4 1
//  1 5 10 10 5 1
// 1 6 15 20 15 6 1

// by chatGPT
#include <stdio.h>

void printPascal(int n) {
    for (int i = 0; i < n; i++) {
        // Spaces for formatting
        for (int j = 0; j < n - i - 1; j++) {
            printf(" ");
        }
        
        int num = 1; // First element is always 1
        for (int j = 0; j <= i; j++) {
            printf("%d ", num);
            num = num * (i - j) / (j + 1); // Compute next element
        }
        printf("\n");
    }
}

int main() {
    int rows;
    printf("Enter number of rows: ");
    scanf("%d", &rows);
    
    printPascal(rows);
    return 0;
}
// output
// Enter number of rows: 7
//       1 
//      1 1 
//     1 2 1 
//    1 3 3 1 
//   1 4 6 4 1 
//  1 5 10 10 5 1 
// 1 6 15 20 15 6 1 