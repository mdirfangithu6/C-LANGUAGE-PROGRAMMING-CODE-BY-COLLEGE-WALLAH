// 2:37:30+ Swap 2 numbers pass by reference

#include <stdio.h>

void swap(int* x, int* y){
    int temp;
    temp = *x;  // temp = 2
    *x = *y;    // a = 9
    *y = temp;  // *y = 2 --> b = 2
    return;
}

int main(){
    int a = 2;
    int b = 9;
    swap(&a, &b);
    printf("The value of a is %d\n", a);
    printf("The value of b is %d\n", b);
    return 0;
}
// output
// The value of a is 9
// The value of b is 2


#include <stdio.h>

int main(){
    int a = 25;
    int* x = &a; // int* -> int ka address store karta hai
    // VVIP ->  *x = 7;  // a is changed.

    int y = &x; // int -> int* ka address store karta hai

    printf("%p\n", &x); // %p se address print hota hai
    printf("%p\n", y);

    return 0;
}
// output
// 0x7fff2a7f8f58
// 0x7fff2a7f8f58


#include <stdio.h>

int main(){
    int a = 25;
    int* x = &a; // int* -> int ka address store karta hai
    // VVIP ->  *x = 7;  // a is changed.

    int y = &x; // int -> int* ka address store karta hai

    printf("%d\n", *x); // %p se address print hota hai
    printf("%p\n", y);

    return 0;
}
// 


#include<stdio.h>

int main(){
    int a = 25;
    int* x = &a; // int* -> int ka address store karta hai
    // VVIP ->  *x = 7;  // a is changed.
    int y = &x; // int -> int* ka address store karta hai
    printf("%d\n", *x);  // %p se address print hota hai
    printf("%d\n", **y);

    return 0;
}
// output
// 25
// 0x7ffe477ce668


#include<stdio.h>

int main(){
    int a = 25;
    int* x = &a; // int* -> int ka address store karta hai
    // VVIP ->  *x = 7;  // a is changed.
    void* y = &x; // int -> int* ka address store karta hai
    printf("%d\n", a);
    printf("%d\n", *x);  // %p se address print hota hai
    printf("%d\n", y);

    return 0;
}
// output
// 25
// 25
// -1629530616