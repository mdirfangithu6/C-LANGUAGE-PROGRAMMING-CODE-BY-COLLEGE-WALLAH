// 4:40+ par code


// 5:10+ par code
#include<stdio.h>

int main(){
    printf("Good Morning \n");
    return 0;
}
// output
// Good Morning 

// 6:25+ par code
#include<stdio.h>

int main(){
    for(int i=1; i<=10; i++){
        printf("Good Morning \n");
    }
    return 0;
}
// output
// Good Morning 
// Good Morning 
// Good Morning 
// Good Morning 
// Good Morning 
// Good Morning 
// Good Morning 
// Good Morning 
// Good Morning 
// Good Morning 



// 7:27+ par code
#include<stdio.h>

int main(){
    // code
    // code
    // code
    // code
    printf("Good Morning \n");
    printf("How are you? \n");
    printf("Bye\n");
    // code
    // code
    // code
    // code
    printf("Good Morning \n");
    return 0;
}




// 9:07+ par code
#include<stdio.h>

void greet(){
    printf("Good Morning \n");
    printf("How are you ? \n");
    return;  
}
int main(){
    greet();
    greet();
    greet();
    return 0;
}
// output
// Good Morning 
// How are you ? 
// Good Morning 
// How are you ? 
// Good Morning 
// How are you ? 
