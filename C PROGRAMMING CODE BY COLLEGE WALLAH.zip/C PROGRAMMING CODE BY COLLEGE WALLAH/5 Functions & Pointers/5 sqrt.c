// 50:24+ library function

// 51:24+ par code
#include<stdio.h>
#include<math.h>

int main(){
    int a;
    printf("Enter a number : ");
    scanf("%d",&a);
    
    int root = sqrt(a);
    printf("The square root is : %d",root);
    
    return 0;
}
// output
// Enter a number : 64
// The square root is : 8



// 54:56+ 
//  power wala 
#include<stdio.h>
#include<math.h>

int main(){
    int q = pow(2,6);
    printf("%d", q);
    return 0;
}
// output
// 64
