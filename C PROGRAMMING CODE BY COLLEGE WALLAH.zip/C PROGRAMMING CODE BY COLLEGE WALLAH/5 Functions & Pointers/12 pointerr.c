// 2:19:12+ par code

#include<stdio.h>
int main(){
    int a = 5;
    printf("%d", a);
    return 0;
}
// output 
// 5

#include<stdio.h>
int main(){
    int a = 5;
    int b = 5;
    printf("%p", &a); //%p se address print hota hai
    printf("%p", &b);
    return 0;
}
// output


#include<stdio.h>
int main(){
    int a = 5;
    printf("%p", &a); //%p se address print hota hai
    return 0;
}
// output


#include<stdio.h>
int main(){
    int a = 5;
    int *x = &a;
    printf("%p\n", x); // %p se address print hota hai
    return 0;
}
// output 


#include<stdio.h>
int main(){
    int a = 5;
    int *x = &a;
    printf("%p\n", x); // %p se address print hota hai
    printf("%p\n", &x);
    return 0;
}
// output 


#include<stdio.h>
int main(){
    int a = 5;
    int *x = &a;
    printf("%d\n", *x); // %p se address print hota hai
    return 0;
}
// output 


#include<stdio.h>
int main(){
    int a = 5;
    int *x = &a;
    x = &a;
    printf("%p\n", &a);
    printf("%p\n", x); // %p se address print hota hai
    return 0;
}
// output


#include<stdio.h>
int main(){
    int a = 5;
    int *x = &a;
    *x = 7; // a is changed
    printf("%d\n", a); //%p se address print hota hai
    return 0;
}




























