// 38:48+ return type

#include<stdio.h>
int main(){
    int a;
    printf("Enter 1st number : ");
    scanf("%d",&a);
    
    int b;
    printf("Enter 2nd number : ");
    scanf("%d",&b);
    
    int sum = a + b;
    printf("%d",sum);
    
    return 0;
}
// output
// Enter 1st number : 3
// Enter 2nd number : 6
// 9



// 40:47+ par code
#include<stdio.h>
int add(int a, int b){
    return a + b;
}

int main(){
    int a;
    printf("Enter 1st number : ");
    scanf("%d",&a);
    
    int b;
    printf("Enter 2nd number : ");
    scanf("%d",&b);
    
    int sum = add(a, b);
    printf("%d",sum);
    
    return 0;
}
// output
// Enter 1st number : 4
// Enter 2nd number : 7
// 11