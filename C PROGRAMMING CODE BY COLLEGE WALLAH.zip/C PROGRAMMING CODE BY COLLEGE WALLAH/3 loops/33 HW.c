// 3:55:28+ par code
// HW : Write a program to print out all Armstrong numbers between 1 and 500. 
// if sum of cubes of each digit of the number itself, then the number is called an Armstrong number.
// For example, 153 = (1*1*1)+(5*5*5)+(3*3*3)
// by chatGPT

#include <stdio.h>
#include <math.h>

int main() {
    int num, originalNum, remainder, sum, digit;

    // Loop through numbers from 1 to 500
    for (num = 1; num <= 500; num++) {
        originalNum = num;
        sum = 0;

        // Process each digit of the number
        while (originalNum != 0) {
            remainder = originalNum % 10; // Get the last digit
            sum += remainder * remainder * remainder; // Add the cube of the digit
            originalNum /= 10; // Remove the last digit
        }

        // Check if the sum of cubes equals the original number
        if (sum == num) {
            printf("%d is an Armstrong number.\n", num);
        }
    }

    return 0;
}
// output
// 1 is an Armstrong number.
// 153 is an Armstrong number.
// 370 is an Armstrong number.
// 371 is an Armstrong number.
// 407 is an Armstrong number.