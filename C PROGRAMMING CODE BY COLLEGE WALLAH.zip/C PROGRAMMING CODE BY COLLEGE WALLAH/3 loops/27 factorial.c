// 3:07:37+ or 3:11:43+ par code
// *Ques: Print the factorial of a given number 'n'.

#include<stdio.h>
int main(){
    int n;
    printf("Enter a number : ");
    scanf("%d",&n);
    // 5! = 1x2x3x4x5
    int product = 1;
    for(int i=1; i<=n; i++){
        product = product*i;
    }

    printf("The factorial is : %d",product);
    return 0;
}
// output
// Enter a number : 5
// The factorial is : 120