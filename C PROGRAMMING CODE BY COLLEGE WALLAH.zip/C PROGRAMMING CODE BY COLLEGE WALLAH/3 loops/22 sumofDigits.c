// 2:31:18+ or 2:37:26+ par code
// Ques: WAP to print sum of digits of a given number.

#include<stdio.h>
int main(){
    int n;
    printf("Enter a number : ");
    scanf("%d", &n);
    int sum = 0;
    int lastDigit = 0;
    while(n!=0){
        lastDigit = n%10;
        sum = sum + lastDigit;
        n = n/10;
    }
    printf("The no of digits is %d", sum);
    return 0;
}
// output
// Enter a number : 9999
// The no of digits is 36