// 1:53:09+  

// 1 Predict the output
#include<stdio.h>
int main(){
    int j;
    while(j<=10){
        printf("\n%d",j);
        j=j+1;
    }
    return 0;
}

//2 Predict the output

#include<stdio.h>
int main(){
    int i=1;
    while(i<=10);{
        printf("\n%d",i);
        i++;
    }
    return 0;
}

// 3 Predict the output

#include<stdio.h>
int main(){
    int x=1;
    while(x==1){
        x=x-1;
        printf("\n%d",x);
    }
    return 0;
}

// 4 Predict the output


#include<stdio.h>
int main(){
    int x=4,y,z;
    y=--x;
    z=x--;
    printf("\n%d%d%d",x,y,z);
    return 0;
}

//5 Predict the output

#include<stdio.h>
int main(){
    int x=4,y=3,z;
    z=x-- -y;
    printf("\n%d%d%d"x,y,z);
    return 0;
}

//6 Predict the output

#include<stdio.h>
int main(){
    while ('a'<'b')
    printf("\n malyalam is a palindrome");
    return 0;

}

//7 Predict the output

#include<stdio.h>
int main(){
    int i=10;
    while (i=20)
    printf("\n A computer buff!");
    return 0;
}

// 8 Predict the output

#include<stdio.h>
int main(){
    int i;
    while (i=10){
        printf("\n%d",i);
        i=i+1;
    }
    return 0;
}

//9 Predict the output

#include<stdio.h>
int main(){
    int x=4,y=0,z;
    while (x>=0){
        x--;
        y++;
        if(x==y)
            continue;
        else
            printf("\n%d%d%d,x,y")
    }
    return 0;
}

//10 Predict the output

#include<stdio.h>
int main(){
    int x=4,y=0,z;
    while (x>=0){
        if(x==y)
            break;
        else
            printf("\n%d%d",x,y);
            x--;
            y++;
    }
    return 0;
}