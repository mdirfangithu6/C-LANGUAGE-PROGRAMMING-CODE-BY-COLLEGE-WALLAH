// 1:01:15+ par code
// Ques: Display this AP - 100,97,94,..upto all terms which are positive.

#include<stdio.h>
int main(){
    //int n;
    //printf("Enter a number : ");
    //scanf("%d",&n);
    //100 97 94 ....
    int a = 100;
    for(int i=1;i<=34;i++){
        printf("%d ",a);
        a = a - 3;
    }
    return 0;
}
// output
// 100 97 94 91 88 85 82 79 76 73 70 67 64 61 58 55 52 49 46 43 40 37 34 31 28 25 22 19 16 13 10 7 4 1 



// 1:06:19+ par code
#include<stdio.h>
int main(){
    //int n;
    //printf("Enter a number : ");
    //scanf("%d",&n);
    //100 97 94 ....
    int a = 100;
    for(int i=1;a>0;i++){
        printf("%d ",a);
        a = a - 3;
    }
    return 0;
}
// output
// 100 97 94 91 88 85 82 79 76 73 70 67 64 61 58 55 52 49 46 43 40 37 34 31 28 25 22 19 16 13 10 7 4 1 