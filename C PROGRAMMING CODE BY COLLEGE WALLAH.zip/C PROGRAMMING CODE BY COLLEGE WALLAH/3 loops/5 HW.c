// 37:35+ par code
// HW: Print all the odd numbers from 1 to 100
// by chatGPT

#include <stdio.h>

int main() {
    printf("Odd numbers from 1 to 100:\n");
    
    for (int i = 1; i <= 100; i += 2) { // Increment by 2 to get only odd numbers
        printf("%d ", i);
    }

    printf("\n");
    return 0;
}
// output
// Odd numbers from 1 to 100:
// 1 3 5 7 9 11 13 15 17 19 21 23 25 27 29 31 33 35 37 39 41 43 45 47 49 51 53 55 57 59 61 63 65 67 69 71 73 75 77 79 81 83 85 87 89 91 93 95 97 99 