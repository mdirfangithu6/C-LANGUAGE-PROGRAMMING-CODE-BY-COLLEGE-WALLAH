// 2:53:26+ par code
// HW: WAP to print the sum of given number and its reverse.
// by chatGPT

#include <stdio.h>

int main() {
    int num, reversed = 0, remainder, original, sum;

    // Input the number
    printf("Enter a number: ");
    scanf("%d", &num);

    original = num; // Store the original number

    // Reverse the number
    while (num != 0) {
        remainder = num % 10;        // Get the last digit
        reversed = reversed * 10 + remainder; // Build the reversed number
        num /= 10;                  // Remove the last digit
    }

    // Calculate the sum of the original number and its reverse
    sum = original + reversed;

    // Output the result
    printf("The sum of %d and its reverse (%d) is: %d\n", original, reversed, sum);

    return 0;
}
// output
// // Enter a number : 