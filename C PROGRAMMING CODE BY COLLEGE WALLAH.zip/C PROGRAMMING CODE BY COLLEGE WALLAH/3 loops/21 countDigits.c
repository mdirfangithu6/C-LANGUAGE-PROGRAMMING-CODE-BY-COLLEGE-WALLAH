// 2:21:21+ Questions using Operators +-*/

// 2:21:51+ or 2:26:00+ par code
// Ques: WAP to count digits of a given number.

#include<stdio.h>
int main(){
    int n;
    printf  ("Enter a number : ");
    scanf("%d", &n);
    int count = 0;
    while(n!=0){
        n = n/10;
        count++;
    }
    printf("The no of digits are %d", count);
    return 0;
}
// output
// Enter a number : 23456789
// The no of digits are 8