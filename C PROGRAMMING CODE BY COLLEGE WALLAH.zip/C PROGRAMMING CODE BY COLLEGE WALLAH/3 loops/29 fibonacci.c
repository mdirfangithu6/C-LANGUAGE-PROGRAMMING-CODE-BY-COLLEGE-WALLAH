// 3:21:41+ or 3:31:14+ par code
// **Ques : Print the nth fibonacci number 

#include<stdio.h>

int main(){
    int n;
    printf("enter a number : ");
    scanf("%d", &n);
    int a = 1;
    int b = 1;
    int sum = 0;
    for(int i=1; i<=n-2; i++){
        sum = a +b;
        a = b;
        b = sum;
    }
    printf("The %dth fibonacci is %d", n, sum);
    return 0;
}
// output
// enter a number : 8
// The 8th fibonacci is 21


// 2nd code
// 3:37:17+ par code
// Enter a number : 2 wala code
#include<stdio.h>
int main(){
    int n;
    printf("enter a number : ");
    scanf("%d", &n);
    int a = 1;
    int b = 1;
    int sum = 1;
    for(int i=1; i<=n-2; i++){
        sum = a +b;
        a = b;
        b = sum;
    }
    printf("The %dth fibonacci is %d", n, sum);
    return 0;
}
// output
// enter a number : 2
// The 2th fibonacci is 1