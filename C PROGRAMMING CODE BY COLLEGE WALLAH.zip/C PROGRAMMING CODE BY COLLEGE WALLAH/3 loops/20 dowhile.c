// 2:16:15+ Questions using Operators +-*/

// 2:16:25+ Do While Loop
// 2:18:02+ par code
#include<stdio.h>
int main(){
    int i = 10;
    while(i<10){
        printf("hello");
    }
    do{
        printf("Hello");
        i++;
    }while(i<10);
    return 0;
}
// output
// Hello