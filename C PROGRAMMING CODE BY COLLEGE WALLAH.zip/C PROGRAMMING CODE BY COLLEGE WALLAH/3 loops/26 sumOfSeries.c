// 2:54:03+ par code
// Ques: Print the sum of this series : 1-2+3-4+ 5 - 6... upto 'n'.

#include <stdio.h>

int main() {
    int n;
    printf("Enter a number: ");
    scanf("%d", &n);
    // 1 + 2 + 3 + 4 .... n terms
    int sum = 0;
    for(int i=1; i<=n; i++){
        sum = sum +i;
    }
    printf("The sum is : %d", sum);
    return 0;
}
// output
// Enter a number: 5
// The sum is : 15



//  2nd code
// 2:57:13+ par code
#include <stdio.h>

int main() {
    int n;
    printf("Enter a number: ");
    scanf("%d", &n);
    // 1 - 2 + 3 - 4 + 5 - 6 + .... n terms
    // odd numbers -> add
    // even numbers -> subtract
    int sum = 0;
    for(int i=1; i<=n; i++){
       if(i%2!=0)sum = sum +i;
       else sum = sum -i;
    }
    printf("The sum is : %d", sum);
    return 0;
}
// output
// Enter a number: 7
// The sum is : 4




// 3rd code
// 3:00:30+ or 3:06:39+ par code
#include <stdio.h>

int main() {
    int n;
    printf("Enter a number: ");
    scanf("%d", &n);
    // 1 - 2 + 3 - 4 + 5 - 6 + .... n terms
    // odd numbers -> add
    // even numbers -> subtract
    int sum = 0;
    if(n%2==0){
        sum = -n/2;
       }
       else{
        sum = -n/2 +n;
       }
    printf("The sum is : %d", sum);
    return 0;
}
// output
// Enter a number: 7
// The sum is : 4