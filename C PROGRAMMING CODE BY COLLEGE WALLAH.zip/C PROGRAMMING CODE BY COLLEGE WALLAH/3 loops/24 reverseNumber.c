// 2:40:20+ or 2:46:20+ par code
// Ques : WAP to ptint reverse of a given number.

#include<stdio.h>
int main(){
    int n;
    printf("Enter a number : ");
    scanf("%d", &n);
    int r = 0;
    while(n>0){
        r = r + (n%10);
        r = r*10;
        n = n/10;
    }
    printf("The reversed number is %d", r);
    return 0;
}
// output
// Enter a number : 1234
// The reversed number is 43210


// 2nd code
// 2:48:48+ par code
#include<stdio.h>
int main(){
    int n;
    printf("Enter a number : ");
    scanf("%d", &n);
    int r = 0;
    while(n>0){
        r = r + (n%10);
        r = r*10;
        n = n/10;
    }
    r = r/10;
    printf("The reversed number is %d", r);
    return 0;
}
// output
// Enter a number : 1234
// The reversed number is 4321



// 3rd code
// 2:52:27+ par code
#include<stdio.h>
int main(){
    int n;
    printf("Enter a number : ");
    scanf("%d", &n);
    int r = 0;
    while(n>0){
        r = r*10;
        r = r*10;
        n = n/10;
    }
    printf("The reversed number is %d", r);
    return 0;
}
// output
// Enter a number : 1234
// The reversed number is 4321