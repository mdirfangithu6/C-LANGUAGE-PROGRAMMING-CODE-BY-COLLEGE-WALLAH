// 2:00:40+ 

#include<stdio.h>
int main(){
    int x + 5;
    printf("%d\n", x);
    x++;
    printf("%d\n", x);
    return 0;
}

#include<stdio.h>
int main(){
    int x + 5;
    printf("%d\n", x);
    ++x;
    printf("%d\n", x);
    return 0;
}

#include<stdio.h>
int main(){
    int x + 5;
    printf("%d\n", x);
    printf("%d\n", x++);
    return 0;
}

#include<stdio.h>
int main(){
    int x + 5;
    printf("%d\n", x);
    printf("%d\n", ++x); //x++ means, use x, then incremenr
    // ++x means, increment use
    return 0;
}