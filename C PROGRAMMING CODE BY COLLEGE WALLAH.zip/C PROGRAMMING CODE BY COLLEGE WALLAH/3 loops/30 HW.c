// 3:38:32+ par code
// HW : print first 'n' fibonacci numbers.
// by chatGPT

#include <stdio.h>

void printFibonacci(int n) {
    long long int a = 0, b = 1, next;

    if (n >= 1) {
        printf("%lld ", a);
    }
    if (n >= 2) {
        printf("%lld ", b);
    }

    for (int i = 3; i <= n; i++) {
        next = a + b;
        printf("%lld ", next);
        a = b;
        b = next;
    }
    printf("\n");
}

int main() {
    int n;

    printf("Enter the number of Fibonacci numbers to print: ");
    scanf("%d", &n);

    if (n <= 0) {
        printf("Please enter a positive integer.\n");
    } else {
        printFibonacci(n);
    }

    return 0;
}
// output
// Enter the number of Fibonacci numbers to print: 
