// 37:50+ par code
// Ques : Print the table of 19

#include<stdio.h>

int main(){
    for(int i=19;i<=190;i=i+19)
    {
        printf("%d ",i);
    }
    return 0;
}
// output
// 19 38 57 76 95 114 133 152 171 190 