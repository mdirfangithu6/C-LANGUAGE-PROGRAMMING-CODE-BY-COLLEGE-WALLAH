// 40:03+ par code
// HW : Print the table of 'n'. Hero 'n' is a integer which user will input 
// by chatGPT

#include <stdio.h>

int main() {
    int n, i;

    // Taking input from the user
    printf("Enter an integer: ");
    scanf("%d", &n);

    // Printing the multiplication table
    printf("Multiplication Table of %d:\n", n);
    for (i = 1; i <= 10; i++) {
        printf("%d x %d = %d\n", n, i, n * i);
    }

    return 0;
}
// output
// Enter an integer: 
