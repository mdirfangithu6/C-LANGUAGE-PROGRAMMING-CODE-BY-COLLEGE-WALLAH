// 3:39:39+ or 3:42:20+ par code
// Ques: Two numbers are entered through the keyboard. Write a program to find the value of one number raised to the power of another.

#include<stdio.h>
int main(){
    int a,b;
    printf("enter a number : ");
    scanf("%d", &a);
    printf("enter a number : ");
    scanf("%d", &b);
    int power = 1;
    for(int i=1; i<=b; i++){
        power = power * a;
    }
    printf("%d raised to the power %d is %d", a,b,power);
}
// output
// enter a number : 2
// enter a number : 5
// 2 raised to the power 5 is 32