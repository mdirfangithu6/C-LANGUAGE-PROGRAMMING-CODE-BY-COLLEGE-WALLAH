// 56:28+ par code
// Ques: Display this GP – 1,2,4,8,16,32,.. upto 'n' terms.

#include<stdio.h>
int main(){
    int n;
    printf("Enter a number : ");
    scanf("%d",&n);
    // 1 2 4 8 16 32 ....
    int a = 1;
    for(int i=1;i<=n;i++){
        printf("%d ",a);
        a = a*2;
    }
    return 0;
}
// output
// Enter a number : 10
// 1 2 4 8 16 32 64 128 256 512 