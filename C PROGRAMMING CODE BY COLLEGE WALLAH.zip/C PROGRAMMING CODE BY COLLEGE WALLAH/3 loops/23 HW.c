// 2:39:25+ par code
// HW: WAP to print sum of all the even digits of a given number.
// by chatGPT

#include <stdio.h>

int main() {
    int num, digit, sum = 0;

    // Input the number
    printf("Enter a number: ");
    scanf("%d", &num);

    // Loop through each digit
    while (num != 0) {
        digit = num % 10; // Get the last digit
        
        if (digit % 2 == 0) { // Check if the digit is even
            sum += digit;
        }

        num /= 10; // Remove the last digit
    }

    // Output the result
    printf("The sum of even digits is: %d\n", sum);

    return 0;
}
// output
// Enter a number : 