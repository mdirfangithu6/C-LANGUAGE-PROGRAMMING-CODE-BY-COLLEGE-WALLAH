// 3:53+ par code

#include<stdio.h>

int main(){
    printf("Hello PW\n");
    printf("Hello PW\n");
    printf("Hello PW\n");
    printf("Hello PW\n");
    printf("Hello PW\n");
    return 0;
}
// output
// Hello PW
// Hello PW
// Hello PW
// Hello PW
// Hello PW




// 5:52+ par code
#include<stdio.h>

int main(){
    for(int i=1;i<=5;i++){
        printf("Hello PW\n");
    }
    return 0;
}
// output
// Hello PW
// Hello PW
// Hello PW
// Hello PW
// Hello PW