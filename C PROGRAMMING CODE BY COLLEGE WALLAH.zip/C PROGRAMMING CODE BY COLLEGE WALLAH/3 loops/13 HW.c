// 1:10:48+ par code
// HW: Display this GP – 100,50,25,.. upto 'n' terms.
// by chatGPT

#include <stdio.h>

int main() {
    int n, i;
    double term = 100, ratio = 0.5;

    printf("Enter the number of terms (n): ");
    scanf("%d", &n);

    printf("The GP series is: ");
    for (i = 1; i <= n; i++) {
        printf("%.2f ", term);
        term *= ratio;
    }

    return 0;
}
// output
// Enter the number of terms (n):