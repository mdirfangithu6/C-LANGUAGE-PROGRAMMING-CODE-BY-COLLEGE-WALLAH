// 1:11:59+ Loop ke ander jo bhi daalo vo sab repeat hota hai !!

// 1:12:43+ Break;

// 1:12:47+ or 1:17:35+ par code
// Ques: WAP to check if a number is prime or not.

#include<stdio.h>
int main(){
    int n;
    printf("Enter a number : ");
    scanf("%d",&n);
    for(int i=2;i<=n-1;i++){
        if(n%i==0){ // i is a factor of n
            printf("the given number is composite\n");
            break;
        }
    }
    return 0;
}
// output
// Enter a number : 25
// the given number is composite



// 2nd code 
// 1:20:40+ or 1:22:22+ (break)
#include<stdio.h>
int main(){
    int n;
    printf("Enter a number : ");
    scanf("%d",&n);
    int a = 0;
    for(int i=2;i<=n-1;i++){
        if(n%i==0){ // i is a factor of n
            printf("the given number is composite\n");
            break;
        }
    }
    return 0;
}
// output
// Enter a number : 12
// the given number is composite



// 3rd code
// 1:30:15+ par code
#include<stdio.h>
int main(){
    int n;
    printf("Enter a number : ");
    scanf("%d",&n);
    int a = 0;
    for(int i=2;i<=n-1;i++){
        if(n%i==0){ // i is a factor of n
            a = 1;
            break;
        }
    }
    if(n==1) printf("1 is neither prime nor composite");
    else if(a==0) printf("the given number is prime\n");
    else printf("the given number is composite\n");
    return 0;
}
// output
// Enter a number : 43
// the given number is prime




// 4th code
// 1: while loop se
#include<stdio.h>

int main(){
    int n;
    printf("Enter a number : ");
    scanf("%d", &n);

    int a = 0;
    int i = 2;
    
    while(i <= n - 1){
        if(n % i == 0){ // i is a factor of n
            a = 1;
            break;
        }
        i++;
    }

    if(n == 1) 
        printf("1 is neither prime nor composite");
    else if(a == 0) 
        printf("The given number is prime\n");
    else 
        printf("The given number is composite\n");

    return 0;
}
// output
// Enter a number : 

