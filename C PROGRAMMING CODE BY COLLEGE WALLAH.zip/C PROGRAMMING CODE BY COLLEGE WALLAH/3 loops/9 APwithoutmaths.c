// 47:33+ or 50:40+ par code
// Hw : Display this AP - 4,7,10,13,16.. upto 'n' terms.

#include<stdio.h>

int main(){
    int n; // itni baar loop chalega
    printf("Enter a number : ");
    scanf("%d", &n);
    int a = 4;
    for(int i=1;i<=n;i++){
        printf("%d ", i);
    }
    return 0;
}
// output
// Enter a number : 10
// 4 7 10 13 16 19 22 25 28 31 



// 52:52+ par code
#include<stdio.h>

int main(){
    int n; // itni baar loop chalega
    printf("Enter a number : ");
    scanf("%d", &n);
    // 4 7 10 13 16 19 ....... upto n number of terms
    // we are going to use extra variables
    int a = 4;
    for(int i=1;i<=n;i++){
        printf("%d ", a);
    }
    return 0;
}
// output
// Enter a number : 10
// 4 4 4 4 4 4 4 4 4 4 




// 54:35+ par code
#include<stdio.h>

int main(){
    int n; // itni baar loop chalega
    printf("Enter a number : ");
    scanf("%d", &n);
    // 4 7 10 13 16 19 ....... upto n number of terms
    // we are going to use extra variables
    int a = 4;
    for(int i=1;i<=n;i++){
        printf("%d ", a);
        a = a + 3;
    }
    return 0;
}
// output
// Enter a number : 10
// 4 7 10 13 16 19 22 25 28 31 