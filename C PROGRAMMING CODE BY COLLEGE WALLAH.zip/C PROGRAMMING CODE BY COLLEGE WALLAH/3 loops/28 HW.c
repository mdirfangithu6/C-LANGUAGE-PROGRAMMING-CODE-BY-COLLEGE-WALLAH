// 3:16:08+ par code
// HW: Print the factorials of first 'n' numbers
// by chstGPT

#include <stdio.h>

long long factorial(int num) {
    long long fact = 1;
    for (int i = 1; i <= num; i++) {
        fact *= i;
    }
    return fact;
}

int main() {
    int n;
    
    printf("Enter the value of n: ");
    scanf("%d", &n);
    
    printf("Factorials of first %d numbers:\n", n);
    for (int i = 1; i <= n; i++) {
        printf("%d! = %lld\n", i, factorial(i));
    }
    
    return 0;
}
