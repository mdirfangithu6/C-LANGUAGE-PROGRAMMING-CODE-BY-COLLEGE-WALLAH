// 18:42+ par code
// Ques : Print hello world 'n' times. Take 'n' as input from user

#include<stdio.h>

int main(){
    int n;
    printf("Enter a number : ");
    scanf("%d", &n);
    for(int i=1;i<=n;i=i+1){
        printf("Hello World\n");
    }
    return 0;
}
// output
// Enter a number : 



// 20:07+ par code
#include<stdio.h>

int main(){
    // int n;
    // printf("Enter a number : ");
    // scanf("%d", &n);
    for(int i=1;i<=10;i=i+1){
        printf("Hello World\n");
    }
    return 0;
}
// // output
// Hello World
// Hello World
// Hello World
// Hello World
// Hello World
// Hello World
// Hello World
// Hello World
// Hello World
// Hello World




// 25:55+ par code
#include<stdio.h>

int main() {
    // int n;
    // printf("Enter a number : ");
    // scanf("%d", &n);

    int i;
    for(i = 1; i <= 6; i++) {
        printf("Hello World\n");
    }

    printf("%d", i);
    return 0;
}
// output
// Hello World
// Hello World
// Hello World
// Hello World
// Hello World
// Hello World
// 7
