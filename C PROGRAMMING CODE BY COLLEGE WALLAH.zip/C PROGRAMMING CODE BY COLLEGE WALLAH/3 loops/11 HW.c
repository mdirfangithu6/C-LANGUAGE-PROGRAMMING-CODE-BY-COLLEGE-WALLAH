// 1:00:54+ par code
// HW: Display this GP - 3,12,48,.. upto 'n' terms.
// by chatGPT
#include <stdio.h>

int main() {
    int n, term = 3; // First term of the series

    printf("Enter the number of terms: ");
    scanf("%d", &n);

    printf("The Geometric Progression is: ");
    for (int i = 1; i <= n; i++) {
        printf("%d ", term);
        term *= 4; // Multiply the term by the common ratio (4)
    }

    printf("\n");
    return 0;
}
// output
// Enter the number of terms: 