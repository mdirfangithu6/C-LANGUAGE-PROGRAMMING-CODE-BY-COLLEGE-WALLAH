// 1:34:18+ or 1:35:03+ par code
// print the given pattern
// 1
// 2 3
// 4 5 6
// 7 8 9 10

#include<stdio.h>
int main (){
    int n;
    printf("Enter no of rows : ");
    scanf("%d", &n);
    for(int i=1; i<=n; i++){
        for(int j=1; j<=i; j++){
            printf("*");
        }
        printf("\n");
    }
    return 0;
}
// output
// Enter no of rows : 4
// *
// **
// ***
// ****


// 1:35:55+ par code
// main code
#include<stdio.h>

int main() {
    int n;
    printf("Enter number of rows: ");
    scanf("%d", &n);

    int a = 1;

    for(int i = 1; i <= n; i++) {
        for(int j = 1; j <= i; j++) {
            printf("%d ", a);
            a++;
        }
        printf("\n");
    }

    return 0;
}
// output
// Enter no of rows : 4
// 1
// 2 3
// 4 5 6
// 7 8 9 10




#include<stdio.h>

int main() {
    int n;
    printf("Enter number of rows: ");
    scanf("%d", &n);

    int num = 1;  // Start from 1

    for(int i = 1; i <= n; i++) {
        for(int j = 1; j <= i; j++) {
            printf("%d ", num);
            num++;
        }
        printf("\n");
    }

    return 0;
}

// is ka output hoga
// Enter no of rows : 4
// 1
// 2 3
// 4 5 6
// 7 8 9 10