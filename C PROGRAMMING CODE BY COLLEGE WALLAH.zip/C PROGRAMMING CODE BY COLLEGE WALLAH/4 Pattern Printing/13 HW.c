// 1:27:36+ par code

// HW : print the given pattern
// ******
// *    *
// *    *
// ******

// by chatGPT

#include <stdio.h>

int main() {
    int i, j;
    for(i = 0; i < 4; i++) {
        for(j = 0; j < 6; j++) {
            if(i == 0 || i == 3) {
                printf("*");
            } else {
                if(j == 0 || j == 5)
                    printf("*");
                else
                    printf(" ");
            }
        }
        printf("\n");
    }
    return 0;
}
// output
// ******
// *    *
// *    *
// ******