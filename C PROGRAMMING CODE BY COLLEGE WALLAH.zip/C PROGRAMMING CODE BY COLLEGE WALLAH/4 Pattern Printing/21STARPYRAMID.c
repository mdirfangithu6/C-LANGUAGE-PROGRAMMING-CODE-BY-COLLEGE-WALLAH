// 2:12:40+ 2:15:28+ par code
// print the given pattern
//   *
//  ***
// *****
//*******


#include<stdio.h>
int main (){
    int n;
    printf("Enter no of lnes : ");
    scanf("%d", &n);
    for(int i=1; i<=n; i++){
        for(int j=1; j<=i; j++){ //for space
            printf("*");
        }
        printf("\n");
    }
    return 0;
}
//  iska output
// *
// **
// ***
// ****


// 2:16:00+ par code
// 2*i-1 wala
#include<stdio.h>
int main (){
    int n;
    printf("Enter no of lnes : ");
    scanf("%d", &n);
    for(int i=1; i<=n; i++){
        for(int j=1; j<=2*i-1; j++){
            printf("*");
        }
        printf("\n");
    }
    return 0;
}
//  iska output
// Enter no of lnes : 4
// *
// ***
// *****
// *******



// 2:17:50+ par code
// no of star wala (nst) code
#include<stdio.h>
int main (){
    int n;
    printf("Enter no of lnes : ");
    scanf("%d", &n);
    int nst = 1;
    for(int i=1; i<=n; i++){
        for(int j=1; j<=nst; j++){
            printf("*");
        }
        nst = nst +2;
        printf("\n");
    }
    return 0;
}
//  iska output
// Enter no of lnes : 5
// *
// ***
// *****
// *******
// *********




// 2:22:35+ or 2:23:50+ par code
#include<stdio.h>
int main (){
    int n;
    printf("Enter no of lnes : ");
    scanf("%d", &n);
    int nst = 1;
    for(int i=1; i<=n; i++){
        for(int j=1; j<=n-i; j++){ //for space
            printf(" ");
        }
        for(int j=1; j<=nst; j++){
            printf("*");
        }
        nst = nst +2;
        printf("\n");
    }
    return 0;
}
// output
//   *
//  ***
// *****
//*******



// 2:24:40+ or 2:26:33+ par code
#include<stdio.h>
int main (){
    int n;
    printf("Enter no of lnes : ");
    scanf("%d", &n);
    int nst = 1;
    int nsp = 3;
    for(int i=1; i<=n; i++){
        for(int k=1; k<=nsp; k++){ //for space
            printf(" ");
        }
        nsp = nsp - 1; // ya nsp--;
        for(int j=1; j<=nst; j++){
            printf("*");
        }
        nst = nst +2;
        printf("\n");
    }
    return 0;
}
// output
// Enter no of lnes : 4
//    *
//   ***
//  *****
// *******


// 2:38:35+ par code
// n-1 wala
#include<stdio.h>
int main (){
    int n;
    printf("Enter no of lnes : ");
    scanf("%d", &n);
    int nst = 1;
    int nsp = n-1;
    for(int i=1; i<=n; i++){
        for(int k=1; k<=nsp; k++){ //for space
            printf(" ");
        }
        nsp = nsp - 1; // ya nsp--;
        for(int j=1; j<=nst; j++){
            printf("*");
        }
        nst = nst +2;
        printf("\n");
    }
    return 0;
}
// output
// Enter no of lnes : 4
//    *
//   ***
//  *****
// *******