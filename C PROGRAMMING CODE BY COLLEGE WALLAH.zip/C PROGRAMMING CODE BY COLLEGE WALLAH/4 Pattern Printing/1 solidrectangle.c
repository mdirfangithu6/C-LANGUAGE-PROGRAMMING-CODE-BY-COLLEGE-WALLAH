// 2:33+ or:3:03+ par code

#include<stdio.h>
int main(){
    int n;
    printf("*****\n*****\n*****");
    return 0;
}
// *****
// *****
// *****


// 5:30+ par code
#include<stdio.h>
int main(){
    int n;
    printf("enter a number : ");
    scanf("%d", &n);
    for (int i = 1; i <= n; i++)
        printf("*");
    return 0;
}
// output
// enter a number : 6
// ******


// 6:44+ par code
#include<stdio.h>
int main(){
    int n;
    printf("enter a number: ");
    scanf("%d", &n);
    for (int i = 1; i <= n; i++)
        printf("*\n");
    return 0;
}
// output
// enter a number: 3
// *
// *
// *



// 7:05+ par code
#include<stdio.h>
int main(){
    int n;
    printf("enter a number: ");
    scanf("%d", &n);
    // *****.... upton no of stars
    for(int i=1;i<=3;i++){
        for(int i=1;i<=n;i++){
            printf("*");
        }
    }
    return 0;
}
// output
// enter a number: 5
// ***************


// 10:40+ par code
#include<stdio.h>
int main(){
    int n;
    printf("enter a number : ");
    scanf("%d", &n);
    // *****.... upton no of stars
    for(int i=1; i<=n; i++){
        for(int i=1; i<=n; i++){
        printf("*");
        }
    }
    return 0;
}
// output
// enter a number : 2
// ****

// enter a number : 3
// *********


// 12:05+ par code
#include<stdio.h>
int main(){
    int n;
    printf("enter a number: ");
    scanf("%d", &n);
    // *****.... upton no of stars
    for(int i=1;i<=n;i++){
        for(int i=1;i<=n;i++){
            printf("*");
        }
        printf("\n");
    }
    return 0;
}
// output
// enter a number: 3
// ***
// ***
// ***


// 13:00+ par code
#include<stdio.h>
int main(){
    // int n;
    // printf("enter a number: ");
    // scanf("%d", &n);
    // *****.... upton no of stars
    for(int i=1;i<=3;i++){ //output loop -> no of lines
        for(int i=1;i<=5;i++){ // inner loop -> no of stars in each line
        printf("*");
        }
        printf("\n");
    }
    return 0;
}
// output
// *****
// *****
// *****


// 14:30+ par code
// n,m
#include<stdio.h>
int main(){
    int n;
    printf("enter a number: ");
    scanf("%d", &n);
    // *****.... upton no of stars
    for(int i=1;i<=n;i++){ //output loop -> no of lines
        for(int i=1;i<=m;i++){ // inner loop -> no of stars in each line
            printf("*");
        }
        printf("\n");
    }
    return 0;
}



// 15:40+ par code
// rows & columns
#include<stdio.h>
int main(){
    int n;
    printf("enter number of rows: ");
    scanf("%d", &n);
    int m;
    printf("enter number of columns: ");
    scanf("%d", &m);
    // *****.... upton no of stars
    for(int i=1;i<=n;i++){ //output loop -> no of lines
        for(int i=1;i<=m;i++){ // inner loop -> no of stars in each line
            printf("*");
        }
        printf("\n"); // har line ke baad ek enter maarne ke liye hai
    }
    return 0;
}
// output
// enter number of rows: 5
// enter number of columns: 7
// *******
// *******
// *******
// *******
// *******