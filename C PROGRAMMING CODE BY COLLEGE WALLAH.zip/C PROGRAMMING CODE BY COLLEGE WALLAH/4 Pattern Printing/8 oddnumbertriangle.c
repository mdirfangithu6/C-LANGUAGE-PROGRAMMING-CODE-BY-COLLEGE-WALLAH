// 49:20+ or 51:07+ par code
// ques : Print the given pattern
// 1
// 1 3
// 1 3 5
// 1 3 5 7

#include<stdio.h>
int main(){
    int n;
    printf("Enter no of rows : ");
    scanf("%d ", &n);
    // n = 4 -> 1 3 5 7
    for(int i=1; i<=2*n-1; i=i+2){
        printf("%d", i);
    }
    return 0;
}
// output
// Enter no of rows : 4
// 1 3 5 7


// 53:08+ par code
// extra variable se
#include<stdio.h>
int main(){
    int n;
    printf("Enter no of rows : ");
    scanf("%d", &n);
    // n = 4 -> 1 3 5 7
    int a = 1;
    for(int i=1; i<=n; i++){
        printf("%d ", i);
        a = a + 2;
    }
    return 0;
}
// output
// Enter no of rows : 4
// 1 3 5 7




// 53:50+ par code
#include<stdio.h>
int main(){
    int n;
    printf("Enter no of rows : ");
    scanf("%d", &n);
    for(int i=1; i<=n;i++) {
    int a = 1;
        for(int j=1; j<=n; j++) {
            printf("%d ",a);
            a = a + 2;
        }
        printf("\n");
    }
    return 0;
}
// output
// Enter no of rows : 4
// 1 3 5 7
// 1 3 5 7
// 1 3 5 7
// 1 3 5 7


// 55:42+ par code
// dusre tarike se
#include<stdio.h>
int main(){
    int n;
    printf("Enter no of rows : ");
    scanf("%d", &n);
    for(int i=1; i<=n;i++) {
        for(int j=1; j<=2*n-1; j=j+2){
            printf("%d ",j);
        }
        printf("\n");
    }
    return 0;
}
// output 
// Enter no of rows : 4
// 1 3 5 7
// 1 3 5 7
// 1 3 5 7
// 1 3 5 7


// 556:12+ par code
// main code
#include<stdio.h>
int main(){
    int n;
    printf("Enter no of rows : ");
    scanf("%d", &n);
    // n = 4 -> 1 3 5 7
    for(int i=1; i<=n;i++) {
        int a = 1;
        for(int j=1; j<=i; j++){
            printf("%d ",a);
            a = a + 2;
        }
        printf("\n");
    }
    return 0;
}
// output
// Enter no of rows : 4
// 1 
// 1 3 
// 1 3 5 
// 1 3 5 7 
