// 1:55:48+ or 2:07:27+ par code
// print the given pattern
//   *
//  **
// ***
//****


#include<stdio.h>
int main (){
    int n;
    printf("Enter no lines : ");
    scanf("%d", &n);
    for(int i=1; i<=n; i++){
        for(int j=1; j<=n-i; j++){
            printf(" ");
        }
        for(int k=1; k<=i; k++){
            printf("*");
        }
        printf("\n");
    }
    return 0;
}
// output
//   *
//  **
// ***
//****