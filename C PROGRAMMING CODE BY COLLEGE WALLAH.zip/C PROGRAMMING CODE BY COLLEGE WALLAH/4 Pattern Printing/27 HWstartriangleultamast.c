// 3:04:09+ par code
// HW : print the given pattern
//    ****
//   ****
//  ****
// ****

// by chatGPT
#include<stdio.h>

int main() {
    int n;
    printf("Enter no of lines : ");
    scanf("%d", &n);
    int nst = n;        // number of stars per line
    int nsp = n - 1;    // initial number of spaces

    for(int i = 1; i <= n; i++) {
        for(int j = 1; j <= nsp; j++) {
            printf(" ");
        }
        for(int k = 1; k <= nst; k++) {
            printf("*");
        }
        nsp--;
        printf("\n");
    }
    return 0;
}
// output
// Enter no of lines : 4
//    ****
//   ****
//  ****
// ****


// 3:05:15+ par code
// ****
//  ***
//   **
//    *

#include<stdio.h>
int main(){
    int n;
    printf("Enter no of lines : ");
    scanf("%d", &n);
    int nst = n;
    int nsp = 0;
    for(int i=1; i<=n; i++){
        for(int j=1; j<=nsp;j++){
            printf(" ");
        }
        for(int k=1; k<=nst; k++){
            printf("*");
        }
        nsp++;
        nst--;
        printf("\n");
    }
    return 0;
}
// output
// Enter no of lines : 4
// ****
//  ***
//   **
//    *