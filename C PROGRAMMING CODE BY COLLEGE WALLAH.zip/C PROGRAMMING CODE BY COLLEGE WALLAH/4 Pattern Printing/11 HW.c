// 1:15:50+ par code
// *HW : Print th given pattern
// 1
// A B
// 1 2 3 
// A B C D 
// 1 2 3 4 5

//  by chatGPT

#include <stdio.h>

int main() {
    int rows = 4;

    for (int i = 1; i <= rows; i++) {
        // Odd rows: numbers
        if (i % 2 != 0) {
            for (int j = 1; j <= i; j++) {
                printf("%d ", j);
            }
        }
        // Even rows: alphabets
        else {
            char ch = 'A';
            for (int j = 1; j <= i; j++) {
                printf("%c ", ch);
                ch++;
            }
        }
        printf("\n");
    }

    return 0;
}
// output
// 1 
// A B 
// 1 2 3 
// A B C D 