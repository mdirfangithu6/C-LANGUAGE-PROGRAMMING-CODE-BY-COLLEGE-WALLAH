// 1:16:55+ or 1:22:05+ par code
// Ques : Print the given pattern
//   *  
//   *  
// *****
//   *  
//   * 


#include<stdio.h>
int main(){
    int n;
    printf("Enter no of roes : ");
    scanf("%d", &n);
    for(int i=1; i<=n; i++){
        for(int j=1; j<=n; j++){
            printf("*");
        }
        printf("\n");
    }
    return 0;
}
// output
// Enter no of roes : 5
// ***** 
// ***** 
// ***** 
// ***** 
// ***** 


// 1:23:47+ par code
#include<stdio.h>
int main(){
    int n;
    printf("Enter no of roes : ");
    scanf("%d", &n);
    for(int i=1; i<=n; i++){
        for(int j=1; j<=n; j++){
            if(j==3 || i==3) printf("*");
            else printf("#");
        }
        printf("\n");
    }
    return 0;
}
// output
// Enter no of roes : 5
// ##*## 
// ##*## 
// ***** 
// ##*## 
// ##*## 



// 1:25:40+ par code
#include<stdio.h>
int main(){
    int n;
    printf("Enter no of roes : ");
    scanf("%d", &n);
    for(int i=1; i<=n; i++){
        for(int j=1; j<=n; j++){
            if(j==n/2+1 || i==n/2+1) printf("*");
            else printf("#");
        }
        printf("\n");
    }
    return 0;
}
// output
// Enter no of roes : 5
// ##*## 
// ##*## 
// ***** 
// ##*## 
// ##*## 


// 1:26:10+ par code
// a naya variable 
#include<stdio.h>
int main(){
    int n;
    printf("Enter no of roes : ");
    scanf("%d", &n);
    for(int i=1; i<=n; i++){
        for(int j=1; j<=n; j++){
            int a = n/2+1
            if(j==a || i==a) printf("*");
            else printf("#");
        }
        printf("\n");
    }
    return 0;
}





// 1:26:48+ par code
// main code 
#include<stdio.h>
int main(){
    int n;
    printf("Enter no of roes : ");
    scanf("%d", &n);
    for(int i=1; i<=n; i++){
        for(int j=1; j<=n; j++){
            int a = n/2+1;
            if(j==a || i==a) printf("*");
            else printf(" ");
        }
        printf("\n");
    }
    return 0;
}
// output
// Enter no of roes : 5
//   *  
//   *  
// *****
//   *  
//   *  