// 2:28:06+ par code
// HW : Print the output
//    1
//   123
//  12345
// 1234567

// bY chatGPT
#include <stdio.h>

int main() {
    int i, j, space;

    for(i = 1; i <= 4; i++) {
        // Print leading spaces
        for(space = 1; space <= 4 - i; space++) {
            printf(" ");
        }
        // Print numbers
        for(j = 1; j <= (2 * i - 1); j++) {
            printf("%d", j);
        }
        printf("\n");
    }

    return 0;
}
// output
//    1
//   123
//  12345
// 1234567
