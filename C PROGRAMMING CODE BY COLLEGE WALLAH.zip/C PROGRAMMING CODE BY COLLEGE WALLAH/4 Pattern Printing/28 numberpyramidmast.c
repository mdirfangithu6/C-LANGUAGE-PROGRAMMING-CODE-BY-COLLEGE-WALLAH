// 3:19:23+ or 3:22:03+ par code
// Ques : Print the given pattern
// 1 2 3 4 5 6 7 
// 1 2 3   5 6 7
// 1 2       6 7
// 1           1


#include<stdio.h>
int main (){
    int n;
    printf("Enter no of lines : ");
    scanf("%d", &n);
    // 1234567
    // 123 567
    // 12   67
    // 1     7
    for(int i=1; i<=n; i++){
        for(int j=1; j<=2*n-1;j++){ 
            printf("%d", j);
        }
        printf("\n");
    }
    return 0;
}
// iska ouput
// 1234567
// 1234567
// 1234567
// 1234567




// 3:26:51+ par code
#include<stdio.h>
int main (){
    int n;
    printf("Enter no of lines : ");
    scanf("%d", &n);
    int nst = n;
    nsp = 1;
    for(int i=1; i<=2*n+1; i++){ // pehli line
        printf("%d", i);
    }
    printf("\n");
    for(int i=1; i<=n; i++){
        for(int j=1; j<=nst;j++){ // stars
            print("%d", j);
        }
        for(int k=1; k<=nsp; k++){ // spaces
            printf(" ");
        }
        for(int j=1; j<=nst;j++){ // stars
            printf("%d", j);
        }
        nst--;     //nst = nst - 1;
        nsp+=2;
        printf("\n");
    }
    return 0;
}
// iska output
// Enter no of lines : 3
// 1234567
// 123 123
// 12   12
// 1     1


// 3:29:25+ par code
#include<stdio.h>
int main (){
    int n;
    printf("Enter no of lines : ");
    scanf("%d", &n);
    int nst = n;
    int nsp = 1;
    for(int i=1; i<=2*n+1; i++){ // pehli line
        printf("%d", i);
    }
    printf("\n");
    for(int i=1; i<=n; i++){
        int a = 1;
        for(int j=1; j<=nst;j++){ // stars
            printf("%d", a);
            a++;
        }
        for(int k=1; k<=nsp; k++){ // spaces
            printf(" ");
        }
        for(int j=1; j<=nst;j++){ // stars
            printf("%d", a);
            a++;
        }
        nst--;     //nst = nst - 1;
        nsp+=2;
        printf("\n");
    }
    return 0;
}
// iska output
// 1234567
// 123 456
// 12   34
// 1     2


// 3:30:03+ par code
// main code
#include<stdio.h>
int main (){
    int n;
    printf("Enter no of lines : ");
    scanf("%d", &n);
    int nst = n;
    int nsp = 1;
    for(int i=1; i<=2*n+1; i++){ // pehli line
        printf("%d", i);
    }
    printf("\n");
    for(int i=1; i<=n; i++){
        int a = 1;
        for(int j=1; j<=nst;j++){ // stars
            printf("%d", a);
            a++;
        }
        for(int k=1; k<=nsp; k++){ // spaces
            printf(" ");
            a++;
        }
        for(int j=1; j<=nst;j++){ // stars
            printf("%d", a);
            a++;
        }
        nst--;     //nst = nst - 1;
        nsp+=2;
        printf("\n");
    }
    return 0;
}
// output
// Enter no of lines : 3
// 1234567
// 123 567
// 12   67
// 1     7