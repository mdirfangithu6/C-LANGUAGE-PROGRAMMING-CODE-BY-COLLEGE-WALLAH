// 1:05:00+ or 1:07:10+ par code
// Ques : Print the given pattern
// A B C D 
// A B C D 
// A B C D 
// A B C D 


#include<stdio.h>
int main(){
    int n;
    printf("Enter no of rows : ");
    scanf("%d", &n);
    for(int i=1; i<=n; i++){ // no of lines / roes -> i
        for(int j=1; j<=n; j++){ // no of columns -> j
            printf("%d ", j);
        }
        printf("\n");
    }
    return 0;
}
// output
// Enter no of rows : 4
// 1 2 3 4 
// 1 2 3 4 
// 1 2 3 4 
// 1 2 3 4 


// 
// extra variable
#include<stdio.h>
int main(){
    int n;
    printf("Enter no of rows : ");
    scanf("%d", &n);
    for(int i=1; i<=n; i++){ // no of lines / roes -> i
        int a = 1;
        for(int j=1; j<=n; j++){ // no of columns -> j
            printf("%d ", a);
            a++;
        }
        printf("\n");
    }
    return 0;
}
// output
// Enter no of roes : 4
// 1 2 3 4 
// 1 2 3 4 
// 1 2 3 4 
// 1 2 3 4 




// 1:08:55+ par code


// 1:10:40+ par code
#include<stdio.h>
int main(){
    int n;
    printf("Enter no of rows : ");
    scanf("%d", &n);
    // A B C D
    // A B C D
    // A B C D
    // A B C D
    for(int i=1; i<=n; i++){ // no of lines / roes -> i
        int a = 1;
        for(int j=1; j<=n; j++){ // no of columns -> j
            printf("%d ", a+64);
            a++;
        }
        printf("\n");
    }
    return 0;
}
// output
// Enter no of rows : 3
// 65 66 67
// 65 66 67
// 65 66 67




// 1:11:35+ par code
#include<stdio.h>
int main(){
    int n;
    printf("Enter no of rows : ");
    scanf("%d", &n);
    // A B C D
    // A B C D
    // A B C D
    // A B C D
    for(int i=1; i<=n; i++){ // no of lines / roes -> i
        int a = 1;
        for(int j=1; j<=n; j++){ // no of columns -> j
            int d = a + 64;
            printf("%d ", d);
            a++;
        }
        printf("\n");
    }
    return 0;
}
// output
// Enter no of rows : 3
// 65 66 67
// 65 66 67
// 65 66 67



// 1:12:25+par code
#include<stdio.h>
int main(){
    int n;
    printf("Enter no of rows : ");
    scanf("%d", &n);
    // A B C D
    // A B C D
    // A B C D
    // A B C D
    for(int i=1; i<=n; i++){ // no of lines / roes -> i
        int a = 1;
        for(int j=1; j<=n; j++){ // no of columns -> j
            int d = a + 64; // d = 65
            char ch = (char)d; // ch = (chat)65 -> ch = 'A'
            printf("%c ", ch);
            a++;
        }
        printf("\n");
    }
    return 0;
}
// output
// Enter no of rows : 4
// A B C D
// A B C D
// A B C D
// A B C D


// without extra variable
#include<stdio.h>
int main(){
    int n;
    printf("Enter no of rows : ");
    scanf("%d", &n);
    // A B C D
    // A B C D
    // A B C D
    // A B C D
    for(int i=1; i<=n; i++){ // no of lines / roes -> i
        int a = 1
        for(int j=1; j<=n; j++){ // no of columns -> j
            char ch = (char)(a+64); // ch = (chat)65 -> ch = 'A'
            printf("%d", d);
            a++;
        }
        printf("\n");
    }
    return 0;
}
// output
// Enter no of rows : 4
