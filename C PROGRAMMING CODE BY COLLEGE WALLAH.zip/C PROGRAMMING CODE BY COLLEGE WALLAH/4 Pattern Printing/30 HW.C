// 3:37:03+ par code

// HW : print the given pattern
// 1 2 3 4 5 6 7 
// 1 2 3   3 2 1
// 1 2       2 1
// 1           1

// BY CHATGPT

#include <stdio.h>

int main() {
    int i, j;

    for(i = 0; i < 4; i++) {
        // Print first half
        for(j = 1; j <= 3 - i; j++) {
            printf("%d ", j);
        }

        // Print spaces in the middle
        for(j = 0; j < 2 * i + 1; j++) {
            printf("  ");
        }

        // Print second half
        for(j = 3 - i; j >= 1; j--) {
            printf("%d ", j);
        }

        printf("\n");
    }

    return 0;
}