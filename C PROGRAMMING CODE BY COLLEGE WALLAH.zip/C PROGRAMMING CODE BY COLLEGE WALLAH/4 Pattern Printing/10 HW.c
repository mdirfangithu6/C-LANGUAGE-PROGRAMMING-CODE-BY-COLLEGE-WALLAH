// 1:14:05+ par code
// HW : Print th given pattern
// A
// A B
// A B C
// A B C D

// by chatGPT

#include <stdio.h>

int main() {
    int rows = 4;

    for (int i = 1; i <= rows; i++) {
        char ch = 'A';
        for (int j = 1; j <= i; j++) {
            printf("%c ", ch);
            ch++;
        }
        printf("\n");
    }

    return 0;
}
// output
// A 
// A B 
// A B C 
// A B C D 