// 18:00+ par code
// Ques : Print the given pattern
// 1234
// 1234
// 1234
// 1234

#include<stdio.h>
int main(){
    int n;
    printf("Enter no of rows : ");
    scanf("%d", &n);
    for(int i=1; i<=n; i++){ // no of lines / roes -> i
        for(int j=1; j<=n; j++){ // no of columns -> j
            printf("%d", j);
        }
        printf("\n");
    }
    return 0;
}
// output
// Enter no of rows : 4
// 1234
// 1234
// 1234
// 1234