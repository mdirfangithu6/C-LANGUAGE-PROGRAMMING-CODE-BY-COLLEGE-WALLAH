// 35:09+ or 37:10+  par code
// Ques : Print the given pattern
// ****
// ***
// **
// *

#include<stdio.h>
int main(){
    int n;
    printf("Enter no of roes : ");
    scanf("%d", &n);
    for(int i=1; i<=n; i++){ // no of lines / roes -> i
        for(int j=1; j<=n+1-i; j++){ // no of columns -> j // if i =1, j
            printf("* ");
        }
        printf("\n");
    }
    return 0;
}
// output
// Enter no of roes : 4
// * * * * 
// * * * 
// * * 
// * 



// 43:20+ par code
// extra variable
#include<stdio.h>
int main(){
    int n;
    printf("Enter no of roes : ");
    scanf("%d", &n);
    int a = n;
    for(int i=1; i<=n; i++){ // j -> 1 to a
        for(int j=1; j<=a; j++){ 
            printf("* ");
        }
        printf("\n");
    }
    return 0;
}
//  output
//  Enter no of roes : 4
//  * * * *
//  * * * * 
//  * * * *
//  * * * *


// 44:58+ par code
#include<stdio.h>
int main(){
    int n;
    printf("Enter no of roes : ");
    scanf("%d", &n);
    int a = n;
    for(int i=1; i<=n; i++){ // j -> 1 to a
        for(int j=1; j<=a; j++){ 
            printf("*");
        }
        a--;
        printf("\n");
    }
    return 0;
}
// output
// Enter no of roes : 4
// * * * * 
// * * * 
// * * 
// * 