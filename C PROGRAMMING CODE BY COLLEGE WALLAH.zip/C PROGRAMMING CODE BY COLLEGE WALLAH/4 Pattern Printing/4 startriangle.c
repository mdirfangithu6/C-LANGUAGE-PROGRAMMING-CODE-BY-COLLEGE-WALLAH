// 25:50+ or 28:11+ par code
// Ques : Print the given pattern

// * 
// * * 
// * * * 
// * * * * 

#include<stdio.h>
int main(){
    int n;
    printf("Enter no. of rows : ");
    scanf("%d", &n);
    for(int i=1; i<=n; i++){ // no of lines / rows --> i
        for(int j=1; j<=n; j++){ // no of columns --> j
            printf("* ");
        }
        printf("\n");
    }
    return 0;
}
// output
// Enter no. of rows : 4
// * * * * 
// * * * * 
// * * * * 
// * * * * 


// 28:50+ par code
// main code
#include<stdio.h>
int main(){
    int n;
    printf("Enter no. of rows : ");
    scanf("%d", &n);
    for(int i=1; i<=n; i++){ // no of lines / rows --> i
        for(int j=1; j<=i; j++){ // no of columns --> j
            printf("* ");
        }
        printf("\n");
    }
    return 0;
}
// output
// Enter no. of rows : 4
// * 
// * * 
// * * * 
// * * * * 