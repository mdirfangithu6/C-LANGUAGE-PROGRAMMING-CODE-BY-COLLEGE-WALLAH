// 2:29:00+ par code
// HW : Print the output
//    A
//   ABC
//  ABCDE
// ABCDEFG

// bY chatGPT
#include <stdio.h>

int main() {
    int i, j, space;

    for(i = 1; i <= 4; i++) {
        // Print leading spaces
        for(space = 1; space <= 4 - i; space++) {
            printf(" ");
        }
        // Print characters
        for(j = 0; j < (2 * i - 1); j++) {
            printf("%c", 'A' + j);
        }
        printf("\n");
    }

    return 0;
}
// output
//    A
//   ABC
//  ABCDE
// ABCDEFG