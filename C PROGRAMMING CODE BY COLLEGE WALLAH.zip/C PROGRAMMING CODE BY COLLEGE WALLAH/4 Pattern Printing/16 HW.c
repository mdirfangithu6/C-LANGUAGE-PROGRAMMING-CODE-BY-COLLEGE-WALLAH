// 1:38:12+ par code
// print the given pattern
// 1
// 3 5
// 7 9 11
// 13 15 17 19

// by chatGPT

#include <stdio.h>

int main() {
    int i, j, num = 1;
    
    for(i = 1; i <= 4; i++) {
        for(j = 1; j <= i; j++) {
            printf("%d ", num);
            num += 2;
        }
        printf("\n");
    }
    
    return 0;
}
// output
// 1 
// 3 5 
// 7 9 11 
// 13 15 17 19 