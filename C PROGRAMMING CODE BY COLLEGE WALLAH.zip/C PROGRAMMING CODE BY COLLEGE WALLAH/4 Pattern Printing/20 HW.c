// 2:11:20+ par code
// Print the given pattern

//   A
//  AB
// ABC
//ABCD

// by chatGPT

#include<stdio.h>

int main() {
    int n;
    printf("Enter number of rows: ");
    scanf("%d", &n);

    for(int i = 1; i <= n; i++) {
        // print spaces
        for(int s = 1; s <= n - i; s++) {
            printf(" ");
        }
        // print characters
        char ch = 'A';
        for(int j = 1; j <= i; j++) {
            printf("%c", ch);
            ch++;
        }
        printf("\n");
    }

    return 0;
}
// output
//   A
//  AB
// ABC
//ABCD