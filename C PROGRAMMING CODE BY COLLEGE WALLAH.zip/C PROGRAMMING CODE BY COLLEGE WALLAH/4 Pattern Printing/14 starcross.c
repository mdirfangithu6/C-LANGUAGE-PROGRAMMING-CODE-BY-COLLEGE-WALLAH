// 1:28:54+ or 1:29:45+ par code
// print the given pattern
// *   *
//  * * 
//   *  
//  * * 
// *   *


#include<stdio.h>
int main (){
    int n;
    printf("Enter no pf rows : ");
    scanf("%d", &n);
    for(int i=1; i<=n; i++){
        for(int j=1; j<=n; j++){
            if(i==j || i+j == n+1) printf("*");
            else printf(" ");
        }
        printf("\n");
    }
    printf("\n");
    return 0;
}
// output
// Enter no pf rows : 5
// *   *
//  * * 
//   *  
//  * * 
// *   *