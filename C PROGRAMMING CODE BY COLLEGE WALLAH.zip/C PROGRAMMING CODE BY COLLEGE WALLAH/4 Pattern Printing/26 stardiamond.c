// 2:44:42+ or2:47:08+ par code
// Ques : Print the given pattern

//    *
//   ***
//  *****
// *******
//  *****
//   ***
//    *


#include<stdio.h>
int main(){
    int n;
    printf("Enter no of lines : ");
    scanf("%d", &n);
    int nsp = n/2;
    int nst = 1;
    for(int i=1; i<=n; i++){
        for(int j=1; j<=nsp; j++){
            printf(" ");
        }
        for(int k=1; k<=nst; k++){
            printf("*");
        }
        nsp--;
        nst+=2;
        printf("\n");
    }
    return 0;
}
// iska output
// Enter no of lines : 7
//    *
//   ***
//  *****
// *******
// *********
// ***********
// *************





// 2:56:50+ par code
// main code
#include<stdio.h>
int main(){
    int n;
    printf("Enter no of lines : ");
    scanf("%d", &n);
    int nsp = n/2;
    int nst = 1;
    int ml = n/2 + 1;
    for(int i=1; i<=n; i++){
        for(int j=1; j<=nsp; j++){
            printf(" ");
        }
        for(int k=1; k<=nst; k++){
            printf("*");
        }
        if(i<ml){
            nsp--;
            nst+=2;
        }
        else{
            nsp++;
            nst-=2;
        }
        printf("\n");
    }
    return 0;
}
// output
// Enter no of lines :7
//    *
//   ***
//  *****
// *******
//  *****
//   ***
//    *