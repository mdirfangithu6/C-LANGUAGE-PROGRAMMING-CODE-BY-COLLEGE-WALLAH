// 3:38:33+ 3:39:48+ par code
// **Ques : Print teh given pattern
// 4 4 4 4 4 4 4
// 4 3 3 3 3 3 4
// 4 3 2 2 2 3 4
// 4 3 2 1 2 3 4
// 4 3 2 2 2 3 4
// 4 3 3 3 3 3 4
// 4 4 4 4 4 4 4

#include<stdio.h>

int main(){
    int n;
    printf("Enter no. of lines : ");
    scanf("%d",&n);
    int min = 0;
    for(int i=1;i<=n;i++) {
        for(int j=1;j<=n;j++){
            if(i<j) min = i; // minimum of 2 numbers
            else min = j;
            printf("%d",min);
        }
        printf("\n");
    }
    return 0;
}
// output
// Enter no. of lines : 4
// 1111
// 1222
// 1233
// 1234



// 3:53:08+ par code
#include<stdio.h>

int main(){
    int n;
    printf("Enter no of lines : ");
    scanf("%d",&n);
    int min = 0;
    for(int i=1; i<=2*n-1; i++) {
        for(int j=1; j<=2*n-1; j++){
            int a = i;
            int b = j;
            if(a<b) min = a; 
            else min = b;
            printf("%d",min);
        }
        printf("\n");
    }
    return 0;
}
// output
// Enter no. of lines : 4
// 1111111
// 1222222
// 1233333
// 1234444
// 1234555
// 1234566
// 1234567


// 3:54:42+ par code
#include<stdio.h>

int main(){
    int n;
    printf("Enter no of lines : ");
    scanf("%d",&n);
    int min = 0;
    for(int i=1;i<=2*n-1;i++) {
        for(int j=1;j<=2*n-1;j++){
            int a = i;
            if(i>n){
                a = 2*n - i;
            }
            int b = j;
            if(b>n){
                b = 2*n - j;
            }
            if(a<b) min = a; 
            else min = b;
            printf("%d",min);
        }
        printf("\n");
    }
    return 0;
}
// iska output
// Enter no of lines : 4
// 1111111
// 1222221
// 1233321
// 1234321
// 1233321
// 1222221
// 1111111




// 3:58:40+ par code
// main code
#include<stdio.h>

int main(){
    int n;
    printf("Enter no. of lines : ");
    scanf("%d",&n);
    int min = 0;
    for(int i=1; i<=2*n-1; i++) {
        for(int j=1; j<=2*n-1; j++){
            int a = i;
            if(i>n){
                a = 2*n - i;
            }
            int b = j;
            if(b>n){
                b = 2*n - j;
            }
            if(a<b) min = a; 
            else min = b;
            printf("%d", n+1-min);
        }
        printf("\n");
    }
    return 0;
}
// output
// Enter no. of lines : 4
// 4444444
// 4333334
// 4322234
// 4321234
// 4322234
// 4333334
// 4444444