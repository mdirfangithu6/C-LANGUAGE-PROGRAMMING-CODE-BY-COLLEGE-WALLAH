// 48:55+ par code
// HW : Print the given pattern

// 1 2 3 4
// 1 2 3
// 1 2
// 1

// by chatGPT

#include <stdio.h>

int main() {
    int rows = 4;

    for (int i = rows; i >= 1; i--) {
        for (int j = 1; j <= i; j++) {
            printf("%d ", j);
        }
        printf("\n");
    }

    return 0;
}
// output
// 1 2 3 4
// 1 2 3
// 1 2
// 1