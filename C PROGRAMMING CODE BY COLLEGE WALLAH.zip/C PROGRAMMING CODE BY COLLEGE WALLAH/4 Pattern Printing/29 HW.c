// 3:36:38+ par code
// HW : print the given pattern
// A B C D E F G
// A B C   E F G
// A B       F G
// A           G

// by chatGPT

#include <stdio.h>

int main() {
    int i, j;
    char ch;

    for(i = 0; i < 4; i++) {
        ch = 'A';
        for(j = 0; j < 7; j++) {
            // Print letters for outer sides, spaces for the hollow middle
            if(j <= 2 - i || j >= 4 + i)
                printf("%c ", ch);
            else
                printf("  ");
            ch++;
        }
        printf("\n");
    }

    return 0;
}
