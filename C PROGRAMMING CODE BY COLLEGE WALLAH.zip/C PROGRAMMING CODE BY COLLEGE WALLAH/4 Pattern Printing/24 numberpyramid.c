// 2:29:40+ or 2:31:27+ par code
// print the given pattern
//    1
//   123
//  12345
// 1234567

#include<stdio.h>
int main (){
    int n;
    printf("Enter no of lines : ");
    scanf("%d", &n);
    for(int i=1; i<=n; i++){
        for(int j=1; j<=i; j++){
            printf("%d ", j);
        }
        printf("\n");
    }
    return 0;
}
// iska output
// 1
// 1 2
// 1 2 3
// 1 2 3 4


// 2:33:30+ or 2:36:00+ par code
#include<stdio.h>
int main (){
    int n;
    printf("Enter no of lnes : ");
    scanf("%d", &n);
    for(int i=1; i<=n; i++){
        for(int j=1; j<=i; j++){
            printf("%d ", j);
        }
        for(int k=1; k<=nsp; k++){ 
            printf("*");
        }
        printf("\n");
    }
    return 0;
}

// iska output
// 1
// 12*
// 123**
// 1234***


// 2:37:10+ par code
#include<stdio.h>
int main (){
    int n;
    printf("Enter no of lnes : ");
    scanf("%d", &n);
    int nsp = n-1;
    for(int i=1; i<=n; i++){
        int a = i - 1;
        for(int q=1; q<=nsp; q++){ // spaces ke liye ek loop
            printf(" ");
        }
        nsp--;
        for(int j=1; j<=i; j++){ // number triangel
            printf("%d ", j);
        }
        for(int k=1; k<=i-1; k++){ // extra cheez
            printf("*");
            a--;
        }
        printf("\n");
    }
    return 0;
} 
// output
// Enter no of lnes : 4
//    1 
//   1 2 *
//  1 2 3 **
// 1 2 3 4 ***


// 2:40:10+ par code
// main code
#include<stdio.h>
int main (){
    int n;
    printf("Enter no of lnes : ");
    scanf("%d", &n);
    int nsp = n-1;
    for(int i=1; i<=n; i++){
        int a = i - 1;
        for(int q=1; q<=nsp; q++){ // spaces ke liye ek loop
            printf(" ");
        }
        nsp--;
        for(int j=1; j<=i; j++){ // number triangel
            printf("%d", j);
        }
        for(int k=1; k<=i-1; k++){ // extra cheez
            printf("%d", a);
            a--;
        }
        printf("\n");
    }
    return 0;
} 
// output
// Enter no of lnes : 4
//    1
//   121
//  12321
// 1234321