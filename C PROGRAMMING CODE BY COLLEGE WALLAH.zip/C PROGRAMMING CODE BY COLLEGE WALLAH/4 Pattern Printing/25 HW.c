// 2:42:34+ par code
// HW : Print the output
//    A
//   ABA
//  ABCAB
// ABCDCBA

#include<stdio.h>
int main (){
    int n;
    printf("Enter no of lnes : ");
    scanf("%d", &n);
    int nsp = n-1;
    for(int i=1; i<=n; i++){
        int a = i - 1;
        for(int q=1; q<=nsp; q++){ // spaces ke liye ek loop
            printf(" ");
        }
        nsp--;
        for(int j=1; j<=i; j++){ // number triangel
            char ch = (char)(j+64);
            printf("%c", ch);
        }
        for(int k=1; k<=i-1; k++){ // extra cheez
            char ch = (char)(a+64);
            printf("%c", ch);
            a--;
        }
        printf("\n");
    }
    return 0;
} 
// output
// Enter no of lnes : 4
//    A
//   ABA
//  ABCBA
// ABCDCBA