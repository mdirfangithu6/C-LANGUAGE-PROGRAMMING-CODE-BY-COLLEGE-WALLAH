// 3:07:45+ or3:11:20+ par code
// Ques : Print the given pattern


#include<stdio.h>
int main (){
    int n;
    printf("Enter no of lines : ");
    scanf("%d", &n);
    // **** ****
    // ***   ***
    // **     **
    // *       *

    int nst = n;
    int nsp = 1;
    for(int i=1; i<=n; i++){
        for(int j=1; j<=nst;j++){ // stars
            printf("*");
        }
        for(int k=1; k<=nsp; k++){ // spaces
            printf(" ");
        }
        for(int j=1; j<=nst;j++){ // stars
            printf("*");
        }
        nst--;     //nst = nst - 1;
        nsp+=2;
        printf("\n");
    }
    return 0;
}
//  iska output
// Enter no of lines : 4
// **** ****
// ***   ***
// **     **
// *       *

// Enter no of lines : 3
// *** ***
// **   **
// *     *



// 3:16:32+ or 3:17:08+ par code
#include<stdio.h>
int main (){
    int n;
    printf("Enter no of lines : ");
    scanf("%d", &n);
    int nst = n;
    int nsp = 1;
    for(int i=1; i<=2*n+1; i++){ // pehli line
        printf("*");
    }
    printf("\n");
    for(int i=1; i<=n; i++){
        for(int j=1; j<=nst;j++){ // stars
            printf("*");
        }
        for(int k=1; k<=nsp; k++){ // spaces
            printf(" ");
        }
        for(int j=1; j<=nst;j++){ // stars
            printf("*");
        }
        nst--;     //nst = nst - 1;
        nsp+=2;
        printf("\n");
    }
    return 0;
}
// output
// Enter no of lines : 4
// *********
// **** ****
// ***   ***
// **     **
// *       *   